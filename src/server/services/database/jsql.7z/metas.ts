/*----------------------------------
- DEPENDANCES
----------------------------------*/

import type mysql from 'mysql2/promise';

import type { TModelMetas } from '@server/services/models/table';

import type { TCondition } from './jsql/factories/abstraction/conditions';
import type { TTypeColonne } from './datatypes';
import type QueryParser from './jsql/query/base';

/*----------------------------------
- TYPES: DATABASE
----------------------------------*/

type TDatabaseColumn = {

    database: string,
    table: string,
    colonne: string,

    defaut: string,
    nullable: string,
    type: string,
    cle: string,
    extra: string,

    assoTable: string,
    assoCol: string,

    onUpdate: string | null,
    onDelete: string | null,

}

export type TDatabasesList = {
    [database: string]: {
        [table: string]: TMetasTable
    }
}

/*----------------------------------
- TYPES: TABLE
----------------------------------*/

export type TMetasTablesIncompletes = TMetasTables<{ loaded: false, database: string, nom: string }>

export type TMetasTables<TInfos = TMetasTable> = {
    default: TInfos,
    [table: string]: TInfos
}

export type TAssociationsIndex = { all: string[] } & { [type in TTypeAsso]: string[] }

export type TTypeAsso = 'hasone' | 'hasmany';

export type TMetasTable = {

    nom: string,
    associations: TAssociationsIndex,
    loaded: true,

    database: string,
    chemin: string, // database + nom

    alias: string,
    modele?: TModelMetas, // Modèle rattaché si table par défaut de ce modèle

    pk: { 0: string } & string[], // Au moins une pk doit être renseignée
    colonnes: TListeMetasColonnesTable,
}

/*----------------------------------
- TYPES: COLUMN
----------------------------------*/

export type TListeMetasColonnesTable = { [nom: string]: TMetasColonne }

export type TMetasColonne = {
    attached: boolean, // Si les métadonnées ont bien été enrichies avec celles provenant de MySQL

    table: TMetasTable,
    nom: string,
    type: TTypeColonne,
    typeParams: string[],
    primary: boolean,
    api?: TMetasApi,
    nullable: boolean,
    defaut?: any, // ATTENTION: Valeur déjà sérialisée
    autoIncrement: boolean,

    association?: TAssociation
}

/*----------------------------------
- TYPES: ASSOCIATION
----------------------------------*/

// Associaiton complète
export type TAssociation = TAssociationLibre | TAssociationQuery | TAssociationRelationComplete;

// Une association est dite libre quand tous ses critères seront définis exclusivement au moment de la requete
export type TAssociationLibre = {
    mode: 'libre',
    type: TTypeAsso,
    pk?: string[]
}

export type TAssociationQuery = {
    mode: 'query',
    type: TTypeAsso,
    query: QueryParser
}

export type TAssociationRelation = {
    mode: 'relation',
    type: TTypeAsso,
    reverse?: boolean, // true: la pk appartient à l'associé, et la fk appartient au modèle actuel (valeur par défaut pour hasmany)
    required?: boolean,
    where?: TCondition
}

export type TAssociationRelationComplete = (TAssociationRelation & {
    pk: TMetasColonne,
    fk: TMetasColonne,
    getModel?: undefined,
    table?: TMetasTable,
    modele?: TModelMetas,
})

export type TMetasApi = {
    auth: string,
    //unite?: ValueOf<typeof TWallet>,
    async?: boolean,
    entree?: (val: any) => string | number,
    sortie?: (val: any) => string | number,
    socket?: boolean
}

/*----------------------------------
- LIB
----------------------------------*/

const regParamsTypeSql = /\'([^\']+)\'\,?/gi;

export default async function loadMetadata( toLoad: Set<string>, connection: mysql.Pool ) {
    
    console.info(`${toLoad.size} databases to load`);
    if (toLoad.size === 0)
        return {};

    const dbNames = Array.from(toLoad);
    const dbColumns = await queryMetadatas(dbNames, connection);

    const metas = importTables(dbColumns);

    // Traitement une fois que toutes les tables sont connues
    buildAssociations(metas);

    console.log(`Databases are loaded.`);
    toLoad.clear();

    return metas;
}

async function queryMetadatas( databases: string[], connection: mysql.Pool ) {
    console.log(`Loading tables metadatas for the following databases: ${databases.join(', ')} ...`);
    return (await connection.query(`
        SELECT

            /* Provenance */
            col.TABLE_SCHEMA as 'database',
        col.TABLE_NAME as 'table',
        col.COLUMN_NAME as 'colonne',

        /* Options */
        col.COLUMN_DEFAULT as 'defaut',
        col.IS_NULLABLE as 'nullable',
        col.COLUMN_TYPE as 'type',
        col.COLUMN_KEY as 'cle',
        col.EXTRA as 'extra',

        asso.REFERENCED_TABLE_NAME as 'assoTable',
        asso.REFERENCED_COLUMN_NAME as 'assoCol',

        contrainte.UPDATE_RULE as 'onUpdate',
        contrainte.DELETE_RULE as 'onDelete'

        /* Colonnes */
        FROM information_schema.COLUMNS col

        /* Associations pk - fk */
        LEFT JOIN information_schema.KEY_COLUMN_USAGE asso ON
            asso.REFERENCED_TABLE_SCHEMA = col.TABLE_SCHEMA
            AND
            asso.REFERENCED_TABLE_NAME = col.TABLE_NAME
            AND
            asso.REFERENCED_COLUMN_NAME = col.COLUMN_NAME

        /* Contraintes */
        LEFT OUTER JOIN information_schema.REFERENTIAL_CONSTRAINTS contrainte ON
            contrainte.CONSTRAINT_SCHEMA = col.TABLE_SCHEMA
            AND
            contrainte.TABLE_NAME = col.TABLE_NAME
            AND 
            contrainte.CONSTRAINT_NAME IS NOT NULL
            AND
            contrainte.CONSTRAINT_NAME = asso.CONSTRAINT_NAME

        WHERE col.TABLE_SCHEMA IN(${databases.map(d => '"' + d + '"').join(', ')})
    `))[0] as TDatabaseColumn[];
}

function importTables(dbColumns: TDatabaseColumn[]) {

    console.log(`Processing ${dbColumns.length} rows of metadatas`);

    const metas: TDatabasesList = {};

    for (const {
        database, table: nomTable, colonne: nomColonne,
        defaut, nullable, type, cle, extra,
        assoTable, assoCol,
        onUpdate, onDelete
    } of dbColumns) {

        if (metas[database] === undefined)
            metas[database] = {}

        // Indexage de la table si pas déjà fait
        if (metas[database][nomTable] === undefined)
            metas[database][nomTable] = {
                loaded: true,
                database: database,
                alias: nomTable.toLowerCase(),
                nom: nomTable,
                chemin: '`' + database + '`.`' + nomTable + '`',
                colonnes: {},
                associations: { all: [], hasone: [], hasmany: [] },
                pk: [],
                default: false,
                modele: undefined
            }

        // Extraction des informations
        const table = metas[database][nomTable];
        const { nomType, paramsType } = parseColType(type);

        // Indexage clés primaires
        const primaire = cle === 'PRI';
        if (primaire && !table.pk.includes(nomColonne))
            table.pk.push(nomColonne);

        // Forme temporaire car toutes les tables n'ont pas encre été référencées
        let association: TAssociation | undefined;
        if (assoTable !== null && assoCol !== null) {
            association = {
                table: assoTable,
                colonne: assoCol,
                contrainte: {
                    onUpdate,
                    onDelete
                }
            }
        }

        // Indexage de la colonne
        table.colonnes[nomColonne] = {
            attached: true,
            table: metas[database][nomTable],
            nom: nomColonne,
            primary: primaire,
            autoIncrement: extra.includes('auto_increment'),
            nullable: nullable === 'YES',
            defaut: defaut === null ? undefined : defaut,

            type: nomType,
            typeParams: paramsType,

            association
        }

    }

    return metas;
    
}

function parseColType(brut: string) {

    let nomType: TMetasColonne["type"];
    let paramsType: TMetasColonne["typeParams"] = [];

    const posParenthese = brut.indexOf('(');
    if (posParenthese === -1)
        nomType = brut.toUpperCase() as TMetasColonne["type"];
    else {
        nomType = brut.substring(0, posParenthese).toUpperCase() as TMetasColonne["type"];

        // Extraction paramètres du type entre les parentheses
        const paramsStr = brut.substring(posParenthese + 1, brut.length - 1)
        let m;
        do {
            m = regParamsTypeSql.exec(paramsStr);
            if (m)
                paramsType.push(m[1]);
        } while (m);
    }

    return { nomType, paramsType }

}

function buildAssociations( metas: TDatabasesList ) {
    console.info(`Building associations between tables`);
    for (const database in metas)
        for (const nomTable in metas[database]) {
            const table = metas[database][nomTable]

            for (const nomCol in table.colonnes) {
                const colonne = table.colonnes[nomCol]

                // Association = référence vers colonne concernée
                const asso = colonne.association as unknown as { table: string, colonne: string, contrainte: TContrainteColonne };
                if (asso !== undefined) {

                    // Verif existance
                    const erreurAsso = (msg: string) => new Error(`Impossible de créer l'association ${database}.${nomTable}.${nomCol} => ${database}.${asso.table}.${asso.colonne}: ` + msg);
                    if (metas[database][asso.table] === undefined)
                        throw erreurAsso(`La table ${asso.table} n'a pas été répertoriée dans metas[${database}] (Tables connues: ${Object.keys(metas[database])})`);
                    if (metas[database][asso.table].colonnes[asso.colonne] === undefined)
                        throw erreurAsso(`La colonne ${asso.colonne} n'a pas été répertoriée dans metas[${database}][${asso.table}].colonnes (Colonnes connues: ${Object.keys(metas[database][asso.table].colonnes)})`);

                    // Création référence
                    const colonneAssociee = metas[database][asso.table].colonnes[asso.colonne];
                    colonne.association = {
                        mode: 'relation',
                        type: 'hasone',
                        fk: colonne,
                        pk: colonneAssociee,

                        contrainte: asso.contrainte
                    }

                    // Indexage
                    table.associations.all.push(nomCol);
                    table.associations.hasone.push(nomCol);

                }
            }
        }
}