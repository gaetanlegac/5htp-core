/*----------------------------------
- DEPENDANCES
----------------------------------*/

// Npm
import dayjs from 'dayjs';
import mysql, { ResultSetHeader } from 'mysql2/promise';
import dottie from 'dottie';

// Core: specific
import Query from './query';
import QueryRunner, { printQuery, TOptsExecQuery } from './jsql/query/runner';
import { TOptsQueryParser } from './jsql/query/base';
import loadDatabases, { TDatabasesList } from './metas';

// Core: general
import app from '@server/app';
import { arrayToObj, TOptsArrayToObj } from '@common/data/tableaux';
import { buildStats, TPeriodeStats } from '@common/data/stats';
import { Introuvable } from '@common/errors';

/*----------------------------------
- TYPES
----------------------------------*/

export { Op, Sql } from './query';

/*----------------------------------
- DEFINITIONS TYPES
----------------------------------*/

type TConfig = {
    host: string,
    database: string,
    login: string,
    password: string,
    port: number
}

export type TOptsQuery = {
    simuler?: true,
    data?: TObjDonnees,
    structurer?: boolean,
    orig?: Query
}

export type TOptsSelectQuery = TOptsQuery & TOptsArrayToObj;

type TObjDonnees = { [cle: string]: any }

export const sepPks = '-'; // Symbole de séparation en cas de p composée







export type SqlQuery = ReturnType<typeof sql>;

export const sql = (strings: TemplateStringsArray, ...data: any[]) => {

    const query = sql.string(strings, ...data);
    console.log('QUERY', query);
    
    const defaultOpts = { structurer: true }

    const run = () => database.select(query, undefined, defaultOpts);
    run.all = run;
    run.then = (cb: (data: any) => void) => run().then(cb);
    run.first = () => database.first(query, undefined, defaultOpts);
    run.value = () => database.selectVal(query, undefined, defaultOpts);
    run.count = () => database.selectVal('SELECT COUNT(*) FROM ' + query, undefined, defaultOpts);
    run.firstOrFail = () => database.firstOrFail(query, undefined, defaultOpts);
    run.stats = (periodStr: string, intervalStr: string, columns: string[]) => database.select(query, undefined).then(
        results => buildStats(periodStr, intervalStr, results)
    )
    run.string = query;

    return run;
}

sql.string = (strings: TemplateStringsArray, ...data: any[]) => {
    const iMax = data.length - 1;
    return strings.map((s, i) => {

        if (i <= iMax) {

            let d = data[i];
            if (s[s.length - 1] === ':') // `SET :${column} = ${data}` => `SET balance = 10`
                s = s.substring(0, s.length - 1);
            else if (typeof d === 'function' && d.string !== undefined)
                d = d.string;
            else
                d = mysql.escape(d);

            s += d;

        }

        return s;

    }).join(' ').trim();
}

sql.bulk = (queries: (SqlQuery | string)[]) => {
    const allqueries = queries.map(q => typeof q === "string" ? q : q.string).join(';\n');
    console.log("Bulk query", allqueries);
    return database.query(allqueries);
}

/*----------------------------------
- SERVICES
----------------------------------*/
export class Database {

    public connection!: mysql.Pool;
    public toLoad = new Set<string>()
    public tables: TDatabasesList = {}

    private config = app.config.services.database as TConfig;

    /*----------------------------------
    - HOOKS
    ----------------------------------*/
    public constructor() {

        app.register(this);
        app.on('cleanup', () => this.cleanup());

    }

    public loading: Promise<void> | undefined = undefined;
    public async load() {

        this.connection = await this.connect();

        this.tables = await loadDatabases( this.toLoad, this.connection );

    }

    public async cleanup() {
        return this.connection.end();
    }

    /*----------------------------------
    - INIT
    ----------------------------------*/
    public async connect() {

        console.info(`Connecting to databases ...`);

        return await mysql.createPool({

            // Identification
            host: this.config.host,
            port: this.config.port,
            user: this.config.login,
            password: this.config.password,
            database: this.config.database,

            // Pool
            waitForConnections: true,
            connectionLimit: 100,
            queueLimit: 0,

            // Dates & timezone
            dateStrings: true,
            timezone: "+02:00", // Utilise le timezone du serveur

            // Gestion types données personnalisées
            typeCast: true,

            // Transforme les décimaux en flottants (par d"faut, mysql retourne une chaine)
            // https://github.com/sidorares/node-mysql2/tree/master/documentation#known-incompatibilities-with-node-mysql
            decimalNumbers: true,

            // Permet lusieurs requetes en une
            multipleStatements: true,

            queryFormat: function (query, values) {
                //console.info('queryFormat', query);
                return query;
            }
        });
    }

    /*----------------------------------
    - QUERIES: BASIC
    ----------------------------------*/
    public async query(
        requete: string,
        donnees: TObjDonnees = {},
        opts: TOptsQuery = {}
    ) {

        await this.loading;

        const debut = new Date().getTime();

        //console.log('SQL', sqlFormatter.format(requete, { indent: ' '.repeat(4) }), donnees);
        
        // remplacement des placeholders
        // TODO: Virer, utiliser JSQL dés que possible (mise en cache + meilleur deboguage + meilleure gestion des erreurs)
        const nomDonnees = Object.keys(donnees);
        if (nomDonnees.length !== 0)
            requete = requete.replace(
                new RegExp(':\\b(' + nomDonnees.join('|') + ')\\b', 'g'),
                (all: string, cle: string) => {

                    let valeur = donnees[cle]

                    // Liste
                    // ['static', 'interactive'] => ('static', 'interactive')
                    if (Array.isArray(valeur))
                        return '(' + valeur.map(v => mysql.escape(v)).join(', ') + ')'
                    // Objet = json
                    else if (typeof valeur === 'object' && valeur !== null && valeur.constructor === Object)
                        valeur =  JSON.stringify(valeur);

                    return mysql.escape(valeur)

                }
            );

        //console.log( printQuery(requete), donnees );

        if (opts.simuler === true)
            return;

        // Lancement de la requête
        let [rows, fields] = await this.connection.query(requete, donnees);

        if (opts.structurer !== false)
            rows = dottie.transform(rows);

        return rows;
    }

    /*----------------------------------
    - QUERIES: RETRIEVE
    ----------------------------------*/

    public jsql = async (
        jsql: string,
        data: TObjDonnees = {},
        optsQuery: TOptsExecQuery = {},
        optsParser: TOptsQueryParser = {},
    ) => {

        // Parsing
        const query = new QueryRunner(jsql, {
            ...(data || {}),
            ...(optsQuery.data || {})
        }, {
            ...optsQuery,
            ...optsParser
        })

        // Execution
        return await query.exec({}, {
            raw: true
        })

    }

    public select = (requete: string, donnees: TObjDonnees = {}, opts: TOptsSelectQuery = {}) =>
        this.query(requete, donnees, opts).then((resultats: any) => {

            return arrayToObj(resultats, opts);

        });

    public first = (requetes: string, donnees: TObjDonnees = {}, opts?: TOptsQuery) =>
        this.query(requetes, donnees, opts).then((resultatRequetes: any) => {

            return resultatRequetes[0];

        });

    public firstOrFail = (requetes: string, donnees: TObjDonnees = {}, opts?: TOptsQuery) =>
        this.query(requetes, donnees, opts).then((resultatRequetes: any) => {

            if (resultatRequetes.length === 0)
                throw new Introuvable();

            return resultatRequetes[0];

        });

    public selectVal = (requetes: string, donnees: TObjDonnees = {}, opts?: TOptsQuery) =>
        this.query(requetes, donnees, opts).then((resultatRequetes: any) => {

            const resultat = resultatRequetes[0];

            if (!resultat)
                return undefined;

            return Object.values(resultat)[0];

        });

    public selectMulti = (requetes: string, donnees: TObjDonnees = {}, opts?: TOptsQuery) =>
        this.query(requetes, donnees, opts).then((resultatRequetes: any) => {

            let retour: TObjDonnees = {};
            for (const resultatRequete of resultatRequetes) {
                const ctor = resultatRequetes.constructor;


                // NOTE: Parmi les résultats se trouvent des métadonnées sur les colonnes retournées (instance de ResultHeader, etc ...)
                //  On filtre donc par constructeur
                
                if (ctor === Object) {

                    for (const nomDonnee in resultatRequete)
                        retour[nomDonnee] = resultatRequete[nomDonnee];

                } else if (ctor === Array) {

                    for (const nomDonnee in resultatRequete[0])
                        retour[nomDonnee] = resultatRequete[0][nomDonnee];

                }
            }
                
            return retour;

        });

    public stats = async (
        [debut, fin]: TPeriodeStats,
        jsql: string,
        data: TObjDonnees = {},
        optsQuery: TOptsExecQuery = {},
    ) => {

        const stats = await this.jsql(jsql, { ...data, debut, fin }, optsQuery);

        return buildStats([debut, fin], stats);

    }

    /*----------------------------------
    - QUERIES: WRITE
    ----------------------------------*/

    public async exists(table: string, where: TObjDonnees = {}, opts?: TOptsQuery) {

        const egalitesWhere = Object.keys(where).map(k => '`' + k + '` = :' + k).join(' AND ')

        const result = await this.query(`
            SELECT COUNT(*) as count FROM ${table} WHERE ${egalitesWhere}
        `, where);

        // @ts-ignore
        return result[0].count !== 0;

    }

    public async insert(table: string, data: TObjDonnees = {}, opts?: TOptsQuery) {

        const egalitesProduct = Object.keys(data).map(k => '`' + k + '` = :' + k).join(', ')

        const inserted = await this.query(`
            INSERT INTO ${table} SET ${egalitesProduct}
        `, data);

        // @ts-ignore
        return inserted.insertId;

    }


    public async tryInsert(table: string, data: object) {

        const egalitesProduct = Object.keys(data).map(k => '`' + k + '` = :' + k).join(', ')
        
        const inserted = await this.query(`
            INSERT IGNORE INTO ${table} SET ${egalitesProduct}
        `, data);

        // @ts-ignore
        return inserted.insertId;
    }

    public async upsert(table: string, data: object, toUpdate?: string[]) {

        if (toUpdate === undefined)
            return await this.tryInsert(table, data);

        const egalitesInsert = Object.keys(data).map(k => '`' + k + '` = :' + k).join(', ')
        const egalitesUpdate = toUpdate.map(k => '`' + k + '` = :' + k).join(', ')

        const inserted = await this.query(`
            INSERT INTO ${table} SET ${egalitesInsert}
            ON DUPLICATE KEY UPDATE ${egalitesUpdate}
        `, data);

        // @ts-ignore
        return inserted.insertId;
    }

    public update = (table: string, data: TObjDonnees, where: TObjDonnees, opts?: TOptsQuery) => {

        const egalitesData = Object.keys(data).map(k => '`' + k + '` = :' + k).join(', ')
        const egalitesWhere = Object.keys(where).map(k => '`' + k + '` = :' + k).join(' AND ')

        return this.query(`
            UPDATE ${table} SET ${egalitesData} WHERE ${egalitesWhere}
        `, { ...data, ...where }) as Promise<ResultSetHeader>;

    }
    
    public delete = (table: string, where: TObjDonnees = {}, opts?: TOptsQuery) => {

        const egalitesWhere = Object.keys(where).map(k => '`' + k + '` = :' + k).join(' AND ')

        return this.query(`
            DELETE FROM ${table} WHERE ${egalitesWhere}
        `, where) as Promise<ResultSetHeader>;

    }

}

const database = new Database
export default database;