/*----------------------------------
- DEPENDANCES
----------------------------------*/

// Libs
import Modele from '../../models';
import Db from '..'
import { ErreurSaisie } from '@common/errors';

/*----------------------------------
- TYPES
----------------------------------*/

/*----------------------------------
- FONCTIONS
----------------------------------*/
// MANY TO MANY (Basé sur majTags)
export async function majDifferencielle(
    elements: { 
        modele: typeof Modele, 
        liste: string[], 
        colonne: string, // Colonne depuis laquelle proviennent les données de liste (id, nom, ...)
        creer: boolean
    },
    association: {
        modele: typeof Modele,
        criteres?: {[cle: string]: any}
    },
    associe: { 
        modele: typeof Modele, 
        id: number 
    }
): Promise<void> {

    const simuler = false;

    if (association.criteres === undefined)
        association.criteres = {};
    association.criteres[ associe.modele.name + '_id' ] = associe.id;

    let whereStr: string[] = [];
    for (const nomCritere in association.criteres)
        whereStr.push('tp.' + nomCritere + ' = :' + nomCritere);

    // Récupération de la liste des elements actuellement associés
    const anciensElements: string[] = (await Db.select(`
        SELECT t.${elements.colonne} FROM ${elements.modele.metas.tables.default.chemin} t
        INNER JOIN ${association.modele.metas.tables.default.chemin} tp
            ON tp.${elements.modele.name}_id = t.id
        WHERE ${whereStr.join(' AND ')}
    `, association.criteres)).map(
        // La liste des élements pouvant provenir d'une saisie utilisateur,
        // On normalise tous les ids en chaine afin d'éviter les problèmes de comparaisons ('1' !== 1)
        (tag: object) => ('' + tag[ elements.colonne ]) as string
    );

    // Détermination action pour chaque élement
    const elementsAcreer: string[] = elements.liste.filter(
        (tag) => !anciensElements.includes(tag)
    );
    const elementsAgarder: string[] = anciensElements.filter(
        (tag: string) => elements.liste.includes( tag )
    );
    const elementsAsupprimer: string[] = anciensElements.filter(
        (tag: string) => !elements.liste.includes( tag )
    );

    console.log(`[Maj différencielle]`, anciensElements, '=>', elements.liste);
    console.log(`[Maj différencielle] Créer: `, elementsAcreer);
    console.log(`[Maj différencielle] Garder: `, elementsAgarder);
    console.log(`[Maj différencielle] Supprimer: `, elementsAsupprimer);

    if (simuler) return;
    let promisesMaj: Promise<any>[] = [];

    // Créations
    if (elementsAcreer.length !== 0) {

        // Dans tous les cas, besoin de l'id pour assurer l'association Many To Many
        let champsSelect: string, identificateursSelect: string;
        if (elements.colonne === 'id') {
            champsSelect = elements.colonne;
            identificateursSelect = elementsAcreer.join(', ');
        } else {
            champsSelect = elements.colonne + ', id';
            identificateursSelect = elementsAcreer.map((e) => "'" + e + "'").join(', ');
        }

        // Récupération de l'id des élements à creer
        const elementsExistants = await Db.select(`
            SELECT ${champsSelect} FROM ${elements.modele.metas.tables.default.chemin}
            WHERE ${elements.colonne} IN (${identificateursSelect})
        `, {}) as {[cle: string]: any}[];
         // On ignore les différnces de type
        const getElemExistant = (id: string) => elementsExistants.find((elem) => elem[ elements.colonne ] == id);

        //console.log('elementsExistants', elementsExistants, 'elementsAcreer', elementsAcreer);

        // Si pas autorisé à créér les élements s'ils n'existent pas
        if (!elements.creer)
            // Verif si toutes les associations à créer existent
            for (const aCreer of elementsAcreer)
                if (getElemExistant(aCreer) === undefined)
                    throw new ErreurSaisie(`L'élement ${elements.modele.name} portant pour ${elements.colonne} « ${aCreer} » est introuvable. Vos modifications n'ont pas été enregistrées.`);

        // Création des associations, et éventuellement des élements
        for (const aCreer of elementsAcreer) promisesMaj.push(
            (async () => {
            
                // Création si pas existant
                let elementExistant = getElemExistant(aCreer);
                if (elements.creer && elementExistant === undefined)
                    elementExistant = await elements.modele.create({
                        [elements.colonne]: aCreer
                    });

                // Erreur lors de la création
                if (elementExistant === undefined)
                    throw new Error(`Impossible de créer l'élement ${elements.modele.name} portant pour ${elements.colonne} « ${aCreer} »`);

                // Association avec l'objet en question
                console.log(`[Maj différencielle]`, elementExistant ? 'Nouveau' : 'Existant', aCreer, `. Creation association ${elements.modele.name}(${elementExistant.id}) => ${associe.modele.name}(${associe.id})`);
                const nomCriteres = Object.keys(association.criteres);
                await Db.insert(`
                    INSERT INTO ${association.modele.metas.tables.default.chemin}
                    (${elements.modele.name}_id, ${nomCriteres.join(', ')})
                    VALUES(:idElement, ${nomCriteres.map((nomCritere: string) => ':' + nomCritere).join(', ')})
                `, {
                    idElement: elementExistant.id,
                    ...association.criteres
                });
    
            })()
        );
    }

    // Suppressions
    if (elementsAsupprimer.length !== 0) {

        console.log(`[Maj différencielle]`, 'Suppression de', elementsAsupprimer);

        promisesMaj.push(
            Db.delete(`
                DELETE tp FROM ${association.modele.metas.tables.default.chemin} tp
                INNER JOIN ${elements.modele.metas.tables.default.chemin} t ON t.id = tp.${elements.modele.name}_id
                WHERE
                    t.${elements.colonne} IN (:elements)
            `, {
                elements: elementsAsupprimer
            })
        )
    }

    if (promisesMaj.length !== 0)
        await Promise.all(promisesMaj);
    else
        console.log(`[Maj différencielle]`, 'Aucune action à effectuer');
}

// MANY TO ONE (Basé sur majTags)
type TElement = { id: string, [cle: string]: any };
export async function majDifferencielleOTM(
    elements: { 
        modele: typeof Modele, 
        liste: TElement[]
    },
    associe: { 
        modele: typeof Modele, 
        id: number 
    }
): Promise<void> {

    const simuler = false;

    // Récupération de la liste des elements actuellement associés
    const anciensElements = (await Db.select(`
        SELECT id FROM ${elements.modele.metas.tables.default.chemin}
        WHERE ${associe.modele.name}_id = :${associe.modele.name}
    `, {
        [associe.modele.name]: associe.id
    })).map(
        // La liste des élements pouvant provenir d'une saisie utilisateur,
        // On normalise tous les ids en chaine afin d'éviter les problèmes de comparaisons ('1' !== 1)
        (e) => '' + e.id
    ) as string[];

    // Détermination action pour chaque élement
    const elementsAcreer: TElement[] = elements.liste.filter(
        (element) => !element.id
    );
    const elementsAgarder: string[] = anciensElements.filter(
        (ancienElement) => elements.liste.some(
            (nouvelElement) => ancienElement === nouvelElement.id
        )
    );
    const elementsAsupprimer: string[] = anciensElements.filter(
        (ancienElement) => !elements.liste.some(
            (nouvelElement) => ancienElement === nouvelElement.id
        )
    );

    console.log(`[Maj différencielle]`, anciensElements, '=>', elements.liste);
    console.log(`[Maj différencielle] Créer: `, elementsAcreer);
    console.log(`[Maj différencielle] Garder: `, elementsAgarder);
    console.log(`[Maj différencielle] Supprimer: `, elementsAsupprimer);

    if (simuler) return;
    let promisesMaj: Promise<any>[] = [];

    // Créations
    if (elementsAcreer.length !== 0) {

        // Verif si les élement dont l'id est spécifié existe bien
        const idElementsAcreer = elementsAcreer.filter( (e) => !!e.id ).map( (e) => e.id );
        if (idElementsAcreer.length !== 0) {

            // Récupération de l'id des élements à creer
            const elementsExistants = await Db.select(`
                SELECT id FROM ${elements.modele.metas.tables.default.chemin}
                WHERE id IN (${idElementsAcreer.join(', ')})
            `, {}) as {[cle: string]: any}[];
            const getElemExistant = (id: number) => elementsExistants.find((elem) => elem.id === id);

            // Verif si toutes les associations à créer existent
            for (const aCreer of elementsAcreer)
                if (aCreer.id && getElemExistant(aCreer.id) === undefined)
                    throw new ErreurSaisie(`L'élement ${elements.modele.name} portant pour id « ${aCreer.id} » est introuvable. Vos modifications n'ont pas été enregistrées.`);

            console.log('elementsExistants', elementsExistants);
            
        }

        promisesMaj = elementsAcreer.map(({ id, ...aCreer }) => id === undefined
            // Création
            ? elements.modele.create(aCreer)
            // Modification
            : elements.modele.update(aCreer, { where: { id } })
        );
    }

    // Suppressions
    if (elementsAsupprimer.length !== 0) {

        console.log(`[Maj différencielle]`, 'Suppression de', elementsAsupprimer);

        promisesMaj.push(
            Db.delete(`
                DELETE FROM ${elements.modele.metas.tables.default.chemin}
                WHERE id IN (:elements)
            `, {
                elements: elementsAsupprimer
            })
        )
    }

    if (promisesMaj.length !== 0)
        await Promise.all(promisesMaj);
    else
        console.log(`[Maj différencielle]`, 'Aucune action à effectuer');
}