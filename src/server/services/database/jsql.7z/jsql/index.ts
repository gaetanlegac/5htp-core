/*
    * \u00c9criture et utilisation de vues et procédures
    * Meilleures performances:
        - Vues et procédures préenregistrées auprès de MySQL
        - Mise en cache requêtes
    * Flexibilité : tout le potentiel de MySQL + aucun problème pour construire des requêtes SQL complexes
    * Facilitation débogage
*/