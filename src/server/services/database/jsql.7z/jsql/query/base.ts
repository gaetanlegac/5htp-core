/*----------------------------------
- DEPENDANCES
----------------------------------*/

// Npm
const getUuid = require('uuid-by-string')
import { format as formatSql } from 'sql-formatter';
import highlight from 'cli-highlight';
import { escape } from 'mysql2/promise';

// Core: specific
import { objToJsql, TQueryAbstraite } from '../parser/abstraction';

import factories, {
    keywords, TTypeInstruction,
    Select, From, Join, Where, Order, Group, Limit, Having, With,

    JoinContainer, WithContainer
} from '../factories';

import { TListeChamps, TInstructionBrute } from '../factories/base';

// Constantes
import { regParamExterne, regReferences } from '../parser/regex';

// Core: general
import semantique, { TBlock } from '@common/data/chaines/semantique';

/*----------------------------------
- TYPES
----------------------------------*/

import type { TImportedQuery } from './runner'

export type TListeParams = {
    [nom: string]: {
        type: string
    }
}

const ordreQuery: TTypeInstruction[] = [
    'select',
    'from',
    'join',
    'where',
    'having',
    'group',
    'order',
    'limit',
]

const typesScopes2: {
    type: string,
    start: string,
    class: string
}[] = []
for (const keyword in keywords)
    typesScopes2.push({
        type: keywords[keyword],
        start: keyword,
        class: 'instruction'
    })

/*----------------------------------
- TYPES OPTIONS
----------------------------------*/
export type TOptsQueryParser = Partial<Pick<QueryParser, 'parametres' | 'type' | 'id' | 'sourceFile'>>


export type TContexteQuery = {
    prefixe?: string,
    arguments?: { [nom: string]: string | number | boolean },
    replacements?: {[placeholder: string]: string}
}

/*----------------------------------
- TYPES: PARSER
----------------------------------*/
export type TScopeResult = {
    sql: string,
    instructions: TInstructionsBrutes,
    subqueries: { [id: string]: QueryParser },
}

export type TTypeQuery = 'scope'

export type TParseResult = {
    id: string,
    source: string,
    instructions: TInstructionsBrutes,
    type?: TTypeQuery,
    chemin?: string
}

export type TInstructionsBrutes = Partial<{
    [type in TTypeInstruction]: TInstructionBrute< typeof factories[type]["keywords"][number]>[]
}>

/*----------------------------------
- OUTILS
----------------------------------*/
export const printQuery = (requete: string) => highlight(
    formatSql(requete, { indent: ' '.repeat(4) }),
    { language: 'sql', ignoreIllegals: true }
)

/*----------------------------------
- SERVICE
----------------------------------*/
export default class QueryParser {

    private static cache: { [id: string]: QueryParser } = {}
    private static fileToId: { [file: string]: string } = {}

    /*----------------------------------
    - INIT
    ----------------------------------*/
    public readonly id: string;
    public readonly sourceFile?: string;
    public readonly source: string;
    public readonly type?: TTypeQuery;

    // Options
    public readonly parent?: QueryParser;
    public readonly parametres: TListeParams = {} // Liste des paramètres attendus avec leur type

    // Généré lors du traitement
    private sql?: string;
    // Cumule toutes les références accessibles dans le contexte actuel (query actuelle + query mère)
    public references: { [chemin: string]: Join } = {};

    // Factories
    public select: Select = new Select(this);
    public from?: From; // N'est pas renseigné quand on a une sous-requete simple. Ex: SELECT 0
    public with: WithContainer = new WithContainer(this);
    public join: JoinContainer = new JoinContainer(this);
    public where: Where = new Where(this);
    public order: Order = new Order(this);
    public group: Group = new Group(this);
    public limit: Limit = new Limit(this);
    public having: Having = new Having(this);

    // Liste totale du nom des champs importés (y compris ceux issus des wildcard)
    // Nom => alias provenance 
    public colonnes: TListeChamps = {};

    // Etat
    private built: boolean = false;
    public replacements: object = {};
    public data: object = {};
    // Regex simplifié pour de meilleures performances lors de l'execution d'une query
    // undefined = pas encore déterminé
    // null = aucun paramètre à remplacer
    private regexParams: RegExp | undefined | null;

    /*----------------------------------
    - INIT
    ----------------------------------*/

    public log = (...args: any[]) => console.log(`[database][query][` + this.id + `][parser]`, ...args);

    public static fromId( id: string ) {

        const query = QueryParser.cache[id];
        if (query === undefined)
            throw new Error(`Impossible de restituer la query ${id}, car elle n'a pas été trouvée dans la liste des subqueries de la requete actuelle.`)
        query.prebuild();

        return query;

    }

    public static parse(source: string | TImportedQuery | TQueryAbstraite, { id: idCustom, ...opts }: TOptsQueryParser = {}): QueryParser {

        // SQL via import = extraction métadonnées
        if (source instanceof String) {

            if (source.id !== undefined)
                idCustom = source.id;
            if (source.sourcefile !== undefined)
                opts.sourceFile = source.sourcefile;

            // Plus besoin de conserver les métadonnées
            source = source.toString();

        // Objet abstraction
        } else if (typeof source === 'object') {

            ({ jsql: source, /*data: this.data*/ } = objToJsql(source));

        }

        source = source.trim();
        if (source.length === 0)
            throw new Error(`La requete est vide.`);

        // Cache
        const id = idCustom !== undefined ? idCustom : getUuid(source, 3);;
        if (QueryParser.cache[id] !== undefined)
            return QueryParser.cache[id];

        // Interpretation
        const ast = semantique(source, {
            keywords: typesScopes2,
            debug: false,
            onBegin: (bloc) => {

                if (bloc.keyword?.class === 'instruction') {

                    if (bloc.parent.type !== 'query') {
                        bloc.parent.type = 'query';
                    }

                    if (bloc.type === 'select')
                        // Force le regroupement des instructions n'étant pas séparées par une virgule
                        bloc.isList = true;

                }

            },
            onClose: (bloc) => {

                if (bloc.type === 'query') {

                    // Indexage des instructions par type
                    let instructions: TInstructionsBrutes = {}
                    for (const child of bloc.content) {

                        if (typeof child === 'string') {
                            console.log("Source erreur:", source);
                            throw new Error(`Un bloc query est censé ne contenir que des blocs de type instruction. Un bloc de type chaine été trouvé (Contenu: \u00ab ${child} \u00bb). Source complète ci-dessus`);
                        }
                        if (child.keyword.class !== 'instruction') {
                            console.log("Source erreur:", source);
                            throw new Error(`Un bloc query est censé ne contenir que des blocs de type instruction. Un bloc de type \u00ab ${bloc.type} \u00bb a été trouvé. `);
                        }

                        // Init type
                        if (instructions[child.type] === undefined)
                            instructions[child.type] = []

                        let data: any;
                        // TODO: Passer liste champs sélectionnés / arguments from / arguments join
                        //  Problème: L'index de la liste des argument sera-t-il toujours le même ppour from et join ?
                        //  Attention: Màj également la valeur par défaut de SELECT (ainsi que toutes les constantes ayant pour type TInstructionBrute)
                        /*switch (child.type) {
                            case 'select':
                                data = child.content.map(c => blockToString(c))
                                break;
                        }*/

                        instructions[child.type].push({
                            keyword: child.keyword?.start,
                            sql: child.raw,
                        });

                    }

                    // Récupèration de la requête mère (s'il y a)
                    let parentQuery: TBlock | undefined = bloc.parent;
                    while (parentQuery !== undefined) {
                        if (parentQuery.type === 'query')
                            break;
                        parentQuery = parentQuery.parent;
                    }

                    // Requete racine
                    const racine = parentQuery === undefined;

                    // Instanciation query
                    const idSubquery = racine ? id : getUuid(bloc.raw, 3);
                    if (QueryParser.cache[idSubquery] === undefined) {

                        QueryParser.cache[idSubquery] = new QueryParser({
                            id: idSubquery,
                            source: bloc.raw,
                            instructions: instructions,
                        }, racine ? opts : undefined);

                    }

                    bloc.query = QueryParser.cache[idSubquery];

                    // Remplacement par la référence à l'idSubquery
                    bloc.raw = '{' + idSubquery + '}'
                    // Vire les délimiteurs
                    bloc.keyword = undefined;


                }

            }
        });

        if (ast.type !== 'query')
            throw new Error(`Erreur: Le parser a retourné un bloc de type \u00ab ${ast.type} \u00bb (type attendu: query)`);

        QueryParser.cache[id] = ast.query;

        // Extraction des paramètres attendus
        const regDefParam = /\*\s+@param (?<nom>[a-zA-Z]+) (?<type>[a-z]+)/g;
        let match: RegExpExecArray | null;
        while (match = regDefParam.exec(source)) {

            if (!match.groups) continue;

            const { nom, type } = match.groups;

            ast.query.parametres[nom] = { type };

        }

        // Association au chemin du fichier source
        if (opts.sourceFile !== undefined)
            QueryParser.fileToId[ opts.sourceFile ] = id;

        return QueryParser.cache[id];

    }

    // NOTE: Si QueryParser est une subquery, la hiérarchie a déjà été créée. 
    // Dans ce cas, on reprend le travail qui a djà été fait (= TBloc)
    public constructor({ id, source, instructions: instructionsBrutes }: TParseResult, opts: TOptsQueryParser = {}) {

        this.id = id;
        this.source = source;
        this.sourceFile = opts.sourceFile;

        this.importer(instructionsBrutes);

        this.parametres = opts.parametres || {}; // Liste des paramètres avec types (généré via header annotations des fichiers .sql)
        this.type = opts.type;

        // Dans les fichiers de scope, les paramètres attendus sont définis dans le header en commentaire
        // On peut donc générer le regex de remplacement des commentaires dés le départ
        // ATTENTION: Doit retourner les memes groupes que 
        if (this.type === 'scope')
            this.genRegexParams( Object.keys(this.parametres) );

    }

    /*----------------------------------
    - INSTRUCTIONS BRUTES
    ----------------------------------*/
    private genRegexParams(nomParams: string[]) {
        this.regexParams = nomParams.length === 0
            ? null
            : new RegExp(':(' + nomParams.join('|') + ')', 'g');
    }

    private importer(instructionsBrutes: TInstructionsBrutes) {
        let nomInstruction: TTypeInstruction;
        for (nomInstruction in instructionsBrutes) {

            const instructions = instructionsBrutes[nomInstruction];
            if (instructions === undefined) continue;

            for (const { keyword, sql } of instructions) {

                this.set(nomInstruction, keyword, sql);

            }
        }
    }

    public set(nomInstruction: TTypeInstruction, keyword: string, sql: string, opts: Omit<TInstructionBrute, 'sql' | 'keyword'> = {}) {

        //console.log('SET', (provenance_id === undefined ? '' : 'via ' + provenance_id), nomInstruction, printQuery( keyword + ' ' + sql));

        // Le dernier FROM écrase les anciens
        if (nomInstruction === 'from') {

            this.from = new From(this, sql);

        } else
            this[nomInstruction].add(keyword, sql, opts)
    }

    public mergeWith( query: QueryParser, args?: object, prefixe_in?: string, prefixe_out?: string) {
        
        // Si le from de la query est également une query (scope), 
        // on l'importe AVANT toutes les autres instructions
        // comme s'il était réféencé via un with
        if (query.from !== undefined && (query.from.table instanceof QueryParser)) {
            this.log(`Transformation de FROM ${query.id} en WITH ${query.id}`);
            this.mergeWith(query.from.table, {}, prefixe_in, prefixe_out);
        }

        // Importation des instructions
        let nomInstruction: TTypeInstruction;
        for (nomInstruction in factories) {

            const factory = query[nomInstruction]

            // On conserve le FROM d'origine
            if (nomInstruction === 'from' || factory === undefined)
                continue;

            // Ajout des instructions
            if (factory.isContainer === true)
                // Même si les containers conservent le raw, 
                // On préfèrera lrécupérer ce dernier via l'instance dédiée 
                // Pour être certain d'obtenir la version la plus actualisée du sql
                for (const alias in factory.liste)
                    for (const { keyword, sql } of factory.liste[ alias ].raw)
                        this.set(nomInstruction, keyword, sql, {
                            provenance_id: query.id, 
                            prefixe_in, 
                            prefixe_out
                        });
            else
                for (const { keyword, sql } of factory.raw)
                    this.set(nomInstruction, keyword, sql, {
                        provenance_id: query.id,
                        prefixe_in,
                        prefixe_out
                    });

        }

        // Importation des arguments
        if (args !== undefined) {
            for (const nomArg in args) {

                // Verif existance
                if (!( nomArg in query.parametres ))
                    throw new Error(`La requete ${query.id} n'accepte pas d'argument « ${nomArg} ». Arguments acceptés: ${Object.keys( query.parametres )}`);

                // Réféencement
                //this.data[ nomArg ] = args[nomArg];
                this.replacements[ nomArg ] = args[nomArg];

            }
        }

        return this;
    }

    /*----------------------------------
    - METADONNÉES INSTRUCTIONS
    ----------------------------------*/
    public static clearCache() {
        for (const file in this.fileToId) {
            const id = this.fileToId[file]
            console.log(`[database][query] Suppression du fichier ${file} du cache (ID: ${id})`);
            delete this.cache[id]
        }
    }

    public static prebuildCache() {
        for (const id in QueryParser.cache)
            QueryParser.cache[id].prebuild();
    }

    // Interprétation de chaque instruction en respectant l'ordre
    // Seulement nécessaire pour:
    // - Générer le sql
    // - Accéder à des informations relatives à une instruction
    public prebuild(opts?: TOptsQueryParser) {

        // Déjà prebuild
        // Si les factories sont relancés alors que déjà prebuilds, les instructions seront ajoutées en double (nottamment dans le select)
        if (this.built) {
            this.log(`query.prebuild() annulé: Déjà prebuild`);
            return;
        }

        let nomInstruction: TTypeInstruction;
        for (nomInstruction in factories) {

            const factory = this[nomInstruction]
            if (factory === undefined)
                continue;

            factory.parseInstructions();

        }

        // Aucune erreur, on peut le marquer comme built
        this.built = true;
    }

    public printDebugInfos( instruction?: string | TInstructionBrute ) {

        const raw = {}
        for (const factory of ordreQuery)
            if (this[factory] !== undefined)
                raw[factory] = this[factory].raw

        const sql = ordreQuery.map(
            (nomFactory) => this[nomFactory] === undefined ? '' : 
                this[nomFactory].raw.map(({ keyword, sql, provenance_id }) => 
                    (provenance_id !== undefined ? '/* Via ' + provenance_id + ' */ ' : '') + keyword + ' ' + sql
                ).join('\n')
        ).join('\n')

        this.log(`JSQL Source:\n`, printQuery(this.source));
        this.log(`Instructions brutes:`, raw);
        this.log(`JSQL brut:\n`, printQuery(sql));

        if (instruction !== undefined) {
            if (typeof instruction === 'string')
                this.log(`Instruction traitée:\n`, printQuery(instruction));
            else 
                this.log(`Instruction traitée:`, instruction, printQuery(instruction.keyword + ' ' + instruction.sql));
        }
    }

    /*----------------------------------
    - PRE-CONSTRUCTION DU SQL
    ----------------------------------*/
    // Génère le code SQL de base, remplace les paramètres locaux uniqueement et met le tout en cache
    public getBaseSql({ }: TContexteQuery = {}): string {

        if (this.sql !== undefined)
            return this.sql;

        this.prebuild();

        // Construction de chaque instruction avec respect de l'ordre original
        let morceaux: string[] = []

        for (const type of ordreQuery) {

            this.log(`Construction SQL ${type}`);
        
            // Certains factories, comme from, peuvent ne pas être instanciés
            if (this[type] === undefined)
                continue;

            const sqlComplet = this[type].getSql();
            if (sqlComplet !== undefined)
                morceaux.push(sqlComplet);
        }

        this.sql = morceaux.join(' ');

        // S'il y a des paramètres à remplacer
        let paramsManquant: string[] = []
        if (this.regexParams !== null) {

            // Si regexParams n'a pas encore été généré, on utilise le regex génériqu pour trouver les placeholders
            //  et ainsi générer regexParams
            //({ sql: this.sql, manquant: paramsManquant } = this.withParams( this.data ));
            ({ sql: this.sql, manquant: paramsManquant } = this.withParams( this.replacements, false ));

            // Plus aucun param à remplacer
            if (paramsManquant.length === 0)
                this.regexParams = null;
            // Génère le regex de remplacement pour les paramètres manquant
            else
                this.genRegexParams( paramsManquant );

        }

        return this.sql
    }

    public getSql({ prefixe, replacements }: TContexteQuery = {}): string {

        let sql = this.getBaseSql();

        // Remplacements JSQL brut
        if (replacements !== undefined) {
            this.log(`Remplacements`, replacements);
            ({ sql } = this.withParams(replacements, false, prefixe));
        }

        return sql;

    }

    public static prefixer(jsql: string, prefixe: string) {
        return jsql.replace(regReferences, (match: string, refParent: string, refParam: string, cheminComplet: string) => {
            return '$' + refParent + refParam + prefixe + '.' + cheminComplet
        });
    }

    public withParams( data: {[cle: string]: any}, shouldEscape: boolean = true, prefixe?: string ) {

        if (this.sql === undefined) this.sql = this.getSql()

        let paramsManquant: string[] = []
        const sql = this.sql.replace(this.regexParams || regParamExterne, (placeholder: string, nomParam: string) => {

            // Verif existance
            if (!(nomParam in data)) {
                paramsManquant.push(nomParam);
                return placeholder;
            }

            // Traitement de la valeur
            let valeur = data[nomParam];

            // undefined => NULL
            if (valeur === undefined)
                valeur = 'NULL';
            // Boolean
            else if (typeof valeur === 'boolean')
                valeur = valeur ? 1 : 0;
            // Liste
            // ['static', 'interactive'] => ('static', 'interactive')
            else if (Array.isArray(valeur))
                valeur = '(' + (shouldEscape ? valeur.map(v => escape(v)).join(', ') : valeur) + ')';
            // Valeur seule
            else if (shouldEscape === true)
                valeur = escape(valeur)
            // JSQL brut
            else if (prefixe !== undefined)
                valeur = QueryParser.prefixer(valeur, prefixe);

            this.log(`Remplacement du placeholder ${placeholder} par « ${valeur} » (${shouldEscape ? 'avec' : 'sans'} escape)`);

            return '/* @param ' + nomParam + ' */ ' + valeur;


        });

        return { sql, manquant: paramsManquant }
    }
}