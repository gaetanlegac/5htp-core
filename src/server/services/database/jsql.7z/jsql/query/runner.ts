/*
    NOTE: QueryRunner a été séparé de QueryParser afin de pouvoir mettre en cache les AST
*/

/*----------------------------------
- DEPENDANCES
----------------------------------*/

// Npm
import util from 'util';

// Libs
import Db, { TOptsSelectQuery, sepPks } from '../..';
import { Introuvable } from '@common/errors'

// Libs mtier
export { printQuery } from './base';
import QueryParser, { TOptsQueryParser, TContexteQuery, printQuery } from './base';
import factories, { TTypeInstruction } from '../factories';
import { objToJsql, TQueryAbstraite } from '../parser/abstraction';

export { Op } from '../factories/abstraction/conditions';

/*----------------------------------
- TYPES
----------------------------------*/

// Types
import type { TMetasModele, TMetasTable, TAssociation } from '../../../models/metas';

import type Modele from '../../../models';

export type TListeParams = {
    [nom: string]: {
        type: string
    }
}

type TObjDonnees = {[cle: string]: any}

/*----------------------------------
- TYPES OPTIONS
----------------------------------*/
export type TOptsQuery = Partial<Pick<Query, 'hooks'>>

export type TOptsExecQuery = TOptsSelectQuery & {
    raw?: boolean,
    structurer?: boolean,
}

type TArgsFind<TOptionsSupplementaires extends TObjDonnees = {}> = (

    []
    |
    // Modele.find( id )
    // Modele.find(`SELECT ** WHERE id = :id`)
    [number | string]
    |
    // Modele.find( id, { join: ['metas'], debug: true })
    // Modele.find(`SELECT ** WHERE id = :id`, { data: { id } })
    [string, TQueryAbstraite & TOptsExecQuery & TOptionsSupplementaires]
    |
    // Modele.find( id, { join: ['metas'], debug: true }, { hooks: { ... } })
    // Modele.find(`SELECT ** WHERE id = :id`, { data: { id } }, { hooks: { ... } })
    [string, TQueryAbstraite & TOptsExecQuery & TOptionsSupplementaires, TOptsParser]
    // Modele.find({ where: { id }, join: ['metas'] })
    |
    [TQueryAbstraite & TOptsExecQuery & TOptionsSupplementaires/*, TOptsParser*/]

)

export type TImportedQuery = String & {
    id: string,
    sourcefile: string
}

type TNomHooks = 'beforeBuild'
type THookFunc = (data: Partial<TModele>) => void;

/*----------------------------------
- TYPES: PARSER
----------------------------------*/
export type TOptsParser = TOptsQuery & { // Options parsing + instanciation query
    //mergeWith?: string,
}

export type TScopeResult = {
    sql: string,
    instructions: TInstructionsBrutes,
    subqueries: { [id: string]: Query },
}

export type TParseResult = {
    id: string,
    instructions: TInstructionsBrutes,
    subqueries: { [id: string]: Query },
}

export type TInstructionsBrutes = Partial<{
    [type in TTypeInstruction]: [typeof factories[type]["keywords"][number], string][]
}>

/*----------------------------------
- SERVICE
----------------------------------*/
export default class Query<
    TModele extends (typeof Modele | unknown) = unknown,
    TJointures extends (keyof TModele | unknown) = unknown
> {

    public readonly ast: QueryParser;
    public readonly data: TObjDonnees;

    public hooks: { [nom in TNomHooks]?: THookFunc} = {}

    /*----------------------------------
    - INIT
    ----------------------------------*/
    public constructor( 
        source: string | TImportedQuery | QueryParser | TQueryAbstraite,
        data: TObjDonnees = {}, 
        opts: TOptsQuery & TOptsQueryParser = {} 
    ) {

        // Via AST
        if (source instanceof QueryParser) {
            
            this.ast = source;
            
        // Via SQL ou objet query abstraite
        } else {

            // RAPPEL: TImportedQuery est une instance de String
            if (typeof source === 'object' && !( source instanceof String ))
                ({ jsql: source, data } = objToJsql(source, data));

            this.ast = QueryParser.parse(source, opts);
        }

        // Options
        this.data = data;
        this.setOpts(opts);

        // On considère l'instanciation de QueryRunner comme l'intention de lancer une requete
        // On s'assure donc que l'ast est build
        this.ast.prebuild();
    }

    public setOpts( opts: TOptsQuery ): this {

        if (opts.hooks !== undefined)
            this.hooks = opts.hooks;

        return this;
    }

    public setHook( name: TNomHooks, func: THookFunc ): this {
        this.hooks[name] = func;
        return this;
    }

    public extends(source: string, { data = {}, ...opts }: TOptsQuery & TOptsQueryParser = {}) {
        return new Query<TModele>( 
            this.ast.source + ' ' + source, 
            { ...this.data, ...data }, 
            {
                // Héritage des hooks
                hooks: this.hooks,
                ...opts
            }
        )
    }

    /*----------------------------------
    - EXECUTION (HAUT NIVEAU)
    ----------------------------------*/
    public static methodes: (keyof Query)[] = ['find', 'findOrFail', 'count', 'raw', 'all', 'existsOrFail']

    public async raw(...args: TArgsFind): Promise<TModele[]> {

        // Extraction options
        let { query, opts } = this.extractOptions(args)

        return await this.extends(query, opts).exec({}, { raw: true });
    }

    public async val(...args: TArgsFind): Promise<any> {

        const retour = await this.raw(...args);

        if (retour.length === 0)
            throw new Error(`getVal: Aucune ligne n'a été retournée`);

        const donnees = Object.values(retour[0])[0];

        return donnees;
    }

    public async all(...args: TArgsFind): Promise<TModele[]> {

        // Extraction options
        let { query, opts } = this.extractOptions(args)

        // JSQL par défaut. NOTE: le jsql métier peut écraser le jsql par défaut
        query = 'SELECT ** ' + query;

        return await this.extends(query, opts).exec();
    }

    public async pagination(...args: TArgsFind<{ page: number, items: number }>): Promise<TPagination<TModele>> {

        // Extraction options
        let { query, opts } = this.extractOptions<{ page: number, items: number }>(args)

        const { page = 1, items = 10 } = opts;
        
        const total = await this.count(query, opts);

        const start = (page - 1) * items;
        const end = page * items;

        const list = await this.all(query + ' LIMIT ' + start + ',' + end, opts);

        return {
            total,
            list,
            page,
            pages: Math.ceil(total / items)
        }
    }

    public async find(...args: TArgsFind): Promise<TModele | null> {

        // Extraction options
        let { query, opts } = this.extractOptions(args, { idShortcut: true })

        // JSQL par défaut
        // ATTENTION: Pas de LIMIT 1 ici, car on souhaite récupérer toutes les données des jointures
        query = 'SELECT ** ' + query;

        const resultats = await this.extends(query, opts).exec();
        console.info(`find:`, resultats.length === 0 ? 'Non-trouvé' : 'Trouvé', resultats[0]?.get());
        return resultats[0] || null;
    }

    public async findOrFail(...args: Parameters<Query<TModele>["find"]>): Promise<TModele> {

        const resultat = await this.find(...args);

        if (resultat === null) {
            throw new Introuvable();
        }

        return resultat;
    }

    public async count( ...args: Parameters<Query<TModele>["all"]> ): Promise<number> {

        // Extraction options
        let { query, opts } = this.extractOptions(args, { idShortcut: true })

        // JSQL par défaut
        query += ' SELECT COUNT(*) as $nb';

        // Fork requete
        const fork = this.extends(query, opts);

        // Execution
        const resultats = await fork.exec({}, {
            raw: true,
            structurer: false
        });

        if (resultats.length !== 1)
            throw new Error(`Nombre de résultats inattendu pour le count: ${resultats.length}`);
        if (resultats[0].nb === undefined)
            throw new Error(`Résultat inattendu pour le count: La colonne nb est absente`);

        return (resultats[0].nb as number) || 0;
    }

    public async existsOrFail(...args: Parameters<Query<TModele>["count"]>): Promise<number> {

        const nbExistant = await this.count(...args);

        if (nbExistant === 0) {
            throw new Introuvable();
        }

        return nbExistant;
    }

    private extractOptions<TOptionsSupplementaires extends TObjDonnees = {}>(
        args: TArgsFind<TOptionsSupplementaires>,
        extractOpts: { idShortcut?: boolean } = {}
    ) {

        let opts: With<TOptsExecQuery, 'data'> & TQueryAbstraite & TOptsParser & TOptionsSupplementaires = {
            data: {}
        }
        let query: string = '';

        // Modele.find( <options> )
        if (typeof args[0] === 'object') {

            opts = { data: {}, ...args[0] }

        // Modele.find( <id | query>, <options> )
        } else {

            // Objet d'options
            // NOTE: Laisser AVANT la lecture du premier args, car modif des data par la suite
            if (args[1] !== undefined)
                opts = { ...opts, ...args[1] }

            // Via ID
            if (extractOpts.idShortcut === true && (
                // ID numérique
                typeof args[0] === 'number' 
                || 
                // ID chaine (= sans espace)
                (typeof args[0] === 'string' && !args[0].includes(' '))
            )) {

                if (this.ast.from === undefined)
                    throw new Error(`Impossible de déterminer le nom des pks, car l'instruction from est absente.`);

                const pks = this.ast.from.tableReele.pk;
                const pkComposee = pks.length === 1
                    ? '$' + pks[0]
                    : 'CONCAT_WS("' + sepPks + '", ' + pks.map(pk => '$' + pk).join(', ') + ')'

                query = 'WHERE ' + pkComposee + ' = :id';
                opts.data["id"] = args[0];

            // JSQL
            } else if (typeof args[0] === 'string')
                query = args[0]
        }

        // Construction query avec l'objet d'options
        query += objToJsql(opts, opts.data).jsql;

        return { query, opts };

    }

    /*----------------------------------
    - EXECUTION (BAS NIVEAU)
    ----------------------------------*/
    public async exec(data: TObjDonnees = {}, opts: TOptsExecQuery = {}) {

        const sql = this.getSql({ ...this.data, ...data });
        const modele = this.ast.from?.tableReele.modele;

        console.info('[before exec]', printQuery(sql));

        // Execution
        let resultats = (await Db.select(sql, {}, opts).catch((e) => {

            this.ast.printDebugInfos();
            throw e;

        })) as TObjDonnees[];

        if (resultats.length !== 0) {

            // 1. Structuration via les chemins (équivalent à dottie)
            if (opts.structurer !== false)
                resultats = this.structurerDonnees(resultats);

            // 2. Fusion relations hasmany, construction des tableaux
            // Regroupement si on possède les métadonnées et qu'on ne souhaite pas les résultats brutes
            if (modele !== undefined && opts.raw !== true)
                resultats = this.regrouperDonnees(resultats, modele, opts);

        }

        console.info('[resultats]', util.inspect(resultats, {
            showHidden: false,
            depth: 10,
            colors: true
        }));

        // Instanciation
        let retour: any[];
        if (modele !== undefined && opts.raw !== true)
            retour = resultats.map((resultat) => {

                if (this.hooks.beforeBuild !== undefined)
                    this.hooks.beforeBuild(resultat);

                return modele.class.build(resultat, {
                    viaDb: true
                })

            })
        else
            retour = resultats;

        return retour;
    }

    // Complète le SQL mis en cache avec le remplacement des paramètres « métier »
    public getSql(data: {[cle: string]: any}) {

        const { sql, manquant } = this.ast.withParams(data);

        // Tous les paramètres sont censés avoir été remplacés
        if (manquant.length !== 0) {
            console.log(`SQL à l'origine de l'erreur:`, printQuery(sql));
            throw new Error(`${this.ast.id}: Aucune valeur n'a été fournie pour les paramètres suivants: ${manquant.join(', ')} (data fournies: ${Object.keys(data).join(', ')}). SQL complet ci-dessus.`);
        }

        return sql;
    }
    
    /*----------------------------------
    - TRANSFORMATION DONNEES
    ----------------------------------*/
    // - Structure l'objet de retour à partir des chemins dfinie via les clés
    //      - INSPIRATION: https://github.com/mickhansen/dottie.js/blob/master/dottie.js#L115
    // Ex: { 'utilisateur.items.id': 10 } => { utilisateur: { items: [{ id: 10 }] } }
    // - Regroupe les résultats selon l'id du modèle d'origine
    // - Regroupe les associations hasmany à leur modèle parent respectuf, sous forme de tableau
    private structurerDonnees(resultatsBruts: TObjDonnees[]): TObjDonnees[] {
        
        let donneesStructurees: TObjDonnees[] = []; 
        const nbResultats = resultatsBruts.length
        for (let i = 0; i < nbResultats; i++) {
            const donneesBrutes = resultatsBruts[i];

            let donnees: TObjDonnees = {};
            for (const chemin in donneesBrutes) {

                const valeur = donneesBrutes[chemin];
                // Exclusion si absence de valeur (= undefined)
                if (valeur === null) continue;

                // Chemin composé d'une seule branche = pas besoin d'itération
                if (chemin.indexOf('.') === -1) {
                    donnees[chemin] = valeur;
                    continue;
                }

                // Décomposition chemin
                const branches = chemin.split('.');
                const derniereBranche = branches.pop();
                if (derniereBranche === undefined)
                    throw new Error('La clé est vide.');

                // Création structure & ciblage sur l'objet contenant la valeur à assigner
                let donnee: TObjDonnees = donnees;
                for (const branche of branches) {

                    if (donnee[branche] === undefined)
                        donnee[branche] = {}

                    donnee = donnee[branche];

                }

                // Assignement valeur
                donnee[derniereBranche] = valeur;

            }

            // Ajout aux résultats
            donneesStructurees.push(donnees);
        }

        return donneesStructurees;
    }

    private regrouperDonnees(
        input: TObjDonnees[],
        modeleOuTable: TMetasModele | TMetasTable,
        opts: TOptsExecQuery
    ): TObjDonnees[] {

        let resultats: TObjDonnees[] = [];
        for (let i = 0; i < input.length; i++) {

            resultats = this.fusionnerVersListe(
                resultats, input[i], 
                modeleOuTable, undefined,
                opts, [i.toString()]
            );

        }

        console.info(`[regrouper]`, /*input, */resultats);

        return resultats;

    }

    private fusionnerVersListe(
        liste: TObjDonnees[],
        element: TObjDonnees,

        modeleOuTable: TMetasModele | TMetasTable | undefined,
        association: TAssociation | undefined,

        opts: TOptsExecQuery,
        cheminA: string[] = [] // Pour le debug
    ): TObjDonnees[] {

        let nomPks: string[] | undefined;
        if (modeleOuTable !== undefined) {

            nomPks = ('classe' in modeleOuTable) 
                // Modèle
                ? modeleOuTable.tables.default.pk
                // Table
                : modeleOuTable.pk;

        } else if (association?.mode === 'libre')
            nomPks = association.pk;

        // Détermine l'existance de l'élement dans la liste via ses pks
        const existant = nomPks && liste.find((elementExistant) => 
            nomPks.every((nomPk) =>
                elementExistant[nomPk] === element[nomPk]
            )
        );

        // Nouvel élement
        if (!existant) {

            // Ajout intégral à la liste
            liste.push(element);

            // Si on ne parvient pas à obtenir les infos nécéssaires à la fusion,
            // Ajout simple à la liste
            if (modeleOuTable !== undefined)
                // Initialise tous les attributs hasmany de l'élement en tableau
                this.fusionnerDonnees(
                    element, undefined,
                    modeleOuTable,
                    opts, cheminA
                );

        // Element déjà existant avec ces pks
        } else {

            if (modeleOuTable === undefined) {

                // Dans le cas des stats (ex: post.statsEvents), buildStats se chargera de la fusion
                console.warn(`${cheminA.join('.')}: Doublon sur les clés ${(nomPks as string[]).join(', ')}: Impossible de fusionner les données (${JSON.stringify(element)} -> ${JSON.stringify(existant)}), car les métadonnées du modèle / de la table concerné(e) ne sont pas disponibles.`);
            
                liste.push(element);

            } else
                // Fusionne les attributs hasmany de element vers existant
                this.fusionnerDonnees(
                    existant, element, 
                    modeleOuTable, 
                    opts, cheminA
                );

        }

        // retourne la liste à jour
        return liste;

    }
    
    private fusionnerDonnees(
        output: TObjDonnees,
        aAjouter: TObjDonnees | undefined,
        modeleOuTable: TMetasModele | TMetasTable,

        opts: TOptsExecQuery,
        cheminA: string[] = [] // Pour le debug
    ) {
        const colonnesOuAttributs = ('attributs' in modeleOuTable) ? modeleOuTable.attributs : modeleOuTable.colonnes;
        for (const alias of modeleOuTable.associations.all) {

            const asso = colonnesOuAttributs[alias].association as TAssociation;
            const modeleOuTableAsso = asso.mode === 'relation' ? (asso.modele || asso.table) : undefined;
            const cheminAsso = [...cheminA, alias];

            console.info(`[regrouper] Fusionner`, cheminAsso.join('.'), asso.type);

            const donnee = output[alias]; // Rend la donnée toujours accessible malgré le forçage du format tableau
            let donneeTraitee = false;

            // * Hasmany: Init, fusion et recursion
            if (asso.type === 'hasmany') {

                // * Init output en tableau
                if (donnee === undefined)
                    output[alias] = []; // Initialisation
                else if (!Array.isArray(donnee))
                    output[alias] = [donnee] // Force le format tableau

                // * Fusion aAjouter -> output
                if (aAjouter !== undefined && aAjouter[alias] !== undefined) {

                    const nomPks = ('classe' in modeleOuTable) 
                        // Modèle
                        ? modeleOuTable.tables.default.pk
                        // Table
                        : modeleOuTable.pk;

                    const pk = nomPks.map(pk => aAjouter[pk]).join('-')
                    console.info(`[regrouper] Ajout`, cheminAsso.join('.'), pk);

                    // Fusion et récursion
                    output[alias] = this.fusionnerVersListe( 
                        donnee, aAjouter[alias], 
                        modeleOuTableAsso, asso,
                        opts, cheminAsso 
                    );

                    donneeTraitee = true;

                }
            }

            // Recursion si pas déjà fait via fusionnerVersListe
            if (donneeTraitee === false && modeleOuTableAsso !== undefined && donnee !== undefined) {

                // Simple recursion à la recherche d'autres hasmany
                this.fusionnerDonnees(
                    donnee, aAjouter ? aAjouter[alias] : undefined,
                    modeleOuTableAsso,
                    opts, cheminAsso
                );

            }
        }
    }
}