/*----------------------------------
- CONSTANTES
----------------------------------*/
export const OpLogiques = {
    and: Symbol.for('and'),
    or: Symbol.for('or'),
}

export const OpComparaison = {
    eq: Symbol.for('eq'),
    ne: Symbol.for('ne'),
    gt: Symbol.for('gt'),
    gte: Symbol.for('gte'),
    lte: Symbol.for('lte'),
    lt: Symbol.for('lt'),
    in: Symbol.for('in'),
}

export const Op = { ...OpLogiques, ...OpComparaison }

export class SqlLiteral {
    public constructor(public sql: string) { }
    public toString(): string { return this.sql; }
}
export const Sql = (sql: string) => new SqlLiteral(sql)

/*----------------------------------
- TYPES
----------------------------------*/
export type TValeurSql = string | number | boolean | null;

export type TCritereChamp = TValeurSql | string[] | SqlLiteral | { [op in symbol]: TCritereChamp }
export type TObjConditions = { [champ: string]: TCritereChamp } & { [operateur in symbol]: TCritereChamp[] }
export type TCondition = string | TObjConditions

/*----------------------------------
- METHODES
----------------------------------*/
export const genCondition = (cle: string, op: Symbol, valeur: TValeurSql | SqlLiteral, queryData: object, prefixe?: string): string => {

    let comparaison: string;
    let exprValeur: string | undefined;
    switch (valeur) {
        case null: exprValeur = 'NULL'; break;
        case true: exprValeur = 'TRUE'; break;
        case false: exprValeur = 'FALSE'; break;
    }

    if (exprValeur !== undefined) {

        switch (op) {
            case Op.eq: comparaison = 'IS'; break;
            case Op.ne: comparaison = 'IS NOT'; break;
            default: throw new Error(`Valeur ${exprValeur} non-supportée par l'opérateur ` + op.toString());
        }

        comparaison += ' ' + exprValeur;

    } else {

        let sqlValeur: string;
        if (valeur instanceof SqlLiteral)
            sqlValeur = valeur.sql;
        else {
            queryData[cle] = valeur;
            sqlValeur = ':' + cle;
        }
            //sqlValeur = this.addData(cle, valeur);

        switch (op) {
            case Op.eq: comparaison = '= ' + sqlValeur; break;
            case Op.ne: comparaison = '!= ' + sqlValeur; break;

            case Op.gt: comparaison = '> ' + sqlValeur; break;
            case Op.gte: comparaison = '>= ' + sqlValeur; break;
            case Op.lte: comparaison = '<= ' + sqlValeur; break;
            case Op.lt: comparaison = '< ' + sqlValeur; break;

            case Op.in: comparaison = 'IN (' + sqlValeur + ')'; break;

            default: throw new Error('Opérateur inconnu: ' + op);
        }
    }

    return '$' + (prefixe ? prefixe + '.' : '') + cle + ' ' + comparaison;
}

export const genConditions = (conditions: TCondition, queryData: object, opLogique: string = 'AND', prefixe?: string): string | null => {

    // SQL brut
    if (typeof conditions === 'string')
        return conditions;
    // Objet d'Egalités
    else if (typeof conditions === 'object') {

        let retour: string[] = [];

        // Opérateurs logiques
        // { Op.or: [{ type: 'banner' }, { type: 'text' }] }
        const operateurs = Object.getOwnPropertySymbols(conditions);
        for (const operateur of operateurs) {

            let opSql: string;
            if (operateur === Op.and)
                opSql = 'AND';
            else if (operateur === Op.or)
                opSql = 'OR';
            else
                throw new Error("Opérateur inconnu");

            const conditionsSql = conditions[operateur].map((condition) => 
                genConditions(condition, queryData, 'AND', prefixe)
            ).join(' ' + opSql + ' ')

            retour.push('(' + conditionsSql + ')');
        }

        // Nom colonnes
        // { nom: 'booster' }
        // { nom: ['booster', 'exp'] }
        // { nom: sql('...') }
        // { nom: { Op.like: 'booster } }
        for (const cle in conditions) {

            let donnee = conditions[cle];

            // Modèle vers pk

            // Détermination opération selon type donnée
            if (Array.isArray(donnee))
                donnee = { [Op.in]: donnee };

            // undefined = NULL en MySQL
            if (donnee === undefined)
                donnee = null;

            // Egalité simple (RAPPEL: null est un objet)
            if (donnee === null || typeof donnee !== 'object') {

                retour.push( genCondition(cle, Op.eq, donnee, queryData, prefixe) );

            // Sql literal
            // FIX: « donnee instanceof SqlLiteral » ne retourne pas toujours true (à cause d'un « export { SqlLiteral } from ... » ?)
            } else if (donnee.constructor.name === 'SqlLiteral') {

                retour.push('$' + (prefixe ? prefixe + '.' : '') + cle + ' ' + donnee.sql);

            // Opérations spécifiques
            } else if (donnee.constructor === Object) {

                // Opérateurs de comparaison
                // Les boucles for ne tiennent pas compte des symboles
                const operateurs = Object.getOwnPropertySymbols(donnee);
                for (const op of operateurs) {

                    retour.push( genCondition(cle, op, donnee[op], queryData, prefixe) );
                }

                // Modèle
                /*} else if (this.modele !== undefined && this.modele.associations.all.includes(cle)) {

                    if (donnee.metas === undefined)
                        throw new Error(`Seul un modèle peut être passé dans une égalité portant sur un attribut d'association.`);

                    const asso = this.modele.attributs[cle as keyof typeof this.modele.attributs].association as TAssociation;
                    if (asso.reverse === true) // La fk est stockée dans le modèle parent
                        throw new Error(`Seuls les modèles associés dont la pk est stockée dans le modèle parent (reverse = false) sont supportés.`);

                    retour.push( genCondition(asso.fk, Op.eq, donnee.getPkValue()) );*/

            } else {

                console.error(donnee, typeof donnee, typeof donnee === 'object' ? donnee.constructor.name : typeof donnee)

                throw new Error(`Impossible de construire une égalité avec la valeur ${cle} (valeur ci-dessus)`);

            }

        }

        const nbConditions = retour.length;
        if (nbConditions === 0)
            return null;
        else if (nbConditions === 1)
            return retour[0];
        else
            return '(' + retour.join(' ' + opLogique + ' ') + ')';

    } else
        throw new Error('Erreur de format');

}