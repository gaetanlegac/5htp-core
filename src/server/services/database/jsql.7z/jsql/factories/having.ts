/*----------------------------------
- DEPENDANCES
----------------------------------*/
import Factory, { TInstructionBrute } from './base'
import { corrigerEgalites } from './base/egalites';

/*----------------------------------
- TYPES
----------------------------------*/


/*----------------------------------
- CONSTANTES
----------------------------------*/



/*----------------------------------
- FACTORY
----------------------------------*/
type TKeyword = 'HAVING'
export default class Having extends Factory<TKeyword> {

    public static keywords = ['HAVING'] as TKeyword[]
    public static regex = undefined;

    public conditions!: string;

    /*----------------------------------
    - ABSTRACTION
    ----------------------------------*/
    public static serialize(input: string | string[]): string {
        return 'HAVING ' + (typeof input == 'string' ? input : input.join(', '))
    }

    /*----------------------------------
    - INSTRUCTIONS BRUTES
    ----------------------------------*/
    protected mergeAll(): TInstructionBrute<TKeyword> | undefined {

        // Fusion en une instruction
        if (this.raw.length === 0)
            return undefined;

        return {
            keyword: 'HAVING',
            sql: this.raw.map(({ sql }) => '(' + sql + ')').join(' AND ')
        }
        
    }

    /*----------------------------------
   - METADONNEES
   ----------------------------------*/
    protected parse(keyword: TKeyword, conditions: string) {

        this.conditions = conditions;

        return true;

    }

    /*----------------------------------
    - CONSTRUCTION SQL
    ----------------------------------*/
    protected toSql(): string {

        return 'HAVING ' + this.corrigerReferences(corrigerEgalites(  this.conditions ));
    }
}