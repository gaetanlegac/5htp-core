/*----------------------------------
- DEPENDANCES
----------------------------------*/

// Npm
import { arrayMoveMutable } from 'array-move';

// Libs
import Factory, { TListeChamps, TInstructionBrute } from './base'
import semantique, { blockToString } from '@common/data/chaines/semantique';

// Regex
import { regDeclarationSelect, regReferenceSeule, decompChemin, regReferences } from '../parser/regex';

/*----------------------------------
- TYPES
----------------------------------*/

import QueryParser from '../query/base';
import type { From, Join } from '.';

type TSelectAbstrait = (
    string
    |
    string[]
    |
    {[alias: string]: string}
)

/*----------------------------------
- CONSTANTES
----------------------------------*/



/*----------------------------------
- FACTORY
----------------------------------*/
type TKeyword = 'SELECT'
export default class Select extends Factory<TKeyword> {

    public static readonly keywords = ['SELECT'] as TKeyword[]
    public static readonly regex = undefined

    // Alias => Expression
    public selected: TListeChamps = {};
    public constantes: TListeChamps = {};
    // Nom des champs déclarés manuellement
    public declarations: string[] = []

    private idAlias: number = 0;

    /*----------------------------------
    - ABSTRACTION
    ----------------------------------*/
    public static serialize(input: TSelectAbstrait): string {

        if (input.constructor === Array)
            return 'SELECT ' + input.map(i => (i[0] === '$' || i === '*') ? i : '$' + i).join(', ')
        else
            return 'SELECT ' + Object.entries(input).map(([alias, sql]) => sql + ' as $' + alias)
    }

    /*----------------------------------
    - INSTRUCTIONS BRUTES
    ----------------------------------*/
    protected mergeAll(): TInstructionBrute<TKeyword> | undefined {

        // Par défaut, on sélectionne tous les champs disponibles
        if (this.raw.length === 0)
            return {
                keyword: 'SELECT',
                sql: '**'
            }

        // Fusion de plusieurs select en un seul
        // Ex: [['SELECT', '*'], ['SELECT', '$metas.*']] => [['SELECT', '*, $metas.*']]
        let fusion: string[] = []

        for (let { sql, provenance_id } of this.raw) {

            // Doublon
            if (fusion.includes( sql ))
                continue;

            // Ajout à la liste
            fusion.push( sql );
        }

        // La selection de champs spécifique annule le sélecteur double wildcard
        if (fusion.length !== 1)
            fusion = fusion.filter(s => s !== '**')

        return {
            keyword: 'SELECT',
            sql: fusion.join(', ')
        }
        
    }

    /*----------------------------------
   - METADONNEES
   ----------------------------------*/
    protected parse(keyword: TKeyword, select: string) {

        const ast = semantique(select, {
            root: {
                isList: true // L'instruction select (= root) est forcémment une liste
            }
        });

        for (const champ of ast.content)
            this.addSelecteur( blockToString(champ) );

        return true;
    }
    
    private addSelecteur(selecteur: string) {

        /* Wildcard global
            Entrée: *
            Sortie: `post`.id as `id`, `post`.nom as `nom`, ...

            NOTE: ** a été viré pour éviter les importations inutiles, surtout quand on utilise la fusion des queries
        */
        if (selecteur === '*' || selecteur === '**') {

            if (this.query.from === undefined)
                throw this.Erreur(`L'utilisation du wildcard seul n'est pas autorisé, car la clause FROM est manquante dans la requete.`);

            // Table principale
            this.addChamp('*', '`' + this.query.from.alias + '`.*', Select.getListeChamps(this.query.from))

            // Jointures
            if (selecteur === '**') {

                // Importation des champs de chaque table en jointure
                for (const aliasJoin in this.query.join.liste) {

                    const champsWildcard = Select.getListeChamps( this.query.join.liste[aliasJoin] );

                    for (const nomCol in champsWildcard) {

                        const selecteur = '`' + aliasJoin + '`.`' + nomCol + '`';
                        const alias = aliasJoin + '.' + nomCol;

                        // Si cette colonne n'est pas déjà incluse par le wildcard (= dans la table from)
                        if (alias in this.query.from.table.colonnes)
                            continue;
                            
                        this.addChamp(alias, selecteur)
                    }
                }
            }

            return;

        }

        /* Déclaration avec alias
            Entrée: (SELECT ....) as $cout
            Sortie: (SELECT ....) as `cout`

            Entrée: 'completion' as #cout
            Sortie: 
        */
        const aliasTrouve = selecteur.match(regDeclarationSelect);
        if (aliasTrouve?.groups) {

            // Retire l'alias de l'expression
            selecteur = selecteur.substring(0, aliasTrouve.index);
            const { prefixe, alias } = aliasTrouve.groups;

            // Raccourcis
            // NOTE: Attention aux espaces créés avant et après les blocs par le parser jsql
            if (selecteur.endsWith(') |0'))
                selecteur = 'COALESCE( ' + selecteur.substring(0, selecteur.length - 3) + ', 0)'

            // Constante: on ne conserve pas le sql
            // NOTE: Constantes pas utilisées pour le moment
            /*if (prefixe === '#') {

                this.constantes[ alias ] = selecteur;
                
            } else {*/

                if (this.addChamp(alias, selecteur))
                    this.declarations.push(alias)

            //}

            return;
        }

        /* Référence simple

            Entrée: $id 
            Sortie: `post`.id as `id`

            Entrée: $post.createur.*
            Sortie: `post`.`createur.id` as `post.createur.id`, `post`.`createur.nom` as `post.createur.nom`,
        */
        const reference = selecteur.match(regReferenceSeule);
        if (reference !== null) {

            const [ , refParent, refParam, cheminComplet ] = reference;
            const [prefixe, branche] = decompChemin(cheminComplet);

            if (branche === '*' && prefixe !== undefined) {

                let jointure = this.query.references[prefixe];
                if (jointure === undefined) {
                
                    //throw this.Erreur(`Impossible de transformer le selecteur « ${cheminComplet}.* », car aucune jointure n'a été trouvée avec le chemin « ${prefixe} »`);
                    this.log(`Jointure automatique via le sélecteur « ${cheminComplet}.* »`);

                    // Jointure automatique
                    jointure = this.query.join.add('JOIN', '$' + prefixe, {}, true);
                    

                }

                const champsAextraire = Select.getListeChamps(jointure);
                for (const nomCol in champsAextraire) {

                    const selecteurChamp = '`' + prefixe + '`.`' + nomCol + '`';
                    const alias = prefixe + '.' + nomCol; 

                    this.addChamp(alias, selecteurChamp)
                }

            } else {

                // Sous-requete
                const asso = this.query.from?.tableReele.modele?.attributs[ branche ]?.association;
                if (asso?.mode === 'query') {

                    this.addChamp(cheminComplet, '(' + asso.query.getSql({  }) + ')')

                // Sélecteur simple
                } else
                    this.addChamp(cheminComplet, selecteur)

            }

            return;
        }
           
        // Autres: on génère un alias artificiel
        const alias = 'data' + (this.idAlias++);
        this.addChamp(alias, selecteur)
    }

    private addChamp(alias: string, selecteur: string, viaWildcard?: object) {
            
        // Vérification doublons
        if (viaWildcard !== undefined) {

            for (const nomRef in viaWildcard) {

                if (nomRef in this.query.colonnes) {
                    this.log(`Doublon pour le champ « ${nomRef} ». Le dernier a été ignoré.`);
                    return false;
                    //throw this.Erreur(`Doublon pour le champ « ${alias} » (« ${this.query.colonnes[alias]} » vs « ${viaWildcard[alias]} »)`);
                }
                
                this.query.colonnes[nomRef] = viaWildcard[nomRef];
                
            }

        } else {

            if (alias in this.query.colonnes){
                this.log(`Doublon pour le champ « ${alias} ». Le dernier a été ignoré.`);
                return false;
            }

            this.query.colonnes[alias] = selecteur;

        }

        // Selection du champ
        this.selected[alias] = selecteur;

        return true;

    }

    private static getListeChamps(reference: Join | From) {
        // Nom => Provenance
        let retour: {[nom: string]: string} = {}

        if (reference.table instanceof QueryParser)
            return { ...reference.table.colonnes }
        else
            for (const nom in reference.table.colonnes)
                retour[ nom ] = '<colonne>'

        return retour;
    }

    /*----------------------------------
    - CONSTRUCTION SQL
    ----------------------------------*/
    protected toSql(): string {

        // On corrge l'ordre après que toutes les instructions aient été prebuild
        // Afin que l'ensemble des champs sélectionnés, y compris ceux importés par les with, soient affectés
        //const ordreSelection = this.corrigerOrdreSelection();

        let select: string[] = []
        for (let alias in this.selected) {

            const expression = this.selected[alias];

            select.push( alias === '*' 
                ? expression 
                : this.corrigerReferences(expression, alias) + ' as `' + alias + '`'
            )

        }

        // Traite toutes les autres références n'ayant pas été repérées par addSelecteur (subqueries, ...)
        return 'SELECT ' + select.join(', ')

    }

    // OBSOLETE: L'ordre n'a plus d'importance, les références aux champs déclarés dans le même select étant maintenant remplacées par le code SQL direct (voir corrigerReferences)
    private corrigerOrdreSelection() {

        const debug = false;

        let ordreSelection: string[] = Object.keys(this.selected);

        debug && this.log('[corrigerOrdreSelection] avant:', ordreSelection);

        // Pour chaque selecteur faisant référence à au moins 1 autre déclaration du même select,
        // On décalle l'index du selecteur après la déclaration
        // ATTENTION: Ne fonctionne pas si deux déclaration se font référence à elles-mêmes
        for (const alias of this.declarations) {

            const indexInitial = ordreSelection.indexOf(alias);
            let indexDestination = indexInitial;
            let nomReferences: string[] = []

            // Récupère l'index le plus élevé de la déclaration à laquelle le selecteur fait référence
            // TODO: Itération résultats regex sans replace
            const selecteur = this.selected[alias]
            selecteur.replace(regReferences, (complet: string, refParent: string, refParam: string, cheminComplet: string) => {

                const indexRef = ordreSelection.indexOf(cheminComplet);
                if (indexRef === -1) return;

                nomReferences.push(complet);

                if (indexRef > indexDestination)
                    indexDestination = indexRef;

            });

            if (indexDestination !== indexInitial) {
                
                debug && console.log(`Déplacement de la déclaration de « ${alias} » de l'index ${indexInitial} vers l'index ${indexDestination} (références à ${nomReferences.join(', ')})`);

                // Décalle le sélécteur juste après l'index
                arrayMoveMutable(ordreSelection, indexInitial, indexDestination + 1);
            }

        }

        debug && this.log('[corrigerOrdreSelection] après:', ordreSelection);

        return ordreSelection;
    }
}