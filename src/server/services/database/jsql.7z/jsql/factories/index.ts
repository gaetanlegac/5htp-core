/*----------------------------------
- DEPENDANCES
----------------------------------*/
import select from './select';
import from from './from';
import joinContainer from './joinContainer';
import WithContainer from './withContainer'; // with est un mot clé reservé
import where from './where';
import order from './order';
import group from './group';
import limit from './limit';
import having from './having';

export { default as With } from './with';
export { default as WithContainer } from './withContainer';
export { default as Select } from './select';
export { default as From } from './from';
export { default as Join } from './join';
export { default as JoinContainer } from './joinContainer';
export { default as Where } from './where';
export { default as Order } from './order';
export { default as Group } from './group';
export { default as Limit } from './limit';
export { default as Having } from './having';

/*----------------------------------
- INDEX
----------------------------------*/

// Cet objet défini également l'ordre de traitement des AST et de la création du SQL
const factories = { 

    // NOTE: Laisser en premier, car métadonnées reuqises par la majorité des autres factories
    from,

    with: WithContainer, // Peut modifier toutes les instructions sauf le from, donc traité en premier
    join: joinContainer,
    select, // FROM et JOIN peuvent modifier la liste des champs sélectionnés
    
    where, 
    order, 
    group, 
    limit, 
    having 
}
export default factories;

export const keywords: { [keyword in TKeyword]: TTypeInstruction } = {}
for (const instruction in factories)
    for (const keyword of factories[instruction].keywords)
        keywords[keyword] = instruction;

export type TTypeInstruction = keyof typeof factories
export type TKeyword = typeof factories[TTypeInstruction]["keywords"][number]