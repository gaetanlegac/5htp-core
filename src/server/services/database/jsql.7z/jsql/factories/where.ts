/*----------------------------------
- DEPENDANCES
----------------------------------*/
import Factory, { TInstructionBrute } from './base'
import { genConditions, TCondition } from './abstraction/conditions';
import { corrigerEgalites } from './base/egalites';

/*----------------------------------
- TYPES
----------------------------------*/

/*----------------------------------
- CONSTANTES
----------------------------------*/



/*----------------------------------
- FACTORY
----------------------------------*/
type TKeyword = 'WHERE'
export default class Where extends Factory<TKeyword> {

    public static keywords = ['WHERE'] as TKeyword[]
    public static regex = undefined;

    private conditions!: string;

    /*----------------------------------
    - ABSTRACTION
    ----------------------------------*/
    public static serialize(input: TCondition, queryData: object): string | null {
        const conditions = genConditions(input, queryData);
        if (conditions === null)
            return null;
        return 'WHERE ' + conditions;
    }

    /*----------------------------------
    - INSTRUCTIONS BRUTES
    ----------------------------------*/
    protected mergeAll(): TInstructionBrute<TKeyword> | undefined {

        // Fusion en une instruction
        if (this.raw.length === 0)
            return undefined;

        return {
            keyword: 'WHERE',
            sql: this.raw.map(({ sql }) => '(' + sql + ')').join(' AND ')
        }

    }

    /*----------------------------------
   - METADONNEES
   ----------------------------------*/
    protected parse(keyword: TKeyword, conditions: string) {

        this.conditions = conditions;

        return true;
       
    }

    /*----------------------------------
    - CONSTRUCTION SQL
    ----------------------------------*/
    protected toSql(): string {

        return 'WHERE ' + this.corrigerReferences(corrigerEgalites( this.conditions ));
    }
}