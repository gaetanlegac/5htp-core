/*----------------------------------
- DEPENDANCES
----------------------------------*/


// Libs
import { regexWith } from '@common/data/regex';

// Libs métier
import ModelsManager from '../../../models/manager';
import Factory, { TInstructionBrute } from './base'
import { regexTable, parseArgs, regReferenceLocale } from '../parser/regex';

import type WithContainer from './withContainer';

/*----------------------------------
- TYPES
----------------------------------*/

/*----------------------------------
- CONSTANTES
----------------------------------*/



/*----------------------------------
- FACTORY
----------------------------------*/
export type TKeyword = 'WITH'
export default class With extends Factory<TKeyword> {

    public static keywords = ['WITH'] as TKeyword[]
    
    public static regex = regexWith(/^{:regexTable}(?:\s+{:regReferenceLocale})?(?:\s+as\s+{:regReferenceLocale})?/g, { regexTable, regReferenceLocale })
    //public static regex = regexWith(/^{:regexTable}/g, { regexTable })

    public container: WithContainer;

    public chemin!: string;

    public constructor(container: WithContainer, instruction: TInstructionBrute<TKeyword>) {
        super(container.query)
        this.container = container;
        this.add(instruction.keyword, instruction.sql, instruction);
    }

    /*----------------------------------
    - INSTRUCTIONS BRUTES
    ----------------------------------*/
    protected mergeAll(): TInstructionBrute<TKeyword> | undefined {

        // Fusion en une instruction
        if (this.raw.length === 0)
            return undefined;

        return this.raw[0]

    }

    /*----------------------------------
   - METADONNEES
   ----------------------------------*/
    protected parse(keyword: TKeyword, chemin: string, args?: string, prefixe_in?: string, prefixe_out?: string) {

        this.chemin = chemin;

        const scope = ModelsManager.getScope(chemin);

        // Héritage prefixes
        const opts = this.raw[0];
        if (opts.prefixe_in !== undefined)
            prefixe_in = prefixe_in === undefined ? opts.prefixe_in : opts.prefixe_in + '.' + prefixe_in;

        if (opts.prefixe_out !== undefined)
            prefixe_out = prefixe_out === undefined ? opts.prefixe_out : opts.prefixe_out + '.' + prefixe_out;

        // Fusion
        this.query.mergeWith( scope, parseArgs(args), prefixe_in, prefixe_out );
        
        return true;
       
    }

    /*----------------------------------
    - CONSTRUCITON SQL
    ----------------------------------*/
    public toSql(): string {
        return '';
    }
}