/*----------------------------------
- DEPENDANCES
----------------------------------*/
// Libs
import { regexWith } from '@common/data/regex';

// Libs métier
import FactoryAvecTable from './base/table'
import { regexTable, regReferenceLocale } from '../parser/regex';

/*----------------------------------
- TYPES
----------------------------------*/

import { TInstructionBrute } from './base';
import QueryParser from '../query/base';

/*----------------------------------
- CONSTANTES
----------------------------------*/


/*----------------------------------
- FACTORY
----------------------------------*/
type TKeyword = 'FROM'
export default class From extends FactoryAvecTable<TKeyword> {

    public static keywords = ['FROM'] as TKeyword[]
    public static regex = regexWith(/^{:regexTable}(?:\s+(?:as\s+)?{:regReferenceLocale})?/g, { regexTable, regReferenceLocale })

    public constructor(query: QueryParser, sql: string) {
        super(query)
        this.add('FROM', sql);
    }

    /*----------------------------------
    - ABSTRACTION
    ----------------------------------*/
    protected mergeAll(): TInstructionBrute<TKeyword> | undefined {

        // Par défaut, on sélectionne tous les champs disponibles
        if (this.raw.length === 0)
            return undefined;

        // Si plusieurs spécifiés, le dernier les écrase tous
        return this.raw[this.raw.length - 1]

    }

    /*----------------------------------
    - INSTRUCTIONS BRUTES
    ----------------------------------*/
    protected parse(keyword: TKeyword, table: string, args: string | undefined, alias: string | undefined) {

        this.parseTable(table, alias, args);

        return true;
    }

    /*----------------------------------
    - CONSTRUCTION SQL
    ----------------------------------*/
    protected toSql(): string {

        return 'FROM ' + this.toTableSql()
    }
}