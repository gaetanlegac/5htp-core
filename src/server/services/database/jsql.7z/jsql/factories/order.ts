/*----------------------------------
- DEPENDANCES
----------------------------------*/
import Factory, { TInstructionBrute } from './base'

/*----------------------------------
- TYPES
----------------------------------*/

import QueryParser from '../query/base';

/*----------------------------------
- CONSTANTES
----------------------------------*/



/*----------------------------------
- FACTORY
----------------------------------*/
type TKeyword = 'ORDER BY'
export default class Order extends Factory<TKeyword> {

    public static keywords = ['ORDER BY']
    public static regex = undefined;

    private criteres!: string;

    /*----------------------------------
    - ABSTRACTION
    ----------------------------------*/
    public static serialize(input: string | string[]): string {
        return 'ORDER BY ' + (typeof input == 'string' ? input : input.join(', '))
    }

    /*----------------------------------
    - INSTRUCTIONS BRUTES
    ----------------------------------*/
    protected mergeAll(): TInstructionBrute<TKeyword> | undefined {

        // Fusion en une instruction
        if (this.raw.length === 0)
            return undefined;

        return {
            keyword: 'ORDER BY',
            sql: this.raw.map(({ sql }) => sql).join(', ')
        }

    }

    /*----------------------------------
   - METADONNEES
   ----------------------------------*/
    protected parse(keyword: TKeyword, criteres: string) {

        this.criteres = criteres;

        return true;

    }

    /*----------------------------------
    - CONSTRUCTION SQL
    ----------------------------------*/
    protected toSql(): string {

        return 'ORDER BY ' + this.corrigerReferences( this.criteres );
    }
}