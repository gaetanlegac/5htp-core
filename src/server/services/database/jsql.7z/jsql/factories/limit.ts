/*----------------------------------
- DEPENDANCES
----------------------------------*/
import Factory, { TInstructionBrute } from './base'

/*----------------------------------
- TYPES
----------------------------------*/

import QueryParser from '../query/base';

/*----------------------------------
- CONSTANTES
----------------------------------*/



/*----------------------------------
- FACTORY
----------------------------------*/
type TKeyword = 'LIMIT'
export default class Limit extends Factory<TKeyword> {

    public static keywords = ['LIMIT'] as TKeyword[]
    public static regex = undefined;

    public limite?: string; // Peut être un placeholder

    /*----------------------------------
    - ABSTRACTION
    ----------------------------------*/
    public static serialize(input: number): string {
        return 'LIMIT ' + input
    }

    /*----------------------------------
    - INSTRUCTIONS BRUTES
    ----------------------------------*/
    protected mergeAll(): TInstructionBrute<TKeyword> | undefined {

        // Fusion en une instruction
        if (this.raw.length === 0)
            return undefined;

        return this.raw[ this.raw.length - 1 ]

    }

    /*----------------------------------
   - METADONNEES
   ----------------------------------*/
    protected parse(keyword: TKeyword, limite: string) {

        this.limite = limite;

        return true;
       
    }

    /*----------------------------------
    - CONSTRUCTION SQL
    ----------------------------------*/
    protected toSql(): string {

        if (this.limite === undefined)
            return '';

        return 'LIMIT ' + this.limite;
    }
}