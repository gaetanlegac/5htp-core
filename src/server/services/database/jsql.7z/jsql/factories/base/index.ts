/*----------------------------------
- TYPES
----------------------------------*/

import QueryParser from '../../query/base';

// Regex
import { regReferences, regPlaceholder, regConstantes } from '../../parser/regex';

export type TListeChamps = {[alias: string]: string}

export type TInstructionBrute<TKeyword extends string = string> = {
    keyword: TKeyword,
    sql: string,

    provenance_id?: string, 
    prefixe_in?: string, 
    prefixe_out?: string
}


/*----------------------------------
- BASE INSTRUCTION
----------------------------------*/
export default abstract class Factory<TKeyword extends string = string> {

    public static keywords: string[] = []
    public static regex: RegExp | undefined;

    public nom: string;
    public query: QueryParser;

    public raw: TInstructionBrute<TKeyword>[] = [];
    public cancel: boolean = false;

    public log = (...args: any[]) => this.query.log({}, '[' + this.nom + ']', ...args)

    public constructor(query: QueryParser) {
        this.query = query;
        this.nom = this.constructor.name;
    }

    /*----------------------------------
    - INSTRUCTIONS BRUTES
    ----------------------------------*/
    public reset() {
        this.log(`Reset de l'instruction. Instructions éliminées:`, this.raw);
        this.raw = []
    }

    public add(keyword: TKeyword, sql: string, opts: Omit<TInstructionBrute, 'sql' | 'keyword'> = {}): TInstructionBrute<TKeyword> {

        const instruction = { keyword, sql, ...opts }

        this.raw.push(instruction);

        return instruction;
    }

    protected abstract mergeAll(): TInstructionBrute<TKeyword> | undefined;

    public parseInstructions() {

        // Prépration du sql de chaque instruction
        for (const instruction of this.raw) {

            // Restitution des subqueries
            // On lefait avant le prefixage, afin que les références de la subquery soient également mises à jour
            instruction.sql = this.restituerSubqueries2(instruction);

            // Prefixage des références
            if (instruction.prefixe_in !== undefined) {
                instruction.sql = QueryParser.prefixer(instruction.sql, instruction.prefixe_in);
            }
        }

        // Fusion de toutes les instructions en une seule
        const instruction = this.mergeAll();
        if (instruction === undefined) {
            this.cancel = true;
            this.log('parseInstructions annulé (aucune instruction à traiter)');
            return;
        }

        this.log('Fusion et prebuild de ' + this.raw.length + ' instructions', instruction);

        // Interprétation
        try {

            const regex = this.constructor.regex;
            if (regex === undefined) {

                this.parse(instruction.keyword, instruction.sql);

            } else {

                const matches = [...instruction.sql.matchAll(regex)];
                if (matches.length === 0)
                    throw this.Erreur(`Impossible d'interpreter l'instruction ${this.nom}: La syntaxe n'a pas été reconnue par le regex « ${regex.source} »`, instruction);

                const [, ...groupes] = matches[0];
                this.parse(instruction.keyword, ...groupes);

            }
            
        } catch (error) {

            throw this.Erreur(error, instruction);
            
        }
    }

    // Remplacement des subqueries n'ayant pas été traitées par les factories (select, where, ...)
    private restituerSubqueries2( instruction: TInstructionBrute<TKeyword> ) {
        return instruction.sql.replace(regPlaceholder, (placeholder) => {

            const idSubquery = placeholder.substring(1, placeholder.length - 1);

            const subquery = QueryParser.fromId(idSubquery);

            return '(' + subquery.getSql({ prefixe: instruction.prefixe_in }) + ')';

        });
    }

    protected abstract parse(keyword: TKeyword, ...matches: string[]): void;

    /*----------------------------------
    - CONSTRUCTION SQL
    ----------------------------------*/
    protected Erreur(erreur: string | Error, instruction?: string | TInstructionBrute<TKeyword>) {

        console.log("[database][query][factory] Origine de l'erreur ci dessous:");
        this.query.printDebugInfos(instruction);

        const baseErreur = "Erreur dans la clause " + this.nom + ' pour la requete ' + this.query.id + ": ";

        if (typeof erreur === 'string')
            erreur = new Error(baseErreur + erreur);
     

        if (erreur.prefixee !== true) {
            erreur.message = baseErreur + erreur.message;
            erreur.prefixee = true
        }

        return erreur;
        
    }
    
    public getSql(): string | undefined {

        this.log('get sql', this.nom, this.cancel, this.raw);

        if (this.cancel === true)
            return undefined;

        try {

            const sql = this.toSql();

            return sql;
            
        } catch (error) {

            throw this.Erreur(error);
            
        }
    }

    protected abstract toSql(): string | undefined;

    protected corrigerReferences(sql: string, declarationActuelle?: string): string {

        // NOTE: Constantes pas utilisées pour le moment
        return sql/*.replace(regConstantes, (match: string, cheminComplet: string ) => {

            const valeur = this.query.select.constantes[cheminComplet];
            if (valeur === undefined)
                throw new Error(`Impossible de traiter la référence vers la constante ${match} dans la clause ${this.nom}: La déclaration n'a pas été trouvée dans le select.`);

            return valeur;

        })*/.replace(regReferences, (match: string, refParent: string, refParam: string, cheminComplet: string, branche: string, offset: number, sqlActuel: string) => {

            // Ordre de vérification: le plus spécifique en premier
            // * SELECT > JOIN > FROM

            // Préfixé par plusieurs dollars = sera traité par la requete mère
            if (refParent !== '')
                return refParent + cheminComplet;

            let complementErreur: string = '';
            const ErreurReference = (msg: string) => this.Erreur(`Impossible de traiter la référence ${match} dans la clause ${this.nom}: ` + msg + `. ` + complementErreur, sqlActuel);

            // ATTENTION: Pose problème pour le parsin de certaines instructions utilisant un regex capturant les références
            const debugRef = (orig: string) => {
                this.log('[corrigerReferences] ' + match + ': Trouvé dans ' + orig);
                return false ? '/* ' + match + ': ' + orig + ' */ ' : ''
            };

            // Référence à un champ manuellement déclaré dans le SELECT
            // SELECT * FROM MissionTache HAVING `stats.total.taches` != 0
            // SELECT * FROM MissionTache WHERE (SELECT `stats.total.taches`) != 0
            if (this.query.select.declarations.includes(cheminComplet)) {

                // declarationActuelle = l'alias de l'expression déclarée dans le select
                //      Si le sql traité contient une référence dont le chemin correspond à declarationActuelle,
                //      On ne cherchera pas dans la liste des déclarations du select pour ne pas créer de réféence circulaire
                //      Exemple de référence circulaire: SUM( (SELECT `post.stats.completion`) ) as `post.stats.completion`
                if (cheminComplet === declarationActuelle)
                    complementErreur = `Référence à ${cheminComplet} dans la déclaration même de ${cheminComplet}. Recherche de la référence ailleurs pour éviter une référence circulaire ...`
                else
                    switch (this.nom) {
                        case 'Having':
                        case 'Order':
                            return debugRef('SELECT') + '`' + cheminComplet + '`';
                        /*
                            Les alias de colonne ne peuvent être réutilisés dans le même SELECT
                            Car MySQL ne garanti pas l'ordre d'évaluation des expressions.

                            Solutions:
                            * Répéter le calcul (solution la plus fiable)
                                SELECT
                                    *,
                                    (<calcul>) as `post.cout`, # On garde l'alias initial pour le déboguage
                                    (<calcul>) + 1 as `post.reward`
                                FROM Post

                            * (SELECT colonne) ATTENTION: Même si appellé après la déclaration de l'alias en question, la valeur peut être NULL car pas encore évaluée
                                SELECT
                                    *,
                                    (<calcul>) as `post.cout`,
                                    **(SELECT `post.cout`) + 1** as `post.reward`
                                FROM Post

                            * Selectionner les alias dont on a besoin dans une subquery (via FROM ou JOIN)
                                SELECT 
                                    post.*, 
                                    `post.cout` + 1 as `post.reward`
                                FROM (
                                    SELECT 
                                        *,
                                        (<calcul>) as `post.cout`
                                    FROM Post
                                )
                        */
                        case 'Select':
                            return debugRef('SELECT: répétition de $' + cheminComplet) + '(' + this.corrigerReferences(this.query.select.selected[cheminComplet], cheminComplet) + ')'
                            return debugRef('SELECT (ref locale)') + '(SELECT `' + cheminComplet + '`)'
                        default:
                            complementErreur = `Déclaration de ${match} trouvée dans le SELECT, mais les champs calculés ne sont pas accessibles depuis cette clause. Recherche de la référence ailleurs ... Si c'est la valeur déclarée dans le select qui doit être utilisée, ` + (this.nom === 'Where'
                                ? `préférer l'utilisation de HAVING pour cette condition.`
                                : `et que le champ ${cheminComplet} a été importé depuis un scope avec WITH, voir pour importer ce scope via un FROM au lieu d'un WITH.`
                            )
                            this.log(`[corrigerReferences] ` + complementErreur);
                            break;
                    }
            }

            // Décomposition du chemin
            const branchesParent = cheminComplet.split('.');
            if (branchesParent.length === 0) // branchesParent doit contenir au moins 1 élément, car la branche ne peut être vide
                throw ErreurReference(`Chemin vide`);

            // Transfomation du chemin en référence de champ MySQL
            // On itère d'abord les références les chemins les plus longs
            // S'arrête lorsque branchesParent n'est composé que d'une seule branche
            // parent: taches.post.interactionsAapprouver      branche: id
            // parent: taches.post                             branche: interactionsAapprouver.id
            // parent: taches                                       branche: post.interactionsAapprouver.id
            const branchesEnfant: string[] = [];
            let parent: string, enfant: string;
            do {

                branchesEnfant.unshift(branchesParent.pop() as string);

                parent = branchesParent.join('.');
                enfant = branchesEnfant.join('.');

                if (parent === '') continue;

                // Référence à une colonne sélectionnée dans l'une des tables jointes (forcémment préfixée)
                // Prioritaire par rapport aux références vers la table FROM, vu qu'elles sont plus spécifiques
                if (parent in this.query.join.liste) {

                    return debugRef('JOIN $' + parent) + '`' + parent + '`.`' + enfant + '`';
                }

            } while (branchesParent.length > 1)

            // Référence à une colonne sélectionnée dans la table FROM (prefixée manuellement)
            // SELECT `taches`.`id` FROM MissionTache `taches`
            // SELECT `taches`.`post.id` FROM MissionTache `taches`
            if (this.query.from?.aliasManuel === true && parent !== '' && this.query.from.alias === parent && (enfant in this.query.from.table.colonnes)) {

                return debugRef('FROM (alias manuel)') + '`' + this.query.from.alias + '`.`' + enfant + '`';

            }

            // Référence à une colonne sélectionnée dans la table FROM (non-préfixée)
            // SELECT `id` FROM MissionTache
            // SELECT `post.id` FROM MissionTache
            if (this.query.from?.aliasManuel === false && (cheminComplet in this.query.from.table.colonnes)) {

                return debugRef('FROM (sans alias)') + '`' + this.query.from.alias + '`.`' + cheminComplet + '`';

            }

            // Pas trouvé, mais possibilité qu'une valeur externe soit fournie sous forme de paramètre
            if (refParam === ':') {

                // transformation en placeholder paramètre simple
                this.log(`Référence ${match} non-trouvée. Transformation en paramètre externe.`);
                return debugRef('Fallback param') + ':' + cheminComplet;

            }
            
            // Non trouvé
            console.log(`Jointures:`, Object.keys(this.query.join.liste));
            console.log(`Alias from:`, this.query.from?.alias, 'aliasManuel =', this.query.from?.aliasManuel);
            console.log(`Déclarations select:`, this.query.select.declarations);
            
            throw ErreurReference(`La référence n'a pas été trouvée. Déclaration manquante ?`);

        });
    }

    protected restituerSubqueries(sql: string) {
        return sql/*.replace(regPlaceholder, (placeholder) => {

            const idSubquery = placeholder.substring(1, placeholder.length - 1);

            const subquery = QueryParser.fromId(idSubquery);

            return '(' + subquery.getSql() + ')';

        });*/
    }
}