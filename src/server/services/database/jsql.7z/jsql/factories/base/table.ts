/*----------------------------------
- DEPENDANCES
----------------------------------*/

/**
* ! Ne pas importer le parser depuis les factories
*   Celui-ci dépend de factories/index, qui importe tous les factories, 
*   ce qui créé une référence circulaire table => parser => factories => from => table
* * C'est pourquoi les scopes sont compilés lors du boot du serveur, et non à la demande
**/

// Libs métier
import Factory from '.'
import Db from '@server/services/database';
import ModelsManager from '@server/services/models/manager';
import { parseArgs } from '../../parser/regex';
import QueryParser from '../../query/base';
//import semantique, { blockToString } from '@common/data/chaines/semantique';

/*----------------------------------
- TYPES
----------------------------------*/

import type { TMetasTable } from '@server/services/database/metas';

/*----------------------------------
- CONSTANTES
----------------------------------*/

/*----------------------------------
- FACTORY
----------------------------------*/
export default abstract class InstructionAvecTable<TKeyword extends string | unknown = unknown> extends Factory<TKeyword> {

    public type!: 'Scope' | 'Table' | 'Modèle' | 'Subquery' | 'Association';
    public cheminOriginal?: string;

    public table!: TMetasTable | QueryParser;
    public tableReele!: TMetasTable;
    public alias!: string;
    public aliasManuel: boolean = false;

    public replacements?: {[placeholder: string]: string} // Remplacements JSQL brut

    protected parseTable(table: string, alias: string | undefined, replacementsStr?: string) {

        this.replacements = parseArgs(replacementsStr)

        if (alias !== undefined) {
            this.alias = alias;
            this.aliasManuel = true;
        }

        const chemin = table;
        const branches = chemin.split('.')

        // ID subquery
        if (chemin[0] === '{') {

            const idSubquery = chemin.substring(1, chemin.length - 1);
            this.log('Subquery ' + idSubquery + (alias ? '(alias: ' + alias + ')' : ''));

            const subquery = QueryParser.fromId(idSubquery);

            this.table = subquery;
            this.type = 'Subquery';
            this.cheminOriginal = idSubquery;

            if (subquery.from === undefined)
                throw this.Erreur(`Impossible de déterminer la table réelle, car aucune clause FROM n'a été trouvée dans la sous-requête spécifiée dans la clause ${this.nom}.`);
            
            this.tableReele = subquery.from.tableReele;

        // Nom Modèle: Post
        } else if (branches.length === 1) {

            this.log('Modèle ' + table + (alias ? '(alias: ' + alias + ')' : ''));

            this.type = 'Modèle';
            const modele = ModelsManager.modeles[table];

            if (modele === undefined)
                throw this.Erreur(`Le modèe « ${table} n'a pas été trouvé dans ModelManager. Modèles référencés: ${Object.keys(ModelsManager.modeles).join(', ')} »`);

            // Chemin complet de la table
            this.table = modele.metas.tables.default;
            this.tableReele = this.table;

        // Table: advertise.Post
        } else if (branches.length === 2 && (branches[0] in Db.tables)) {

            this.log('Table ' + table + (alias ? '(alias: ' + alias + ')' : ''));

            // Séparation database / nom table
            const database = branches.shift() as string; // Pas undefined, car au moins 1 item
            table = branches.join('.');

            // Récupération des informations de la table
            if (Db.tables[database] === undefined)
                throw this.Erreur(`La base de données « ${database} » n'a pas été répertoriée dans Database.tables. ${chemin} fait-il référence à un scope qui n'a pas été indexé / compilé ?`)
            if (Db.tables[database][table] === undefined)
                throw this.Erreur(`Les métadonnées pour la table « ${chemin} » n'ont pas été trouvées.`);

            this.type = 'Table';

            // Chemin complet de la table
            this.table = Db.tables[database][table]
            this.tableReele = this.table;

        // Vue ou procédure: Post.PourAffichage.Interactif
        } else if (branches[0] in ModelsManager.modeles) {

            this.log('Scope ' + chemin + (alias ? '(alias: ' + alias + ')' : ''));

            // Compilation si pas déjà fait
            const scope = ModelsManager.getScope(chemin)

            this.table = scope;
            this.type = 'Scope'
            this.cheminOriginal = chemin;

            // Vérif si les paraètres requis par le scope à importer sont bien fournis par la requete actuelle (si scope)
            if (this.query.type === 'scope') {

                for (const nomParam in scope.parametres) {
                    const paramRequis = scope.parametres[nomParam];
                    const paramPresent = this.query.parametres[nomParam];

                    if (paramPresent === undefined)
                        throw this.Erreur(`Le paramètre :${nomParam} est requis pour l'importation du scope ${scope.id}, mais n'a pas été déclaré dans la requete actuelle (${this.query.id}). Liste des paramètres déclarés: ` + Object.keys(this.query.parametres).join(', '));

                    if (paramPresent.type !== paramRequis.type)
                        throw this.Erreur(`Le type du paramètre :${nomParam} déclaré dans la requete actuelle ${this.query.id} (${paramPresent.type}) est incompatible avec le type requis pour l'importation du scope ${scope.id} (${paramRequis.type})`);
                }

            }

            if (scope.from === undefined) {
                console.error(scope);
                throw this.Erreur(`Impossible de déterminer la table réelle, car aucune clause FROM n'a été trouvée dans ${scope.id} spécifié dans la clause ${this.nom}. Instructions brutes ci-dessus.`);
            }

            this.tableReele = scope.from.tableReele;

        } else
            throw this.Erreur(`La référence vers « ${chemin} » n'a été reconnue ni en tant que modèle, ni en tant que table, ni en tant que scope, ni en tant que subquery. S'agit-il d'un scope qui n'a pas été réféencé via le décorateur @Scopes ?`);
        
        if (this.alias === undefined) {

            /*if (this.tableReele == undefined)
                console.log('tableReele', this.tableReele);*/

            this.alias = this.tableReele.alias;

            /*console.log('ALIAS TABLE', this.table, this.tableReele);
            throw this.Erreur(`Impossible de déterminer l'alias de la table.`);*/

        }
    }

    protected toTableSql(): string {

        // Transformation de la table en chaine
        let tableStr: string;
        if (this.table instanceof QueryParser) {

            // procédure = sql de la query (besoin d'inclure son sql complet car besoin de passer des paramètres, ce qui n'est pas possible pour les vues)
            const sousRequete = this.table.getSql({
                replacements: this.replacements
            })

            tableStr = '(' + sousRequete + ')';

        // TMetasTable
        } else {

            tableStr = this.table.chemin;

        }

        let provenance = this.type;
    
        if (this.cheminOriginal !== undefined) {

            provenance += ' ' + this.cheminOriginal;

        }
        return '/* [source] ' + provenance + ' */ ' + tableStr + ' as `' + this.alias + '`';
    }
}