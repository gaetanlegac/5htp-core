import { regParamExterne, regReferences } from '../../parser/regex';
import { regexWith } from '@common/data/regex';

const regEgaliteParam = regexWith(/(?<reference>{:regReferences}) (?<not>\!)?\= (?<param>{:regParamExterne})/gi, { regParamExterne, regReferences });

export const corrigerEgalites = (jsql: string) => {

    if (!jsql.includes(':')) return jsql;

    // $valeur = :param => IF( :param IS NULL, $valeur IS NULL, $valeur = :param )
    // $valeur != :param => IF( :param IS NULL, $valeur IS NOT NULL, $valeur != :param )
    const retour = jsql.replace(regEgaliteParam, (...args: any[]) => {

        const { reference, not, param } = args[args.length - 1]

        return not === undefined
            ? 'IF( ' + param + ' IS NULL, ' + reference + ' IS NULL, ' + reference + ' = ' + param + ' )'
            : 'IF( ' + param + ' IS NULL, ' + reference + ' IS NOT NULL, ' + reference + ' != ' + param + ' )'
    });

    return retour;

}