/*----------------------------------
- DEPENDANCES
----------------------------------*/

// Libs métier
import factories, { TTypeInstruction } from '..';
import Factory, { TInstructionBrute } from '.'

/*----------------------------------
- TYPES
----------------------------------*/

/*----------------------------------
- CONTAINER
----------------------------------*/
export default abstract class FactoriesContainer<TFactory extends Factory, TKeyword extends string = string> extends Factory<TKeyword> {

    public static isContainer = true;
    public liste: { [alias: string]: TFactory } = {}

    protected static ChildClass: typeof Factory;

    /*----------------------------------
    - INSTRUCTIONS BRUTES
    ----------------------------------*/
    protected mergeAll(): TInstructionBrute<TKeyword> | undefined {

        // Fusion en une instruction
        if (this.raw.length === 0)
            return undefined;

        return this.raw[0]

    }

    /*----------------------------------
    - METADONNEES
    ----------------------------------*/
    public parseInstructions() {

        for (const instruction of this.raw) {

            const join = new this.constructor.ChildClass(this, instruction)

            join.parseInstructions();

            if (join.cancel !== true)
                this.liste[join.alias] = join;

        }

    }

    // Le parsin a lieu dans les instances spécialisées (ChildClass)
    protected parse() {

        return true;

    }


}