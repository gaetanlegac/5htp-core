/*----------------------------------
- DEPENDANCES
----------------------------------*/

// Libs métier
import FactoriesContainer from './base/container'
import QueryRunner from '../query/runner';

import With, { TKeyword } from './with';

/*----------------------------------
- TYPES
----------------------------------*/

type TWithAbstrait = (
    (string | QueryRunner)[]
)

/*----------------------------------
- CONSTANTES
----------------------------------*/



/*----------------------------------
- FACTORY
----------------------------------*/
export default class WithContainer extends FactoriesContainer<With, TKeyword> {

    public static keywords = With.keywords
    protected static ChildClass = With;

    /*----------------------------------
    - ABSTRACTION
    ----------------------------------*/

    /*----------------------------------
    - ABSTRACTION
    ----------------------------------*/
    public static serialize(input: TWithAbstrait, data: object): string {

        let sql: string[] = []

        for (const scope of input) {

            if (typeof scope === 'string')
                sql.push('WITH ' + scope);
            else {
                sql.push('WITH ' + scope.ast.id);

                for (const cle in scope.data)
                    data[cle] = scope.data[cle]
            }

        }

        return sql.join(' ');


    }
    /*----------------------------------
    - CONSTRUCITON SQL
    ----------------------------------*/
    public toSql(): string {
        return '';
    }
}