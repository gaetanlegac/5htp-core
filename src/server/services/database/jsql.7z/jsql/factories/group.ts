/*----------------------------------
- DEPENDANCES
----------------------------------*/
import Factory, { TInstructionBrute } from './base'

/*----------------------------------
- TYPES
----------------------------------*/

import QueryParser from '../query/base';

/*----------------------------------
- CONSTANTES
----------------------------------*/



/*----------------------------------
- FACTORY
----------------------------------*/
type TKeyword = 'GROUP BY'
export default class Group extends Factory<TKeyword> {

    public static keywords = ['GROUP BY'] as TKeyword[]
    public static regex = undefined;

    public champs!: string;

    /*----------------------------------
    - ABSTRACTION
    ----------------------------------*/
    public static serialize(input: string | string[]): string {
        return 'GROUP BY ' + (typeof input == 'string' ? input : input.join(', '))
    }

    /*----------------------------------
    - INSTRUCTIONS BRUTES
    ----------------------------------*/
    protected mergeAll(): TInstructionBrute<TKeyword> | undefined {

        // Fusion en une instruction
        if (this.raw.length === 0)
            return undefined;
        
        return { 
            keyword: 'GROUP BY', 
            sql: this.raw.map(({ sql }) => sql).join(', ') 
        }
        
    }

    /*----------------------------------
   - METADONNEES
   ----------------------------------*/
    protected parse(keyword: TKeyword, champs: string) {

        this.champs = champs;

        return true;
       
    }

    /*----------------------------------
    - CONSTRUCTION SQL
    ----------------------------------*/
    public toSql(): string {

        return 'GROUP BY ' + this.corrigerReferences( this.champs );
    }
}