/*----------------------------------
- DEPENDANCES
----------------------------------*/

// Libs métier
import FactoriesContainer from './base/container'
import Join, { TKeyword } from './join';
import { SqlLiteral, genConditions, TCondition } from './abstraction/conditions';

/*----------------------------------
- TYPES
----------------------------------*/

type TOptsJointureAbstraite = { name: string, join?: TJointureAbstraite, where?: TCondition }

type TJointureAbstraite = (
    (
        string
        |
        TOptsJointureAbstraite
    )[]
    |
    {
        [nom: string]: (
            SqlLiteral
            |
            true
            |
            Omit<TOptsJointureAbstraite, 'name'>
        )
    }
)


/*----------------------------------
- CONSTANTES
----------------------------------*/


/*----------------------------------
- FACTORY
----------------------------------*/
export default class JoinContainer extends FactoriesContainer<Join, TKeyword> {

    protected static ChildClass = Join;
    public static keywords = Join.keywords

    /*----------------------------------
    - ABSTRACTION
    ----------------------------------*/
    public static serialize(input: TJointureAbstraite, queryData: object = {}, prefixe: string[] = []): string {
        let retour: string[] = []

        let index: keyof typeof input;
        for (index in input) {

            const jointure = input[index];

            // { alias: true }
            if (jointure === true)
                retour.push(`JOIN $` + [...prefixe, index].join('.'));

            // [alias]
            else if (typeof jointure === 'string')
                retour.push(`JOIN $` + [...prefixe, jointure].join('.'));

            // { alias: Sql(`...`) }
            // [Sql(`...`)]
            else if (jointure.constructor.name === 'SqlLiteral')
                retour.push(jointure.sql);

            // { alias: { join: TJointureAbstraite, where: TCondition } }
            // [{ name: alias, join: TJointureAbstraite, where: TCondition }]
            else {

                const nom = jointure.name || index;
                const cheminJointure = [...prefixe, nom];
                const cheminStr = cheminJointure.join('.');

                let sql = `JOIN $` + cheminStr

                if (jointure.where !== undefined)
                    sql += ' ON ' + genConditions(jointure.where, queryData, 'AND', cheminStr)

                retour.push(sql);

                if (jointure.join !== undefined)
                    retour.push(JoinContainer.serialize(jointure.join, {}, cheminJointure));

            }

        }

        return retour.join('\n')
    }

    public add(keyword: TKeyword, sql: string, opts: Omit<TInstructionBrute, 'sql' | 'keyword'>): this;
    public add(keyword: TKeyword, sql: string, opts: Omit<TInstructionBrute, 'sql' | 'keyword'>, parse: true): Join;
    public add(keyword: TKeyword, sql: string, opts: Omit<TInstructionBrute, 'sql' | 'keyword'> = {}, parse?: true): this | Join {

        const instruction = super.add(keyword, sql, opts);

        if (parse) {

            const join = new Join(this, instruction)

            join.parseInstructions();

            this.liste[join.alias] = join;

            return join;

        } else {

            return this;

        }
    }

    /*----------------------------------
    - CONSTRUCTION SQL
    ----------------------------------*/
    protected toSql(): string {
        let retour: string[] = []
        for (const alias in this.liste) {
            const sql = this.liste[alias].getSql()
            if (sql !== undefined)
                retour.push(sql);
        }
        return retour.join('\n')
    }

    
}