/*----------------------------------
- DEPENDANCES
----------------------------------*/

/**
* ! Ne pas importer le parser depuis les factories
*   Celui-ci dépend de factories/index, qui importe tous les factories,
*   ce qui créé une référence circulaire table => parser => factories => from => table
* * C'est pourquoi les associations à base de query brute (attribut.query) sont compilées lors du boot du serveur, et non à la demande
**/

// Libs métier
import { TInstructionBrute } from './base'
import FactoryAvecTable from './base/table'
import { regexTable, regReferenceLocale, decompChemin } from '../parser/regex';
import { SqlLiteral, genConditions, TCondition } from './abstraction/conditions';
import { corrigerEgalites } from './base/egalites';

// Libs
import { regexWith } from '@common/data/regex';

/*----------------------------------
- TYPES
----------------------------------*/

import type JoinContainer from './joinContainer';

import { TMetasTable, TAssociation, TMetasColonne } from '@server/services/database/metas';
import { TMetasAttribut } from '@server/services/models/attributes';

/*----------------------------------
- CONSTANTES
----------------------------------*/

/*----------------------------------
- FACTORY
----------------------------------*/
export type TKeyword = 'LEFT OUTER JOIN' | 'RIGHT OUTER JOIN' | 'INNER JOIN' | 'LEFT JOIN' | 'RIGHT JOIN' | 'JOIN'
export default class Join extends FactoryAvecTable<TKeyword> {

    public static keywords = ['LEFT OUTER JOIN', 'RIGHT OUTER JOIN', 'INNER JOIN', 'LEFT JOIN', 'RIGHT JOIN', 'JOIN'] as TKeyword[]

    public static regex = regexWith(
        /^(?:(MANY|ONE)\s+)?(?:{:regexTable}\s+)?(?:(?:as\s+)?{:regReferenceLocale})+(?:\s+ON\s+([\s\S]+))?/g,
        { regexTable, regReferenceLocale }
    );

    public container: JoinContainer;

    public contraintes?: string;
    public required?: boolean; // Par défaut: requis quand hasone, optionnel quand hasmany
    public typeJointure?: TAssociation["type"];

    public keywords: TKeyword 

    public constructor(container: JoinContainer, instruction: TInstructionBrute<TKeyword>) {
        super(container.query)
        this.container = container;
        this.keywords = instruction.keyword;
        this.add(instruction.keyword, instruction.sql, instruction);
    }

    /*----------------------------------
    - INSTRUCTIONS BRUTES
    ----------------------------------*/
    protected mergeAll(): TInstructionBrute<TKeyword> | undefined {

        // Fusion en une instruction
        if (this.raw.length === 0)
            return undefined;

        return this.raw[0]

    }

    /*----------------------------------
    - METADONNEES
    ----------------------------------*/
    protected parse( 
        keyword: TKeyword,
        typeJointure: string | undefined,
        table: string | undefined, 
        replacements: string | undefined, 
        alias: string, 
        contraintes: string | undefined 
    ) {

        if (typeJointure === 'MANY')
            this.typeJointure = 'hasmany';
        else if (typeJointure === 'ONE')
            this.typeJointure = 'hasone';

        // Seul l'alias est spécifié = la jointure a déjà été définie, soit:
        // - Via une association dans la déclaration du modèle (@HasOne, @HasMany, @Join, ...)
        // - Plus tôt dans la requête JSQL
        // JOIN $metas
        // JOIN $post.metas
        if (table === undefined) {

            this.type = 'Association';
            this.alias = alias;
            this.cheminOriginal = alias;

        // Via référnce de table (chemin, id subquery, ...)
        // JOIN Post.PourPublic $post
        // JOIN {1b0d4547-930c-305c-8569-ecf5f4c9e89f} $post
        // JOIN advertise.Missions $mission ON $mission.id = $mission_id
        } else {

            this.contraintes = contraintes;

            this.parseTable(table, alias, replacements);
        }

        // Extraction chemin de la tableà joindre + nom attribut association
        const [cheminJointure, nomAsso] = decompChemin(alias);
        let tableAjoindre: TMetasTable;
        if (cheminJointure === undefined) { // Association de la table principale

            if (this.query.from === undefined)
                throw this.Erreur(`Impossible de générer la jointure sur ${this.alias} car la clause FROM est requise pour pouvoir déterminer le modèle.`);

            tableAjoindre = this.query.from.tableReele;

        } else { // Association d'une table jointe

            /* 
                TODO: Recup jointure mère via jointure établie dans sous-requete from
            */

            let jointureMere = this.query.join.liste[cheminJointure];
            if (jointureMere === undefined) {

                this.log(`Jointure automatique via le sélecteur « ${cheminJointure}.* »`);

                // Jointure automatique
                jointureMere = this.query.join.add('JOIN', '$' + cheminJointure, {}, true);
            }
            // Si la jointure mère est optionnelle, la jointure fille l'est égalemement vu que absence des données mères = absence des données filles
            if (jointureMere.required === false)
                this.required = false;

            tableAjoindre = jointureMere.tableReele

        }

        // Récupère les infos de l'association correspondant à l'alias donné (si applicable)
        let objRelation: TMetasColonne | TMetasAttribut | undefined;

        // Via jointure déja établie auparavant
        if (nomAsso in this.query.join.liste) {

            const existante = this.query.join.liste[ nomAsso ] as Join;

            // Completion des contraintes
            if (contraintes !== undefined)
                existante.contraintes += ' /* via extension requete */ AND ' + contraintes;

            // On ne créé pas de nouvelle jointure
            this.cancel = true;
            return;

        // Via association déclaration modèle
        } else if (tableAjoindre.modele?._attributes[nomAsso] !== undefined) {
            objRelation = tableAjoindre.modele._attributes[nomAsso];
        // Via association BDD
        } else {
            objRelation = tableAjoindre.colonnes[nomAsso];
        }
        const asso: TAssociation | undefined = objRelation?.association;
        if (asso === undefined) {

            // Jointure composant sur l'alias = indispensable d'avoir les infos de l'association
            if (table === undefined)
                throw this.Erreur(`Impossible d'importer la jointure ${nomAsso}, car aucune jointure portant ce nom n'a été déclarée au préalable, et aucune association n'a été trouvée sur l'attribut du modèle et la colonne de la table.`);

        // Via sous-requee
        } else if (asso.mode === 'query') {

            asso.query.prebuild();

            // Une seule donnée retournée = ajout au sélect au lieu de créer une jointure
            const champUnique = Object.keys(asso.query.colonnes).length === 1
            if (champUnique) {

                // Ajout de la subquery au select 
                // RAPPEL: Les instructions select sont traitées APRÈS les instructions join et from
                this.query.select.add('SELECT', '{' + asso.query.id + '} as $' + this.alias);

                // On annule la création du sql pour le join, vuque ce dernier a été transformé en select
                this.cancel = true;
                return;

            } else {

                this.parseTable('{' + asso.query.id + '}', alias);
                this.required = true;

            }

        // Jointure issue d'une association
        } else if (asso.mode === 'relation') {

            // Hérite des options de l'association si pas de valeur spécifiée pour cette requete
            if (this.required === undefined)
                this.required = asso.required;

            if (this.typeJointure === undefined)
                this.typeJointure = asso.type;

            // Extraction infos colonnes
            let colLocale: TMetasColonne, colJointure: TMetasColonne;
            if (asso.reverse === false)
                ({ pk: colJointure, fk: colLocale } = asso);
            else
                ({ pk: colLocale, fk: colJointure } = asso);

            // Etablissement de la relation de base
            // NOTE: On utilise une référence directe (avec quotes) à la colonne coté jointure, 
            //      Car on sait déjà précisément sur quoi pointe la référence
            this.contraintes = '/* via pk & fk */`' + alias + '`.`' + colJointure.nom + '` = $' + (cheminJointure === undefined ? '' : cheminJointure + '.') + colLocale.nom;

            // Nom de table auto
            if (this.table === undefined)
                this.table = this.tableReele = colJointure.table;

            // Contraintes via asso
            if (asso.where !== undefined)
                this.contraintes += ' /* via opts.where */ AND ' + genConditions(asso.where, {}, 'AND', alias);

        }

        // Keywords auto
        if (this.keywords === 'JOIN')
            this.keywords = this.required === true ? 'INNER JOIN' : 'LEFT OUTER JOIN';

        // Contraintes manuelles
        if (contraintes !== undefined)
            this.contraintes += ' /* via requete */ AND ' + contraintes;

        // Référencement de la jointure auprès de la requête mère
        this.query.references[this.alias] = this;
       
    }

    /*----------------------------------
    - CONSTRUCTION SQL
    ----------------------------------*/
    protected toSql(): string | undefined {

        let retour = this.keywords + ' ' + this.toTableSql();

        if (this.contraintes !== undefined)
            retour += ' ON ' + corrigerEgalites( this.contraintes )

        // Corrige les références sur les contraintes ET la table (qui peut être une Query contenant des référnences aux colonnes de la query mère, càd a query actuelle)
        return this.corrigerReferences( retour );
    }
}