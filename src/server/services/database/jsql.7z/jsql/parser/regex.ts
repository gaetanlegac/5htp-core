import { regexWith } from '@common/data/regex';

export const regBrancheReference = /[a-zA-Z0-9\_\-\*]+/

export const regConstantes = regexWith(
    /\#((?:({:regBrancheReference})\.?)+)/g,
    { regBrancheReference }
)

// Références de champs
// $post
// $post.id
// $$post.id
export const regReferences = regexWith( 
    /\$(\$*)(:?)((?:({:regBrancheReference})\.?)+)/g,
    { regBrancheReference }
)

// :reference
export const regParamExterne = regexWith(/\{?:((?:({:regBrancheReference})\.?)+)\}?/g, { regBrancheReference });

// $reference
export const regReferenceLocale = regexWith( 
    /\$((?:{:regBrancheReference}\.?)+)/,
    { regBrancheReference }
)
export const regReferenceSeule = regexWith(/^{:regReferences}$/, { regReferences })

// as $reference
export const regDeclarationSelect = regexWith( /\s+as (?<prefixe>\$|\#)(?<alias>(?:{:regBrancheReference}\.?)+)$/ , { regBrancheReference });

export const regPlaceholder = /\{[a-z0-9\-]+\}/g;

// advertise.Posts
// Post.PourCreateur( :utilisateur )
// {48cbb954-6ad0-4538-9113-1ea510281549}
// https://regexr.com/5o873
export const regexTable = regexWith(
    /(?:((?:[A-Za-z]\.?)+|(?:{:regPlaceholder})))(?:\s*\(\s*([^\)]+)\s*\))?/,
    // Le support des arguments a été viré
    //(?:((?:[A-Za-z]\.?)+|(?:{:regPlaceholder})))/,
    { regPlaceholder }
)

export const parseArgs = (argsStr: string | undefined) => {

    if (argsStr === undefined)
        return undefined;

    const listeArgs = argsStr.split(' ; ');
    const args: { [cle: string]: string } = {}
    for (const arg of listeArgs) {
        const [cle, val] = arg.split(':');
        args[cle.trim()] = val.trim()
    }

    return args;

}


// Entrée: decompChemin('interactionsAapprouver.eventCompletion.hash', 1)
// Sortie: ['interactionsAapprouver.eventCompletion', 'hash']

// Entrée: decompChemin('interactionsAapprouver.eventCompletion.hash', 2)
// Sortie: ['interactionsAapprouver', 'interactionsAapprouver.eventCompletion', 'hash']
export const decompChemin = (cheminComplet: string, niveaux: number = 1): [...(string | undefined)[], string] => {

    const chemin = cheminComplet.split('.');
    const branche = chemin.pop();

    if (branche === undefined)
        throw new Error(`Erreur: le chemin passé est vide`);

    let retour: (string | undefined)[] = []
    for (let niveauA = 1; niveauA <= niveaux; niveauA++) {
        retour.unshift( chemin.length === 0 ? undefined : chemin.join('.') );
        chemin.pop();
    }

    return [...retour, branche]
}