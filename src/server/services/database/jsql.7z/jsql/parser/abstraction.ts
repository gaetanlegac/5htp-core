import factories, { TTypeInstruction, } from '../factories';

export type TQueryAbstraite = Partial<{ [cle in TTypeInstruction]: Parameters<(typeof factories[cle])["serialize"]>[0] }>

export const objToJsql = (query: TQueryAbstraite, data: object = {}) => {

    let strings: string[] = []
    let instruction: TTypeInstruction
    for (instruction in factories) {

        if (!(instruction in query))
            continue;

        const Factory = factories[instruction];
        if (!("serialize" in Factory))
            throw new Error(`Aucune méthode n'a été spécifiée dans le factory « ${instruction} » pour convertir les objets d'abstraction en requete JSQL.`);

        const jsql = Factory.serialize(query[instruction], data)
        if (jsql === null)
            continue;

        strings.push(jsql);
    }
    //console.log("Sérialisation", query, strings, data);
    return { jsql: strings.join('\n'), data }
}