/*----------------------------------
- DEPENDANCES
----------------------------------*/
import dayjs from 'dayjs';

/*----------------------------------
- TYPES
----------------------------------*/

import { TMetasAttribut } from '../models/metas';

/*----------------------------------
- MYSQL
----------------------------------*/
export type TTypeColonne = 'INT' | 'TINYINT' | 'DATE' | 'DATETIME' | 'STRING' | 'SET' | 'JSON' | 'ENUM';
export const mysql: {
    [id in TTypeColonne]: {
        js: TTypeJs,
        serialize?: (val: any, attribut: TMetasAttribut) => any,
        deserialize?: (val: any, attribut: TMetasAttribut) => any,
    }
} = {

    // Nombres
    INT: {
        js: 'int',
        serialize: (val: number) => val,
        deserialize: (val: string) => val,
    },
    // RAPPEL: Dans mysql, BOOLEAN est en fait un TINYINT
    TINYINT: {
        js: 'boolean',
        serialize: (val: boolean | number, attribut: TMetasAttribut): number => {

            if (val === true)
                val = 1;
            else if (val === false)
                val = 0;

            return val;

        },
        deserialize: (val: string) => val,
    },

    // Dates
    DATE: {
        js: 'date',
        serialize: (val: Date) => dayjs(val).format('YYYY-MM-DD'),
        deserialize: (val: string) => new Date(val),
    },
    DATETIME: {
        js: 'date',
        serialize: (val: Date) => dayjs(val).format('YYYY-MM-DD HH:mm:ss'),
        deserialize: (val: string) => new Date(val),
    },

    // Chaines
    STRING: {
        js: 'string',
        serialize: (val: number) => val,
        deserialize: (val: string) => val,
    },
    SET: {
        js: 'array',
        serialize: (val: string[]) => val.join(','),
        deserialize: (val: string) => val.split(','),
    },

    // Autres
    JSON: {
        js: 'object',
        serialize: (val: string | object) => JSON.stringify(val),
        deserialize: (val: string) => val,
    },
}

/*----------------------------------
- JS
----------------------------------*/
export type TTypeJs = 'array' | 'string[]' | 'number' | 'boolean' | 'Date' | 'string';
export const js: {
    [id in TTypeJs]: {
        mysql: TTypeColonne,
        serialize?: (val: any, attribut: TMetasAttribut) => any,
        deserialize?: (val: any, attribut: TMetasAttribut) => any,
    }
} = {

    // Conteneurs
    array: {
        mysql: 'SET'
    },
    'string[]': {
        mysql: 'STRING',
        serialize: (val: string[]) => val.join(','),
        deserialize: (val: string) => val.split(','),
    },

    // Nombres
    number: {
        mysql: 'INT'
    },
    boolean: {
        mysql: 'TINYINT',
        //serialize: (val: string[]) => val.join(','),
        deserialize: (val: any): boolean => {

            if (typeof val === 'number')
                return val === 1;
            else
                return !!val;

        },
    },

    // Dates
    Date: {
        mysql: 'DATETIME',
    },

    // Chaines
    string: {
        mysql: 'STRING',
    },
}