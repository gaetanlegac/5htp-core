/*----------------------------------
- DEPENDANCES
----------------------------------*/

// Npm
import mysql from 'mysql2/promise';

// Libs
import Database, { TOptsQuery } from '..';
import Query, { TParamModele, TObjDonnees } from '.';

/*----------------------------------
- TYPES
----------------------------------*/

export type TOptsInsert = TOptsQuery & {

}

/*----------------------------------
- SERVICE
----------------------------------*/
export default class InsertQuery<TModele extends TParamModele = unknown> extends Query<InsertQuery<TModele>, TModele> {

    public async insert(valeurs: Partial<TModele>, donneesAupdate?: string[], opts?: TOptsQuery): Promise<string> {

        return await this.execute(valeurs, donneesAupdate, opts);

    }

    public getSQL(valeurs: Partial<TModele>, finaliser: boolean, donneesAupdate?: string[]) {

        let assignements: string[] = []

        // Assignement données spécifiques à la table
        for (const colonne in valeurs)
            assignements.push(colonne + ' = ' + mysql.escape(valeurs[colonne]));

        if (assignements.length === 0)
            return null;

        // Query sql de base
        let insert: string = 'INSERT INTO ' + this.table.chemin + ' SET ' + assignements.join(', ')

        // Upsert
        if (donneesAupdate !== undefined) {
            const assignements = donneesAupdate.map(cle => cle + ' = ' + mysql.escape(valeurs[cle]));
            insert += ' ON DUPLICATE KEY UPDATE ' + assignements.join(', ');
        }

        // L'insertion e la table defaut doit se faire avant les tables secondaires, 
        // ces dernières ayant besoin de l'id de la table default
        return insert;
    }

    public async execute(valeurs: Partial<TModele>, donneesAupdate?: string[], opts?: TOptsQuery): Promise<string> {

        //console.log('EXECINSERT', valeurs);

        const sql = this.getSQL(valeurs, true, donneesAupdate);

        if (sql === null)
            return '';

        const retour = await Database.insert(sql, this.sql.data, {
            simuler: this.simuler,
            ...opts
        });

        return retour.insertId;

    }

}