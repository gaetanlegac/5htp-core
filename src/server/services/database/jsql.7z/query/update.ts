/*----------------------------------
- DEPENDANCES
----------------------------------*/

// Npm
import mysql from 'mysql2/promise';

// Libs
import Database, { TOptsQuery } from '..';
import Query, { TParamModele, TObjDonnees } from '.';

/*----------------------------------
- TYPES
----------------------------------*/

export type TOptsUpdate = TOptsQuery & {

}

/*----------------------------------
- SERVICE
----------------------------------*/
export default class UpdateQuery<TModele extends TParamModele = unknown> extends Query<UpdateQuery<TModele>, TModele> {

    public async update(valeurs: Partial<TModele>, opts?: TOptsQuery) {

        if (opts !== undefined)
            this.set(opts);

        await this.execute(valeurs);

    }

    public getSQL(valeurs: Partial<TModele>, finaliser: boolean) {

        let assignements: string[] = []

        // Assignement données spécifiques à la table
        for (const colonne in valeurs)
            assignements.push(colonne + ' = ' + mysql.escape(valeurs[colonne]));

        if (assignements.length === 0)
            return null;

        // Prefixage
        this.buildSQL(finaliser);

        // Construction
        let update = 'UPDATE ' + this.table.chemin + ' as `' + this.table.alias + '`' + ' SET ' + assignements.join(', ');

        if (this.sql.where.length !== 0)
            update += ' WHERE ' + this.sql.where.join(' AND ');

        return update;

    }

    public async execute(valeurs: Partial<TModele>): Promise<number> {

        const sql = this.getSQL(valeurs, true);

        if (sql === null)
            return 0;

        const retour = await Database.update(sql, this.sql.data, {
            simuler: this.simuler
        });

        return retour.affectedRows;

    }

}