/*----------------------------------
- DEPENDANCES
----------------------------------*/

// Libs
import Database from '..';
import Query, { TParamModele, TObjDonnees, SqlLiteral, TCritere, TWhere, TOptsQuery } from '.';
import { Introuvable } from '@common/errors';

/*----------------------------------
- TYPES: IMPORTATIONS
----------------------------------*/

import { TMetasModele, TMetasAttribut, TMetasColonne } from '../../models/metas';

/*----------------------------------
- TYPES: DEFINITIONS
----------------------------------*/

type TSelect = string | string[] | { [alias: string]: string | SqlLiteral }
type TJoin = (TOptsJoin | string)[] | { [alias: string]: Omit<TOptsJoin, 'name'> | SelectQuery | SqlLiteral | true }
type TOrder = string | string[]
type TGroup = string | string[]
type THaving = TCritere
type TLimit = number | false

export type TOptsSelect = TOptsQuery & {
    select: TSelect,
    join: TJoin,
    where: TWhere,
    order: TOrder,
    limit: TLimit,
    group: TGroup,
    having: THaving,

    raw: boolean,
    required: boolean,

    // <type>, <colonne>
    operation: ['SUM' | 'COUNT', string | true]
}

// Rappel: Les jointures doivent absolument être identifiées par un id / nom / alias
type TOptsJoin = Partial<TOptsSelect> & { 
    name: string,
    as?: string
} & ({} | TRequeteJoin)

export type TRequeteJoin = { sql: string } | { query: SelectQuery }

export type TRawDataMap = { ''?: true } & { [branche: string]: TRawDataMap }

/*----------------------------------
- SERVICE
----------------------------------*/
export default class SelectQuery<TModele extends TParamModele = unknown> extends Query<SelectQuery<TModele>, TModele> {

    /*----------------------------------
    - PROPRIETES
    ----------------------------------*/
    protected static builders = {
        // On génère select après join, car ce dernier met à jour le select avec les champs de la table à joindre
        join: 'buildJoin',
        from: 'buildFrom',
        select: 'buildSelect',
        where: 'buildWhere',
        order: 'buildOrder',
        group: 'buildGroup',
        having: 'buildHaving',
    }

    protected ast: {
        select: TSelect[],
        join: {[nom: string]: TOptsJoin},
        where: TWhere[],
        order: TOrder[],
        group: TGroup[],
        having: THaving[],
        limit: TLimit,
        data: TObjDonnees,
    } = {
        select: [],
        join: {},
        where: [],
        order: [],
        group: [],
        having: [],
        limit: false,
        data: {}
    }

    // Généré via buildSQL
    protected sql: {
        select: string[],
        from: string[],
        join: {[nom: string]: string},
        where: string[],
        order: string[],
        group: string[],
        having: string[],
        limit: TLimit,
        data: TObjDonnees,
    } = {
        select: [],
        from: [],
        join: {},
        where: [],
        order: [],
        group: [],
        having: [],
        limit: false,
        data: {}
    }
    
    protected required: boolean = true;
    // Arborescence des données à instancier
    protected rawDataMap: TRawDataMap = {};

    public operation: { 
        type: string, 
        table_virt: string, 
        colonne_virt: string 
    } | undefined = undefined;

    /*----------------------------------
    - INITIALISATION
    ----------------------------------*/
    protected champsModele(modele: TMetasModele): string {
        return modele.colonnes.map(colonne => '$' + colonne + ' as $' + colonne).join(', ')
    }

    /*----------------------------------
    - LECTURE
    ----------------------------------*/
    public find(id: string | number, opts?: Partial<TOptsSelect>): Promise<TModele | null>;
    public find(opts: Partial<TOptsSelect>): Promise<TModele | null>;
    public find(...args: [string | number, Partial<TOptsSelect>?] | [Partial<TOptsSelect>]): Promise<TModele | null> {

        // Extraction params
        let id: string | number | undefined;
        let opts: Partial<TOptsSelect> | undefined;
        if (typeof args[0] === 'object')
            ([opts] = args)
        else
            ([id, opts] = args)

        // Options find
        if (opts !== undefined)
            this.set(opts)

        // Where id
        if (id !== undefined) {
            const nomPk = this.modele === undefined ? 'id' : this.modele.tables.default.pk[0];
            this.ast.where.push({ [nomPk]: id });
        }

        return this.first();
    }


    public async findOrFail(...args: Parameters<this["find"]>) {

        const instance = await this.find(...args);

        if (instance === null)
            throw new Introuvable("The " + (this.modele ? this.modele.nom : 'item') + " you requested was not found.")

        return instance;
    }

    public async count(opts: Partial<TOptsSelect> = {}): Promise<number> {

        this.ast.select = ['COALESCE( COUNT(*), 0) as nb']

        this.set(opts);

        const retour = await this.execute();

        return retour[0].nb;
    }

    public async all(opts?: Partial<TOptsSelect>): Promise<TModele[]> {

        if (opts !== undefined)
            this.set(opts);

        let resultats = await this.execute();

        resultats = this.structurerDonnees(resultats);

        if (this.modele === undefined || this.rawDataMap[''] === true)
            return resultats;
        else
            return resultats.map(r => this.modele.class.build(r, {
                viaDb: true,
                raw: this.rawDataMap
            }))

    }

    /*----------------------------------
    - CONSTRUCTION (HAUT NIVEAU)
    ----------------------------------*/
    // RAPPEL: Faire le moins de calcul possible ici
    public set(opts: Partial<TOptsSelect>) {

        super.set(opts);

        /*----------------------------------
        - OPTIONS
        ----------------------------------*/
        if (opts.operation !== undefined) {

            const [type, colonne] = opts.operation;

            const table_virt = 'table_' + this.prefixe.join('.');

            this.operation = {
                type: type,
                // Mysql râle si on ne donne pas d'alias à la table virtuelle
                table_virt: table_virt,
                // Alias permettant de faire remonter la donnée de la sous-requete vers la requete où se trouve l'opération
                colonne_virt: colonne === true 
                    ? '*' 
                    : 'op' + (this.dataId++)
            }

            if (this.operation.colonne_virt !== '*')
                this.ast.select.push(colonne + ' as `' + this.operation.colonne_virt + '`');

            // Opération (count, sum, ...) = inutile de récupérer toutes les données vu qu'une seule ligne sera retournée
            this.strict.push('select');
        }

        if (opts.required === false)
            this.required = false;

        if (opts.raw !== undefined)
            this.rawDataMap[''] = true;

        /*----------------------------------
        - EXPRESSIONS
        ----------------------------------*/
        if (opts.select !== undefined)
            this.ast.select.push(opts.select);

        if (opts.order !== undefined)
            this.ast.order.push(opts.order);

        if (opts.limit !== undefined)
            this.ast.limit = opts.limit;

        if (opts.group !== undefined)
            this.ast.group.push(opts.group);

        if (opts.having !== undefined)
            this.ast.having.push(opts.having);

        if (opts.join !== undefined)
            this.addJoin(opts.join);

        return this;

    }

    public addJoin(jointures: TJoin) {

        if (Array.isArray(jointures)) {
            for (const jointure of jointures) {

                let normalisee: TOptsJoin;

                // Nom Alias
                if (typeof jointure === 'string')
                    normalisee = { name: jointure };
                // TOptsJoin
                else
                    normalisee = jointure;

                this.fusionJoin(normalisee.name, normalisee)

            }

        } else {
            for (const id in jointures) {

                const jointure = jointures[id]
                let normalisee: TOptsJoin;

                // Nom alias
                if (jointure === true)
                    normalisee = { name: id };
                // SQL
                else if (jointure instanceof SqlLiteral)
                    normalisee = { name: id, sql: jointure.sql };
                // Query
                else if (jointure instanceof SelectQuery)
                    normalisee = { name: id, query: jointure };
                // TOptsJoin
                else
                    normalisee = {
                        // Le name spécifié dans l'objet a la priorité sur la clé
                        name: jointure.name || id,
                        // Par défaut, quand objet passé, la clé fait référence à l'alias
                        // Permet de joindre plusieurs fois la même table, mais avec des options différentes (count, sum, ...)
                        as: id,
                        ...jointure
                    };

                this.fusionJoin(id, normalisee)
            }
        }
    }

    private fusionJoin(id: string, jointure: TOptsJoin) {

        const existante = this.ast.join[id];
        if (existante === undefined)
            this.ast.join[id] = jointure;
        else {

            this.ast.join[id] = {
                ...existante,
                ...jointure,

                where: this.fusionnerConditions(existante.where, jointure.where)
            };

            //console.log('FUSION JOIN EXISTANT', existante, jointure, this.ast.join[id]);

        }

    }

    public and = this.set;
    
    /*----------------------------------
    - CONSTRUCTION (BAS NIVEAU)
    ----------------------------------*/
    public getSQL(finaliser: boolean) {

        // https://dev.mysql.com/doc/refman/8.0/en/select.html

        this.buildSQL(finaliser);

        // Construction
        let retour = 'SELECT ' + this.sql.select.join(', ') + ' FROM ' + this.sql.from[0];

        for (const alias in this.sql.join)
            retour += ' ' + this.sql.join[ alias ];

        if (this.sql.where.length !== 0)
            retour += ' WHERE ' + this.sql.where.join(' AND ');

        if (this.sql.group.length !== 0)
            retour += ' GROUP BY ' + this.sql.group.join(', ');

        if (this.sql.having.length !== 0)
            retour += ' HAVING ' + this.sql.having.join(' AND ');

        if (this.sql.order.length !== 0)
            retour += ' ORDER BY ' + this.sql.order.join(', ');

        if (this.ast.limit !== false)
            retour += ' LIMIT ' + this.ast.limit;

        if (this.operation !== undefined) {

            /*requete.sql.select = ['COUNT(*)'];
            this.ast.select.push('(' + sqlCount + ') as $' + as);*/

            // Contrairement au format commenté ci-dessus, celui ci-dessous permet de conserver les champs calculés (ex: sous-requetes), 
            // qui peuvent parvois être requis dans les critères (having, group by, ...)
            const colonne_virt = this.operation.colonne_virt === '*'
                ? '*'
                : '$' + this.operation.table_virt + '.' + this.operation.colonne_virt
            return 'SELECT COALESCE( ' + this.operation.type + '(' + colonne_virt + '), 0) FROM (' + retour + ') as `' + this.operation.table_virt + '`';

        }

        return retour;
    }

    public buildSelect() {

        if (this.built.select === true) {
            console.warn(`buildSelect a été appellé, mais le sql a déjà été généré pour select.`);
            return;
        }

        // Par défaut, on sélectionne tous les champs
        if (this.modele !== undefined && !this.strict.includes('select'))
            this.ast.select.unshift( this.champsModele(this.modele) );

        for (let champs of this.ast.select) {

            // Force le format tableau
            if (typeof champs === 'string')
                champs = [champs];
            // { alias: selecteur }
            else if (!Array.isArray(champs)) {

                // Code mysql
                let tbl: string[] = []
                for (const alias in champs) {

                    tbl.push('(' + champs[alias] + ') as $' + alias);

                    // L'alias ne sera pas traité comme un champ d'une table lors du prefixage
                    this._localFields.push(alias);

                }

                champs = tbl;

            }

            for (let champ of champs) {

                // Tous les champs du modèle parent
                if (champ === '$*') {

                    if (this.modele !== undefined)
                        champ = this.champsModele(this.modele);

                // Tous les champs d'un modèle issu d'une jointure
                } else if (champ.endsWith('.*')) {

                    throw new Error('TODO: SELECTEURS WILDCARD');

                    /*const nomAsso = champ.substring(0, champ.length - 2);
                    const asso = this.jointures.find((j) => j.alias === nomAsso);

                    if (asso === undefined)
                        throw new Error(`Tous les champs de l'association ${nomAsso} ont été sélectionnés, mais aucune association ne porte ce nom (Jointures référencées: ${this.jointures.map(j => j.alias).join(', ')})`);

                    return this.champsModele(asso.modele, nomAsso);*/

                }

                this.sql.select.push(
                    this.prefixer(champ)
                );

            }
        }

        this.built.select = true;
    }

    public buildJoin() {

        if (this.built.join === true) {
            console.warn(`buildJoin a été appellé, mais le sql a déjà été généré pour join.`);
            return;
        }

        for (const id in this.ast.join) {
            let jointure = this.ast.join[id];

            if ('sql' in jointure) {

                const sql = this.prefixer(jointure.sql)

                this.sql.join[ jointure.name ] = sql;

                if (jointure.name !== undefined) {
                    const alias = [...this.prefixe, jointure.name].join('.')
                    this.subqueries[alias] = sql;
                }

            } else {

                if (this.modele === undefined)
                    throw new Error(`Seules les jointures sql sont supportées car aucun modèle n'a été joint à la requete.`);

                const attribut = this.modele.attributs[jointure.name] as TMetasAttribut;
                if (attribut === undefined)
                    throw new Error(`L'attribut ${this.modele.nom}.${jointure.name} n'existe pas.`);

                // Fragment de requete select à fusionner avec la requete actuelle
                if (attribut.association?.mode === 'query') {

                    this.set(attribut.association.query);

                // Association à un autre modèle
                } else if (attribut.association?.mode === 'relation') {

                    // Extraction des options de la jointure, le reste sera transmis à la requete
                    let { name: alias, as, pk, fk, query, ...optsRequete } = {
                        ...attribut.association,
                        ...jointure,
                        strict: this.strict
                    }

                    // Si as défini, remplacement de l'alias APRÈS que les infos de l'association aient été récupérés
                    if (as !== undefined)
                        alias = as;

                    let colLocale: TMetasColonne, colJointure: TMetasColonne;
                    if (attribut.association.reverse === false) {
                        colJointure = pk
                        colLocale = fk
                    } else {
                        colJointure = fk
                        colLocale = pk
                    }

                    const relation = '$' + alias + '.' + colJointure.nom + ' = $' + colLocale.nom
                    if (colJointure.table.modele === undefined)
                        throw new Error(`Impossible d'établir la jointure sur ${relation} car aucun modèle n(est rattaché à la table asociée (${colJointure.table.nom}). Utiliser JSQL pour utiliser les jointures sur des tables pures`);

                    // Toutes les jointures héritent du required = false si ce dernier est défini = false
                    // En effet, si la jointure mère peut ne pas retourner de données, alors il est illogique de forcer la jointure enfant à en retourner
                    if (this.required === false)
                        optsRequete.required = false;

                    // Init requete jointure
                    const requete: SelectQuery = query || new SelectQuery(colJointure.table.modele.class);
                    requete.set(optsRequete);

                    // Opération (count, sum) = aggrégation = on ne prend que les colonnes utiles
                    // TODO: réactiver
                    /*if (requete.operation !== undefined && requeteJointure.select !== undefined)
                        requete.set({ strict: ['select'] });*/

                    // Construction
                    requete.ajouterPrefixe([alias]);
                    requete.buildSQL(); // Nécessaire pour compléter requete.data

                    // Héritage des données
                    this.ast.data = { ...this.ast.data, ...requete.get('data') }

                    // Construcion requete SQL
                    if (requete.operation !== undefined) {

                        if (attribut.association.type !== 'hasmany')
                            throw new Error(`Les requtees count ne sont applicables qu'aux associations hasmany`);

                        this.sql.select.push(
                            this.prefixer(
                                '(' + requete.getSQL(false) + ') as $' + alias
                            )
                        );

                        // L'alias ne sera pas traité comme un champ d'une table lors du prefixage
                        this._localFields.push(alias);

                    } else {

                        const operationJointure = requete.required !== true || attribut.association.type === 'hasmany'
                            ? 'LEFT OUTER'
                            : 'INNER';

                        // Héritage WHERE
                        let contraintesJointure = [relation, ...requete.get('where'), ...requete.get('having')]
                        /*if (operationJointure === 'INNER')
                            contraintesJointure = [...contraintesJointure, ...requete.get('where'), ...requete.get('having')]
                            //this.ast.where = [...this.ast.where, ...requete.get('where'), ...requete.get('having')]
                        else
                            contraintesJointure = [...contraintesJointure, ...requete.get('where'), ...requete.get('having')]*/

                        // Construction SQL jointure
                        const sql = operationJointure + ' JOIN ' + requete.table.chemin + ' as $' + alias + ' ON ' + contraintesJointure.join(' AND ');
                        this.sql.join[alias] = this.prefixer(sql);

                        // Héritage SELECT
                        this.ast.select = [...this.ast.select, ...requete.get('select')]
                        this.rawDataMap[alias] = requete.rawDataMap;

                        // Héritage ORDER
                        this.ast.order = [...this.ast.order, ...requete.get('order')]

                        // Héritage JOIN
                        const sousJointures = requete.get('join');
                        for (const aliasSousJointure in sousJointures)
                            this.sql.join[aliasSousJointure] = this.prefixer(sousJointures[aliasSousJointure]);
                    }

                    // Peu importe le type de la requete, on a besoin de connaitre le chemin de tous les champs locaux pour le prefixage
                    this._localFields = [...this._localFields, ...requete.localFields]

                    this.subqueries[ requete.prefixe.join('.') ] = requete;
                    for (const subquery in requete.subqueries)
                        this.subqueries[alias + '.' + subquery] = requete.subqueries[subquery];

                } else
                    throw new Error(`Jointure impossible: l'attribut ${this.modele.nom}.${jointure.name} est référencé ni comme association, ni comme fragment de requete select.`);
            }
        }

        this.built.join = true;
    }

    public buildOrder() {

        if (this.built.order === true) {
            console.warn(`buildOrder a été appellé, mais le sql a déjà été généré pour order.`);
            return;
        }

        for (let criteres of this.ast.order) {

            if (typeof criteres === 'string')
                criteres = [criteres]

            for (const critere of criteres)
                this.sql.order.push(
                    this.prefixer(critere)
                )

        }

        this.built.order = true;
    }

    public buildGroup() {

        if (this.built.group === true) {
            console.warn(`buildGroup a été appellé, mais le sql a déjà été généré pour group.`);
            return;
        }

        for (let cols of this.ast.group) {

            if (typeof cols === 'string')
                cols = [cols]

            for (const col of cols)
                this.sql.group.push(
                    this.prefixer(col)
                )

        }

        this.built.group = true;
    }

    public buildHaving() {

        if (this.built.having === true) {
            console.warn(`buildHaving a été appellé, mais le sql a déjà été généré pour having.`);
            return;
        }

        for (let criteres of this.ast.having) {

            const chaineConditions = this.genConditions(criteres);
            if (chaineConditions === null)
                continue;

            this.sql.having.push(
                this.prefixer(chaineConditions)
            );

        }

        this.built.having = true;
    }

    public async execute(): Promise<any[]> {

        const sql = this.getSQL(true);

        // Execution
        let resultats = await Database.select(sql, this.sql.data, {
            orig: this
        }) as Partial<TModele>[];

        return resultats;

    }

    /*----------------------------------
    - TRANSFORMATION DONNEES
    ----------------------------------*/
    // - Structure l'objet de retour à partir des chemins dfinie via les clés
    //      - INSPIRATION: https://github.com/mickhansen/dottie.js/blob/master/dottie.js#L115
    // Ex: { 'utilisateur.items.id': 10 } => { utilisateur: { items: [{ id: 10 }] } }
    // - Regroupe les résultats selon l'id du modèle d'origine
    // - Regroupe les associations hasmany à leur modèle parent respectuf, sous forme de tableau
    private structurerDonnees(resultatsBruts: TObjDonnees[]): object[] {

        // On n'indexe pas les résultats par leur pk, car cette méthode fait perdre l'ordre des résultats

        const pkVersIndex: { [id: string]: number } = {}
        let resultats: TObjDonnees[] = [];
        let iResultatA: number = 0;

        // Structurztion via chemins (équivalent à dottie)
        const nbResultats = resultatsBruts.length
        for (let i = 0; i < nbResultats; i++) {
            const donneesBrutes = resultatsBruts[i];

            // Traitement de chaque valeur
            let donnees: TObjDonnees = {};
            for (const chemin in donneesBrutes) {

                const valeur = donneesBrutes[chemin];
                // Exclusion si absence de valeur (= undefined)
                if (valeur === null) continue;

                // Chemin composé d'une seule branche = pas besoin d'itération
                if (chemin.indexOf('.') === -1) {
                    donnees[chemin] = valeur;
                    continue;
                }

                // Décomposition chemin
                const branches = chemin.split('.');
                const derniereBranche = branches.pop();
                if (derniereBranche === undefined)
                    throw new Error('La clé est vide.');

                // Création structure & ciblage sur l'objet contenant la valeur à assigner
                let donnee: TObjDonnees = donnees;
                for (const branche of branches) {

                    if (donnee[branche] === undefined)
                        donnee[branche] = {}

                    donnee = donnee[branche];

                }

                // Assignement valeur
                donnee[derniereBranche] = valeur;

            }

            if (this.modele === undefined)
                resultats.push(donnees);
            else {

                // Référencement avec regroupement par modèle
                // TODO: Regroupement selon group by
                const valPk = this.modele.tables.default.pk.map((cle) => {

                    if (donneesBrutes[cle] === undefined)
                        throw new Error(`La valeur de la clé primaire ${cle} est manquante dans les résultats de mysql.`);

                    return donneesBrutes[cle];

                }).join('-');

                if (!(valPk in pkVersIndex)) {

                    // Associations has many = plusieurs résultats = tableau
                    for (const alias of this.modele.associations.hasmany)
                        donnees[alias] = donnees[alias] === undefined
                            ? []
                            : [donnees[alias]];

                    // Indexage du résultat
                    resultats[iResultatA] = donnees;
                    pkVersIndex[valPk] = iResultatA;
                    iResultatA++;

                // Résultats multiples = Fusion tableau
                } else {

                    const indexResultat = pkVersIndex[valPk];

                    // Associations has many = plusieurs résultats = ajout au tableau existant
                    for (const alias of this.modele.associations.hasmany)
                        if (donnees[alias] !== undefined)
                            resultats[indexResultat][alias].push(donnees[alias]);

                }
            }
        }

        return resultats;

    }

    public async raw() {
        return await this.execute();
    }

    public async valeur(...valeurs: string[]) {
        const donnees = await this.execute();
        let retour = {};
        for (const valeur of valeurs)
            retour[valeur] = donnees[0][valeur];
        return retour;
    }

    private async first(opts?: Partial<TOptsSelect>): Promise<TModele | null> {

        const resultats = await this.all(opts);
        return resultats.length === 0 ? null : resultats[0];
    }

}