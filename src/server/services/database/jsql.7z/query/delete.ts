/*----------------------------------
- DEPENDANCES
----------------------------------*/

// Libs
import Database, { TOptsQuery } from '..';
import Query, { TParamModele, TCritere } from '.';

/*----------------------------------
- TYPES
----------------------------------*/

export type TOptsDelete = TOptsQuery & {
    where: TCritere
}

/*----------------------------------
- SERVICE
----------------------------------*/
export default class DeleteQuery<TModele extends TParamModele = unknown> extends Query<DeleteQuery<TModele>, TModele> {

    public async delete(opts: TOptsDelete) {

        if (opts !== undefined)
            this.set(opts);

        return await this.execute();

    }

    public getSQL() {

        this.buildSQL(true);

        if (this.sql.where.length === 0)
            throw new Error("Au moins une condition where doit être spécifiée pour appeller delete.");

        return `DELETE FROM ` + this.table.chemin + ' as `' + this.table.alias + '` WHERE ' + this.sql.where.join(' AND ');
    }

    public async execute() {

        const sql = this.getSQL();

        await Database.delete(sql, this.sql.data, {
            simuler: this.simuler
        });
    } 

}