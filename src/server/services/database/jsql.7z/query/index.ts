/*----------------------------------
- DEPENDANCES
----------------------------------*/

// Libs
import ModelsManager from '../../models/manager';
import { TOptsQuery as TOptsQueryParser } from '..';
import SelectQuery from './select';

// Types
import Modele from '../../models';
import { TMetasModele, TAssociation, TMetasTable } from '../../models/metas';

/*----------------------------------
- CONSTANTES
----------------------------------*/
const OpLogiques = {
    and: Symbol.for('and'),
    or: Symbol.for('or'),   
}

const OpComparaison = {
    eq: Symbol.for('eq'),
    ne: Symbol.for('ne'),
    gt: Symbol.for('gt'),
    gte: Symbol.for('gte'),
    lte: Symbol.for('lte'),
    lt: Symbol.for('lt'),
    in: Symbol.for('in'),
}

export const Op = { ...OpLogiques, ...OpComparaison }

export class SqlLiteral {
    public constructor( public sql: string ) { }
    public toString(): string { return this.sql; }
}
export const Sql = (sql: string) => new SqlLiteral(sql)

// https://regexr.com/5mi62
const regexColonnes = /(?:(as) )?\$((?:([a-z0-9\.\_\-\*]+)\.)*([a-z0-9\.\_\-\*]+))?/gi;
const regexPrefixage = /(\$|\@)([a-z0-9\.\_\-\*]+)?/gi;

/*----------------------------------
- TYPES: DEFINITIONS
----------------------------------*/
type TValeurSql = string | number | boolean | null;

type TCritereChamp = TValeurSql | string[] | SqlLiteral | { [op in symbol]: TCritereChamp }
type TObjCriteres = {[champ: string]: TCritereChamp} & {[operateur in symbol]: TCritereChamp[]}
export type TCritere = string | TObjCriteres

export type TParamModele = (typeof Modele | unknown);

export type TObjDonnees = { [cle: string]: any }

export type TWhere = TCritere

type TNomExpression = string

export type TOptsQuery = TOptsQueryParser & {
    strict?: string[]
}

/*----------------------------------
- SERVICE
----------------------------------*/
/*
    OBJECTIF: Simplifier la construction de requetes tout en restant basé sur du SQL (l'execution de requetes complexes doit être à portée de main)

    CONTRAINTES;
    - Le code sql de chaque instructions (select, where, ...) doit être executé au moment de leur importation
    - Les instructions sql ne doivent être concaténées qu'au moment d'executer la requete sql, de façon à ce qu'il puisse être modifiable

    Fonctionnement: Importation des ASTs (set) => this.ast => Build SQL => this.sql => Consruction => this.sqlString => Execution

    INSPIRATION:
    - https://laravel.com/docs/8.x/eloquent
    - https://preview.adonisjs.com/guides/database/introduction

    RAPPEL: On n'injecte pas les valeur directement dans les requetes pour 2 raisons:
    - Le regex de remplacement des prefixes ne doit pas effecter les valeurs (conditions, insetions, ...)
    - Dans le futur, on doit pouvoir réutiliser la requête sql, au préalable mise en cache, avec des données différentes
*/
export default abstract class Query {

    protected static builders = {
        where: 'buildWhere',
        from: 'buildFrom',
    }

    /*----------------------------------
    - PROPRIETES
    ----------------------------------*/
    public modele?: TMetasModele;
    public table: TMetasTable;
    public prefixe: string[] = [];

    protected simuler: boolean = false;

    // Expressions qui ne doivent pas être complétées automatiquement (ex: fusion du select avec les jointures)
    // Ex:si select est spécifié, on ne retournera que les données explicitement demandées dans la requete (seulement le strict minimum)
    // Utile lorsqu'on fait, par exemple, un count ou un sum, et que seule la donnée à compter sera retournée par la requete
    protected strict: string[] = []; 

    protected ast: {
        where: TWhere[],
        data: TObjDonnees,
    } = {
        where: [],
        data: {}
    }

    // Liste des asts ayant été transformées en sql
    protected built: { [nom: string]: boolean } = {}

    protected sql: {
        from: string[],
        where: string[],
        data: TObjDonnees,
    } = {
        from: [],
        where: [],
        data: {},
    }

    // Liste des champs n'existant pas dans les tables de la bdd (= dont la valeur est détemrinée via du code mysql)
    protected _localFields: string[] = [];

    // Paraètres calculés via traitement opts
    protected viaIdOnly: boolean = false;
    protected dataId: number = 0;

    // Permet de récupérer les infos d'une requete à partir du chemin de la jointure
    protected subqueries: {[chemin: string]: SelectQuery | string} = {}

    /*----------------------------------
    - INITILISATION
    ----------------------------------*/
    // FIX: On ne set pas les options depuis le constructeur, car set a besoin que toutes les props soient bien initialisées (ex: instanciationMap)
    // Hors, si SelectQuery.set est appellé à la fin du constructeur abstrait, toutes les props ne seront pas encore initialisées
    public constructor(source: string | typeof Modele | [string, string], prefixe?: string[]) {

        // Via nom du modèle
        if (typeof source === 'string') {

            this.modele = ModelsManager.modeles[source];
            this.table = this.modele.tables.default;

        // Classe Modèle
        } else if (!Array.isArray(source)) {

            this.modele = source.metas;
            this.table = this.modele.tables.default

        // database + table
        } else {

            const [database, table] = source;

            this.table = {
                nom: table,
                chemin: '`' + database + '`.`' + table + '`',
                alias: table.toLowerCase(),
                colonnes: []
            }

        }

        if (prefixe !== undefined)
            this.prefixe = prefixe;

        //console = Requetes.master.console.scope('bdd', this.modele.nom);

    }

    /*----------------------------------
    - CONSTRUCTION (HAUT NIVEAU)
    ----------------------------------*/
    // TODO: Détecter doublons et écraser si déjà existant
    // Pour cela, indexer this.ast.select et this.ast.join avec les alias 
    public set( opts: Partial<TOptsQuery & { where: TCritere }> ) {

        if (opts.strict !== undefined)
            this.strict = [...this.strict, ...opts.strict];

        if (opts.simuler !== undefined)
            this.simuler = opts.simuler;

        if (opts.data !== undefined)
            this.ast.data = { ...this.ast.data, ...opts.data }

        if (opts.where !== undefined)
            this.ast.where.push(opts.where);

        return this;

    }

    public get(nomExpression: TNomExpression): string[] | {[nom: string]: string} {

        if (this.built[nomExpression] !== true) {
            const nomBuilder = this.constructor.builders[nomExpression];
            throw new Error(`Impossible de récupérer les expressions sql ${nomExpression} car le builder associé (${nomBuilder}) n'a pas encore été appellé.`);
        }

        return this.sql[nomExpression];

    }

    /*----------------------------------
    - PREFIXAGE
    ----------------------------------*/
    public get localFields() {

        if (this.prefixe.length === 0)
            return this._localFields;

        const prefixeStr = this.prefixe.join('.');
        return this._localFields.map((field) => prefixeStr + '.' + field);
    }

    public ajouterPrefixe(prefixe: string[]) {
        this.prefixe = [...prefixe, ...this.prefixe]
    }

    protected prefixer(sql: string, prefixe?: string) {

        if (prefixe === undefined)
            prefixe = this.prefixe.join('.');

        if (this.prefixe.length === 0)
            return sql;

        return sql.replace(regexPrefixage, (match, symbole, chemin) => {

            return symbole + prefixe + (chemin === undefined ? '' : '.' + chemin)
        })
    }

    /*----------------------------------
    - CONSTRUCTION (BAS NIVEAU)
    ----------------------------------*/
    public buildSQL(finaliser?: boolean) {

        for (const nomExpr in this.constructor.builders)
            this[ this.constructor.builders[nomExpr] ]();

        this.buildData();

        if (finaliser !== true)
            return;

        // Finalisation (supprime les $ des prefixes)
        for (const nomInstruction in this.constructor.builders) {
            this.sql[nomInstruction] = Object.values(this.sql[nomInstruction]).map(i => i.replace(
                regexColonnes, (match, keyword, cheminComplet, prefixe, branche) => {

                    // Alias table:                     as $type.id => as `ptctache.type.id`
                    // Alias colonne:                   as $campagne => as `ptctache.campagne`
                    if (keyword === 'as') {

                        // Pas de chemin = root
                        if (cheminComplet === undefined)
                            cheminComplet = this.table.alias;

                        return 'as `' + cheminComplet + '`';

                    // Référence champ local:           $missiontache.disponibilite => @missiontache.disponibilite
                    } else if (this.localFields.includes(cheminComplet))

                        // Les variables ne sont pas accessibles depuis where et having
                        if (nomInstruction === 'having')
                            return '`' + cheminComplet + '`';
                        else if (nomInstruction !== 'where')
                            //return '@' + cheminComplet;
                            return '(SELECT `' + cheminComplet + '`)'
                        else
                            throw new Error(`Impossible de traiter la référence vers « ${cheminComplet} » dans la clause ${nomInstruction}: les champs locaux ne sont pas accessibles depuis cette dernière (ni les alias, ni les variables)`);

                    // Référence colonne association:   $campagne.type.id => `campagne.type`.id
                    else if (prefixe !== undefined) {

                        return '`' + prefixe + '`.' + branche;

                    // Référence colonne table mère:    $titre => `default`.titre
                    } else {

                        return '`' + this.table.alias + '`.' + branche;;

                    }
                }
            ))
        }

        //console.log('Build SQL', this.ast, this.sql);
    }

    public buildWhere() {

        if (this.built.where === true) {
            console.warn(`buildWhere a été appellé, mais le sql a déjà été généré pour where.`);
            return;
        }

        for (let criteres of this.ast.where) {

            const chaineConditions = this.genConditions(criteres);
            if (chaineConditions === null)
                continue;

            this.sql.where.push( 
                this.prefixer(chaineConditions) 
            );

            // Une autre condiion s'ajoute à celle de l'id, la requete n'est plus viaIdOnly
            if (this.viaIdOnly === true)
                this.viaIdOnly = false;
            else if (typeof criteres === 'object' && criteres.id !== undefined)
                this.viaIdOnly = true;

        }

        this.built.where = true;
    }

    public buildFrom() {
        this.sql.from = [this.prefixer(this.table.chemin + ' as $')]
    }

    public buildData() {

        if (this.built.data === true) {
            console.warn(`buildData a été appellé, mais le sql a déjà été généré pour data.`);
            return;
        }

        /*const prefixe = this.prefixe.join('_') + '_';

        for (const nom in this.ast.data)
            this.sql.data[ prefixe + nom ] = this.ast.data[nom]*/

        this.sql.data = { ...this.ast.data }

        this.built.data = true;

    }

    protected addData(nom: string, data: TValeurSql): string {
        this.dataId++;
        const prefixe = this.prefixe.length === 0 ? '' : this.prefixe.join('_') + '_';
        const id = prefixe + nom + this.dataId;
        this.ast.data[id] = data;
        return ':' + id;
    }

    /*----------------------------------
    - CONSTRUCTION CONDITIONS (BAS NIVEAU)
    ----------------------------------*/
    protected genCondition(cle: string, op: Symbol, valeur: TValeurSql | SqlLiteral): string {

        let comparaison: string;

        if (valeur === null) {
            switch (op) {
                case Op.eq: comparaison = 'IS NULL'; break;
                case Op.ne: comparaison = 'IS NOT NULL'; break;

                default: throw new Error(`Valeur NULL non-supportée par l'opérateur ` + op.toString());
            }
        } else {

            let sqlValeur: string;
            if (valeur instanceof SqlLiteral)
                sqlValeur = valeur.sql;
            else
                sqlValeur = this.addData(cle, valeur);

            switch (op) {
                case Op.eq: comparaison = '= ' + sqlValeur; break;
                case Op.ne: comparaison = '!= ' + sqlValeur; break;

                case Op.gt: comparaison = '> ' + sqlValeur; break;
                case Op.gte: comparaison = '>= ' + sqlValeur; break;
                case Op.lte: comparaison = '<= ' + sqlValeur; break;
                case Op.lt: comparaison = '< ' + sqlValeur; break;

                case Op.in: comparaison = 'IN (' + sqlValeur + ')'; break;

                default: throw new Error('Opérateur inconnu: ' + op);
            }
        }

        return '$' + cle + ' ' + comparaison;
    }

    protected genConditions(conditions: TCritere, opLogique: string = 'AND'): string | null {

        // SQL brut
        if (typeof conditions === 'string')
            return conditions;
        // Objet d'Egalités
        else if (typeof conditions === 'object') {

            let retour: string[] = [];

            // Opérateurs logiques
            // { Op.or: [{ type: 'banner' }, { type: 'text' }] }
            const operateurs = Object.getOwnPropertySymbols(conditions);
            for (const operateur of operateurs) {

                let opSql: string;
                if (operateur === Op.and)
                    opSql = 'AND';
                else if (operateur === Op.or)
                    opSql = 'OR';
                else
                    throw new Error("Opérateur inconnu");

                const conditionsSql = conditions[operateur].map((condition) => this.genConditions(condition)).join(' ' + opSql + ' ')

                retour.push('(' + conditionsSql + ')');
            }

            // Nom colonnes
            // { nom: 'booster' }
            // { nom: ['booster', 'exp'] }
            // { nom: sql('...') }
            // { nom: { Op.like: 'booster } }
            for (const cle in conditions) {

                let donnee = conditions[cle];

                // Modèle vers pk

                // Détermination opération selon type donnée
                if (Array.isArray( donnee ))
                    donnee = { [Op.in]: donnee };

                if (donnee === undefined)
                    donnee = null;
                
                // Egalité simple (RAPPEL: null est un objet)
                if (donnee === null || typeof donnee !== 'object') {

                    retour.push( this.genCondition(cle, Op.eq, donnee) );

                // Sql literal
                } else if (donnee instanceof SqlLiteral) {

                    retour.push('$' + cle + ' ' + donnee.sql);

                // Opérations spécifiques
                } else if (donnee.constructor === Object) {

                    // Opérateurs de comparaison
                    // Les boucles for ne tiennent pas compte des symboles
                    const operateurs = Object.getOwnPropertySymbols(donnee);
                    for (const op of operateurs) {

                        retour.push( this.genCondition(cle, op, donnee[op]) );
                    }

                // Modèle
                } else if (this.modele?.attributs[cle]?.association?.mode === 'relation') {

                    if (donnee.metas === undefined)
                        throw new Error(`Seul un modèle peut être passé dans une égalité portant sur un attribut d'association.`);

                    const asso = this.modele.attributs[cle].association as TAssociation;

                    if (asso.reverse === true) // La fk est stockée dans le modèle parent
                        throw new Error(`Seuls les modèles associés dont la pk est stockée dans le modèle parent (reverse = false) sont supportés.`);

                    retour.push( this.genCondition(asso.fk, Op.eq, donnee.getPkValue()) );

                } else {

                    console.error(donnee)
 
                    throw new Error(`Impossible de construire une égalité avec la valeur ${cle} (valeur ci-dessus)`);

                }

            }

            const nbConditions = retour.length;
            if (nbConditions === 0)
                return null;
            else if (nbConditions === 1)
                return retour[0];
            else
                return '(' + retour.join(' ' + opLogique + ' ') + ')';

        } else
            throw new Error('Erreur de format');

    }

    protected fusionnerConditions(cond1: TCritere | undefined, cond2: TCritere | undefined): TCritere | undefined {

        const typeCond1 = typeof cond1;
        const typeCond2 = typeof cond2;

        if (cond1 === undefined && cond2 === undefined) {

            return undefined;

        } else if ((cond1 === undefined) !== (cond2 === undefined)) {

            // L'une des deux est définie
            return cond1 || cond2 || undefined

        } else if (typeCond1 !== typeCond2) {
            
            // Pas possible de fusionner deux types différents
            console.log('cond1 =', cond1, '|| cond2 =', cond2);
            throw new Error("Impossible de fusionner deux conditions de type différent (voir les conditiosn concernées ci-dessus)")

        // Fusion
        } else if (typeCond1 === 'object') {

            return { ...cond1 as object, ...cond2 as object };

        } else if (typeCond1 === 'string') {

            return cond1 + ' AND ' + cond2

        } else {

            console.log('cond1 =', cond1, '|| cond2 =', cond2);
            throw new Error("Aucun code prévu pour la fusion des deux conditions données (voir les conditiosn concernées ci-dessus)")

        }
    }

    /*----------------------------------
    - EXECUTION
    ----------------------------------*/
    public abstract getSQL(...props: any[]): string;
    public abstract execute(...props: any[]): Promise<any>;
}