/*----------------------------------
- DEPENDANCES
----------------------------------*/

// Npm
import safeStringify from 'fast-safe-stringify'; // remplace les références circulairs par un [Circular]

// Queries
import { TWhere, TObjDonnees, TOptsQuery } from '../database/query';
import SelectQuery, { TRawDataMap } from '../database/query/select';
import InsertQuery, { TOptsInsert } from '../database/query/insert';
import UpdateQuery, { TOptsUpdate } from '../database/query/update';
import DeleteQuery, { TOptsDelete } from '../database/query/delete';

// Decorators
export { Table, Scopes } from './table';
export { Column, API, Virtual } from './attributes';
export { HasMany, HasOne } from './associations';

// Const
import * as datatypes from '../database/datatypes';
import { sepPks } from '../database';

/*----------------------------------
- TYPES
----------------------------------*/

import type { TModelMetas } from './table';
import type { TMetasAttribut } from './attributes';

import type { TAssociationRelation } from '../database/metas';
import QueryRunner, { TImportedQuery } from '../database/jsql/query/runner';
import type { TQueryAbstraite } from '../database/jsql/parser/abstraction';

/*----------------------------------
- TYPES OPTIONS
----------------------------------*/

type TOptsActionModele = {  }

type TOptsModele = {
    readOnly?: boolean,
}

export type TOptsSet = TOptsActionModele & TOptsModele & {
    viaDb?: boolean,
    raw?: TRawDataMap
}

export type TOptsAfterUpdate<TModele> = {
    changed: Partial<TModele>
}

type ClassOf<T> = typeof Modele & { new(): T; };

/*----------------------------------
- SERVICE
----------------------------------*/
export default abstract class Modele {

    /*
        ATTENTION: Pour prévenir des risques de confusion de références,
            ne pas initialiser les propriétés statiques depuis les classes abstraites
    */

    // Assigned from decorators
    public static metas: TModelMetas;
    public static _attributes: {[name: string]: TMetasAttribut};

    // Shortcuts
    public _model = this.constructor as typeof Modele;
    public _metas = this._model.metas;
    public _name = this._metas.name;

    // Instance state
    protected _data = {} as { [cle in keyof this]: any};
    private _savedData = {} as { [cle in keyof this]: any};
    private _readOnly: boolean = false;
    private _enregistre: boolean = false;

    public constructor() {
        
    }

    private log = (...args: any[]) => 
        console.log(`[modele][${this._name}][${this.getPkValue() || 'new'}]`, ...args);

    public config(opts: TOptsModele) {

        if (opts.readOnly === true)
            this._readOnly = true;

        return this;
    }

    /*----------------------------------
    - GETTERS DONNEES
    ----------------------------------*/

    // Transforme le modèle en objet json
    public get(opts: TOptsActionModele & { pourDb?: boolean, liste?: string[] } = {}) {

        this.log(`Conversion en json`, opts);

        const cles = opts.liste || Object.keys(this._data)
        const attrs = this._model._attributes;

        let donnees: Partial<this> = {}
        for (const nom of cles) {

            let valeur = this._data[nom];

            // Existance attribut
            const attribut = attrs[nom];
            if (attribut === undefined)
                continue;

            // Conversion / adaptation de la valeur si elle a été définie
            if (valeur !== undefined) {

                // Serialiseation type js
                /*if (attribut.js !== undefined) {

                    const type = attribut.js.type;
                    const serialiser = datatypes.js[type]?.serialize;

                    if (serialiser !== undefined)
                        valeur = serialiser(valeur, attribut);

                }*/

                // Modèle => json
                if (typeof valeur === 'object' && valeur !== null && valeur._model !== undefined)
                    valeur = valeur.get(opts);
        
                // Données destinées à alimenter une requete bdd
                if (opts.pourDb === true) {

                    // On n'inclu pas les attributs ne faisant pas référence à une colonne de la bdd
                    if (attribut.colonne === undefined)
                        continue;

                    const type = attribut.colonne.type;
                    const serialiser = datatypes.mysql[type]?.serialize;
                    if (serialiser !== undefined)
                        valeur = serialiser(valeur, attribut);

                    if (typeof valeur === 'object' && valeur !== null)
                        //valeur = JSON.stringify(valeur);
                        valeur = safeStringify(valeur);

                }
            }

            donnees[nom] = valeur;
        }

        return donnees;
    }

    protected getData(cle: keyof this) {
        return this._data[ cle as string ];
    }

    public getPkValue(): string {
        return this._metas.tables.default.pk.map(pk => this._data[ pk ]).join(sepPks)
    }

    private getPkValues(dernieres: boolean = false) {

        // Si déjà enregistré, on retourne la valeur des pks depuis la bdd (= _savedData)
        // Et non la dernière valeur connue
        // Permet de pouvoir update les pks en basant le where sur les valeurs de la bdd, et non les nouvelles valeurs
        const sourceVals = (this._enregistre && dernieres === false) ? this._savedData : this._data;

        const valsPks: Partial<this> = {}
        for (const pk of this._metas.tables.default.pk)
            if (sourceVals[pk] === undefined)
                throw new Error(`Aucune valeur pour la PK « ${this._name}.${pk} »`);
            else
                valsPks[pk] = sourceVals[pk];

        return valsPks;
    }

    public getChangedData(): Partial<this> | null {

        let changedData: Partial<this> = {};
        let changed: boolean = false;

        // Données issues de la bdd
        for (const col of this._metas.columns)
            if (this._data[col] !== this._savedData[col]) {
                changedData[col] = this._data[col];
                changed = true;
            }

        // Associations
        for (const col of this._metas.associations.all)
            if (this._data[col] instanceof Modele) {

                const changedData = this._data[col].getChangedData();

                if (changedData !== null) {
                    changedData[col] = changedData;
                    changed = true;
                }

            }

        return changed === true ? changedData : null;
    }

    public hasChanged(attrs?: (keyof this)[]): boolean {

        if (attrs === undefined)
            attrs = Object.keys(this._model._attributes) as (keyof this)[];

        for (const attr of attrs)
            if (
                this._data[attr] !== this._savedData[attr]
                ||
                (this._data[attr] instanceof Modele && this._data[attr].hasChanged())
            )
                return true;

        return false;
    }

    /*----------------------------------
    - SETTERS DONNEES
    ----------------------------------*/
    public static build<T extends Modele>(this: ClassOf<T>, donnees: Partial<T>, opts: TOptsSet = {}): T {
        donnees = this.BeforeBuild(donnees, opts);
        return (new this).config(opts).set({ ...this.metas.defaultData, ...donnees }, opts)
    }

    public set(donnees: Partial<this>, opts: TOptsSet = {}): this {
        
        this.log(`set`, Object.keys(donnees), opts);

        const attrs = this._model._attributes;

        for (const nom in donnees) {

            let valeur = donnees[nom];

            // Attribut non-reconnu
            const attribut = attrs[nom];
            if (attribut === undefined) {
                this.log('set', nom + ' rejetté: non-reconnu comme attribut');
                continue;
            }

            this.log('set', nom, '=', valeur)

            // Conversion / adaptation de la valeur si elle a été définie
            if (valeur !== undefined) {

                // Desialisation depuis BDD (colonnes & donnés issues d'une query)
                // ATTENTION: la donnée peut provenir de la bdd, mais ne pas être associée à une colonne
                // Ex: jointure
                // C'est pourquoi, même avec viaDb = true, on assigne toutes les données fournies en entrée
                if (opts.viaDb === true) {

                    let typeMysql: undefined | string;
                    // Colonne présente dans la table
                    if (attribut.colonne !== undefined)
                        typeMysql = attribut.colonne.type;
                    // Colonne virtuelle via fragment
                    else if (attribut.association?.mode === 'query' && attribut.js !== undefined)
                        // On ne connait que le type JS donc déduction via ce dernier
                        typeMysql = datatypes.js[ attribut.js.type ]?.mysql;

                    // Si on doit traiter la donnée comme provenant de la BDD
                    if (typeMysql !== undefined) {

                        // NULL = pas de valeur
                        if (valeur === null) {
                            this._data[nom] = undefined;
                            this._savedData[nom] = undefined;
                            continue;
                        }

                        // Déserialisation type MySQL
                        const deserialiser = datatypes.mysql[ typeMysql ]?.deserialize;
                        if (deserialiser !== undefined)
                            valeur = deserialiser(valeur, attribut);
                        
                    }

                }

                // Deserialiseation depuis type JS si valeur spécifiée
                if (attribut.js !== undefined) {

                    const type = attribut.js.type;
                    const deserialiser = datatypes.js[type]?.deserialize;
                    if (deserialiser !== undefined)
                        valeur = deserialiser(valeur, attribut);

                }

                // Instanciation / màj modèle association
                const asso = attribut.association;
                if (asso?.mode === 'relation') {

                    valeur = this.instancierAssociation(nom, asso, valeur, opts);

                }

            }

            // Assignation + Mémorisation pour déterminer si update ou non
            this._data[nom] = valeur;
            if (opts?.viaDb === true)
                this._savedData[nom] = valeur;
        }

        // Données provenant de la bdd, on marque le modèle comme enregistré
        if (opts?.viaDb === true)
            this._enregistre = true;

        // Une fois que les données sont sont toutes assignées, 
        // On détermine automatiquement les pks et fks
        this.synchronizeKeys( Object.keys(donnees), opts );

        // Empêche tout autre modification
        if (opts.readOnly === true)
            this._readOnly = true;

        return this;

    }

    // Assigne une seule valeur manuellement
    protected setData(cle: keyof this, value: any) {
        this.set({ [cle]: value })
    }

    private synchronizeKeys(changed: string[] = [], opts: TOptsActionModele = {}) {

        this.log(`[synchronizeKeys] Champs modifiés:`, changed);

        const metas = this._metas;
        const className = this._name;

        // Pour chaque association issue d'une relation, 
        // Détermine automatiquement la valeur des fk via les pks, et inversement
        // Ex: Si publicité.id est connu, alors on en déduit la valeur de publicité.metas.id
        // publicité.metas.id étant une fk pointant vers la pk publicité.id
        for (const nomAttr of metas.associations.hasone) {

            const attribut = this._model._attributes[ nomAttr ] as TMetasAttribut;
            if (attribut.association?.mode !== 'relation') continue;

            // NOTE: Si tout s'est bien passé, this.set s'est assuré que le modèle soit bien instancié
            // Si sa valeur n'est pas indéfinie, on considère donc modeleAssocie comme un modele
            const modeleAssocie: Modele | undefined = this._data[ nomAttr ]

            const nomFk = attribut.association.fk.nom;
            const nomPk = attribut.association.pk.nom;

            const cheminAsso = className + '.' + attribut.nom;
            let contPk, contFk, cheminPk, cheminFk;

            const log = (...args: any[]) => this.log(`[synchronizeKeys][${cheminAsso}]`, ...args);

            // Relation Modele.pk -> Association.fk
            if (attribut.association.reverse === false) {

                log(`Association directe. Modele =`, this._data, 'Association =', modeleAssocie?._data);

                contPk = modeleAssocie;
                cheminPk = cheminAsso + '.' + nomPk;
                contFk = this._data;
                cheminFk = className + '.' + nomFk;

                // Définition de l'objet à undefined = de même pour la fk
                // => Modele.fk = undefined
                if (modeleAssocie === undefined) {

                    if (changed.includes(nomAttr)) {

                        log(`Données de l'association ${cheminAsso} changées: ${cheminFk} = ${cheminPk} = undefined`);
                        this._data[nomFk] = undefined;

                    }

                // Changement de l'objet associé = màj de la fk en conséquence si cette dernière n'est pas la pk
                // => Modele.fk = Modele.association.pk
                } else if (changed.includes(nomAttr) && !metas.tables.default.pk.includes( nomFk )) {

                    log(`Données de l'association ${cheminAsso} changées: ${cheminFk} = ${cheminPk} = "${modeleAssocie._data[nomPk]}"`);
                    this._data[nomFk] = modeleAssocie._data[nomPk];

                // Changement de la fk = référence à un nouvel objet (dont on ne connait pas les données)
                // => Modele.association = undefined
                } else if (changed.includes( nomFk ) && this._data[ nomFk ] !== modeleAssocie._data[ nomPk ]) {

                    log(`FK ${cheminFk} changée: ${cheminAsso} = undefined`);
                    this._data[ nomAttr ] = undefined;

                // Changement de la pk de l'objet associé
                // Si Modele.fk n'est pas une clé primaire,
                // => Modele.fk = Modele.asociation.pk
                } else if (modeleAssocie.hasChanged([nomPk]) && !metas.tables.default.pk.includes(nomFk)) {

                    log(`PK ${cheminPk} changée: ${cheminFk} = ${cheminPk} = "${modeleAssocie._data[nomPk]}"`);
                    this._data[nomFk] = modeleAssocie._data[nomPk];

                // Absence de la fk
                // => Modele.fk = Modele.asociation.pk
                } else if ((nomPk in modeleAssocie._data) && !(nomFk in this._data)) {

                    log(`FK ${cheminFk} absente: ${cheminFk} = ${cheminPk} = "${modeleAssocie._data[nomPk]}"`);
                    this._data[nomFk] = modeleAssocie._data[nomPk];

                // Absence de la pk
                // => Modele.asociation.pk = Modele.fk
                } else if ((nomFk in this._data) && !(nomPk in modeleAssocie._data)) {

                    log(`PK ${cheminPk} absente: ${cheminPk} = ${cheminFk} = "${this._data[nomFk]}"`);
                    modeleAssocie._data[nomPk] = this._data[nomFk];

                } else
                    log(`Aucun changement`);

                continue;

                if (!( typeof modeleAssocie === 'object' && modeleAssocie === null ))
                    continue;

                const valFk = this._data[nomFk];
                const valPk = modeleAssocie._data[nomPk];

                // Modele.fk = Association.pk
                if (
                    // Peu importe la valeur de sa pk, les valeurs d'un modèle instancié prennent toujours le dessus
                    /* Ex: 
                        mission.set({
                            approbation: Approbation.build({
                                dateDemande: new Date,
                                utilisateur: user
                            })
                        })
                    Dans ce cas, mission.approbation_id = undefined */

                    (modeleAssocie instanceof Modele && modeleAssocie.hasChanged([nomPk]))
                    ||
                    // FK non-définie, ou PK mise à jour
                    (valPk !== undefined && (valFk === undefined || changed.includes(nomPk)))
                ) {

                    this._data[nomFk] = valPk;
                    log(`${cheminFk} = ${cheminPk} = "${valPk}"`);
                
                // Association.pk = Modele.fk quand:
                // - PK non-définie
                // - FK mise à jour
                } else if (valFk !== undefined && (valPk === undefined || changed.includes(nomFk))) {

                    // L'objet associé n'est pas spécifique a l'objet actuel, et peut être rattaché à d'autres modèles
                    // Au lieu de mettre à jour sa pk, on le rend undefined vu que la fk pointe vers un autre objet
                    //modeleAssocie._data[nomPk] = valFk;
                    //log(`${cheminPk} = ${cheminFk} = "${valPk}"`);

                    this._data[ nomAttr ] = undefined
                    log(`${cheminAsso} = ${cheminFk} = undefined`);
                
                }

            // Relation Association.fk -> Modele.pk
            } else {

                contPk = this._data;
                cheminPk = className + '.' + nomPk;
                contFk = modeleAssocie;
                cheminFk = cheminAsso + '.' + nomFk;

                if (!( typeof modeleAssocie === 'object' && modeleAssocie === null ))
                    continue;

                const valFk = modeleAssocie._data[nomFk];
                const valPk = this._data[nomPk];

                log(`Association reverse`);

                // TODO: Implémenter le code de reverse = false

                // Association.fk = Modele.pk quand:
                // - fk non-définie
                // - pk mise à jour
                if (valPk !== undefined && (valFk === undefined || changed.includes(nomPk))) {

                    modeleAssocie._data[nomFk] = valPk;
                    log(`[reverse] ${cheminAsso}.${nomFk} = ${className}.${nomPk} = "${valPk}"`);
            
                // Association.pk = Modele.fk quand:
                // - pk non-définie
                // - fk mise à jour
                } else if (valFk !== undefined && (valPk === undefined || changed.includes(nomFk))) {

                    modeleAssocie._data[nomPk] = valFk;
                    log(`[reverse] ${className}.${nomPk} = ${cheminAsso}.${nomFk} = "${valFk}"`);
                
                }
            
            }
        }
    }

    protected instancierAssociation(
        nom: string, 
        asso: TAssociationRelation, 
        valeur: any, 
        opts: TOptsSet = {}
    ): any {

        // Association undefined = fk undefined également
        if (valeur === undefined && asso.reverse !== true) {

            this._data[asso.fk.nom] = undefined;
            if (opts?.viaDb === true)
                this._savedData[nom] = undefined;
            
        // Création d'une instance du modèle via objet de données
        } else if (!(typeof valeur === 'object'))
            throw new Error(`Valeur incorrecte pour l'association ` + nom + ': ' + JSON.stringify(valeur));
        else {

            const optsApropager = {
                viaDb: opts.viaDb
            }
            
            // hasone
            if (asso.type === 'hasone' && valeur.constructor === Object) {

                // Déjà instancié: màj des propriétés
                if (this._data[nom] instanceof Modele)
                    valeur = this._data[nom].set(valeur, optsApropager);
                // Nouvelle instance
                else {

                    const tableAssociee = asso.reverse === false
                        ? asso.pk.table
                        : asso.fk.table;

                    if (tableAssociee.modele !== undefined)
                        valeur = tableAssociee.modele.class.build(valeur, optsApropager);
                }

            // hasmany
            } else if (asso.type === 'hasmany' && valeur.constructor === Array) {

                // Déjà instancié: màj des propriétés
                if (this._data[nom] instanceof Modele)
                    throw new Error("TODO: Gérer update de liste d'associations existante");
                // Nouvelle instance
                else {

                    const tableAssociee = asso.reverse === false
                        ? asso.pk.table
                        : asso.fk.table;

                    const modeleAssocie = tableAssociee.modele
                    if (modeleAssocie !== undefined)
                        valeur = valeur.map((v: object) => modeleAssocie.class.build(v, optsApropager));

                }

            }
        }

        return valeur;
    }

    /*----------------------------------
    - RECUPERATION
    ----------------------------------*/

    public static scope<T extends Modele>(this: ClassOf<T>, source: string | TImportedQuery | TQueryAbstraite) {
        return new QueryRunner<T>(source);
    }

    public static all<T extends Modele>( this: ClassOf<T>, ...args: Parameters<QueryRunner<T>["all"]> ) {
        return new QueryRunner<T>('FROM ' + this.metas.name).all(...args);
    }
    public static count<T extends Modele>(this: ClassOf<T>, ...args: Parameters<QueryRunner<T>["count"]>) {
        return new QueryRunner<T>('FROM ' + this.metas.name).count(...args);
    }
    public static find<T extends Modele>(this: ClassOf<T>, ...args: Parameters<QueryRunner<T>["find"]>) {
        return new QueryRunner<T>('FROM ' + this.metas.name).find(...args);
    }
    public static findOrFail<T extends Modele>(this: ClassOf<T>, ...args: Parameters<QueryRunner<T>["findOrFail"]>) {
        return new QueryRunner<T>('FROM ' + this.metas.name).findOrFail(...args);
    }
    public static existsOrFail<T extends Modele>(this: ClassOf<T>, ...args: Parameters<QueryRunner<T>["existsOrFail"]>) {
        return new QueryRunner<T>('FROM ' + this.metas.name).existsOrFail(...args);
    }
    public static raw<T extends Modele>(this: ClassOf<T>, ...args: Parameters<QueryRunner<T>["raw"]>) {
        return new QueryRunner<T>('FROM ' + this.metas.name).raw(...args);
    }

    public async reload(opts: TOptsActionModele = {}) {

        this.log(`Reload`);

        const valsPks = this.getPkValues();

        const classeModele = this.constructor as typeof Modele;

        const nouvellesDonnees = await new SelectQuery<this>(classeModele).find({
            where: valsPks,
            raw: true // On n'instancie pas car on garde la même instance du modèle pour conserver les options, références, etc ...
        });

        this.set(nouvellesDonnees, { viaDb: true })

        this.log(`Reloaded:`, this.getChangedData());

        return this;

    }

    /*----------------------------------
    - ENREGISTREMENT
    ----------------------------------*/
    public static async create<T extends Modele>(this: ClassOf<T>, donnees: Partial<T>, opts?: TOptsInsert): Promise<T> {

        console.log(`[modele][${this.metas.name}][static] Create`, donnees);

        const modele = this.build(donnees, { viaDb: false });

        await modele.insert(opts);
        // Autrement, les données des pks ont été fournies dans les données à insérer

        await this.AfterCreate(modele);

        return modele;
    }

    // donnees undefined = update changed data
    public async update(donnees: undefined | Partial<this>, opts?: TOptsUpdate): Promise<void> {

        const optsApropager = opts === undefined ? undefined : {
            simuler: opts.simuler
        }

        this.log(`Update`, donnees);

        // Màj Associations
        // On le fait avant getChangedData, car saveAssos assigne les fks des données insérées
        await this.saveAssos(false, optsApropager);

        if (donnees === undefined) {

            const changedData = this.getChangedData();

            if (changedData === null) {
                this.log(`Update canceled (no change)`);
                return;
            }

            donnees = changedData;

        } else {

            // .update(<donnees>) = appel manuel, donc pas de viaDb
            this.set(donnees, { viaDb: false })

            if (!this.hasChanged()) {
                this.log(`Update canceled (no change)`);
                return;
            }
            
        }


        const oldData = { ...this._savedData }
        const newData = { ...this._data }

        // Hook
        const classeModele = this.constructor as typeof Modele;
        await classeModele.BeforeUpdate(oldData, newData, {});

        const requete = new UpdateQuery<this>(classeModele);

        // Màj données bdd
        const where = this.getPkValues();

        // Passage des filtres etc 
        const donneesAmaj = this.get({ 
            pourDb: true, 
            liste: Object.keys(donnees) 
        });

        // Màj modèle
        await requete.update(donneesAmaj, { where, ...(opts || {}) });

        // Màj Associations
        await this.saveAssos(true, optsApropager);

        // Hook
        await classeModele.AfterUpdate(oldData, newData, {});
    }

    public static async upsert<T extends Modele>(this: ClassOf<T>, donnees: Partial<T>, opts: TOptsInsert = {}): Promise<void> {

        const requete = new InsertQuery<T>(this);

        console.log(`[modele][${this.metas.name}] Upsert`, donnees);

        // Pk incluses dans les données
        for (const pk of this.metas.tables.default.pk) {
            if (donnees[pk] === undefined)
                throw new Error(`La valeur des pks doivent être incluses dans les valeurs à upsert (pas le cas de ${pk})`);
        }

        let donneesAupdate: string[] = [];
        for (const cle in donnees)
            if (!this.metas.tables.default.pk.includes( cle ))
                donneesAupdate.push(cle);

        await requete.insert(donnees, donneesAupdate, opts);
        
    }

    public static async update<T extends Modele>(this: ClassOf<T>, donnees: Partial<T>, opts: TOptsUpdate) {

        console.log(`[modele][${this.metas.name}] Update`, donnees);

        const requete = new UpdateQuery<T>(this);

        await requete.update(donnees, opts);
        
    }

    public async insert(opts?: TOptsInsert): Promise<string | number> {

        const metas = this._metas;
        const attrs = this._model._attributes;

        const optsApropager = opts === undefined ? undefined : {
            simuler: opts.simuler
        }

        // Enregistre d'abord les associations dont le modèle actuel dépend des pks (asso.reverse = false)
        await this.saveAssos(false, optsApropager);
        
        // Préparation des données pour l'insertion
        const donnees = this.get({ pourDb: true });

        this.log(`Insert`, donnees);

        // Execution de la requete
        const classeModele = this.constructor as typeof Modele;
        const requete = new InsertQuery<this>(classeModele);
        const idInsere = await requete.insert(donnees, undefined, opts);

        // Un seul id généré via autoincrmeent = on le récupère
        if (metas.tables.default.pk.length === 1) {
            const nomPk = metas.tables.default.pk[0];

            if (attrs[nomPk]?.colonne?.autoIncrement === true) {

                this.set({ [nomPk]: idInsere }, { viaDb: true });

            }

            this.log(`Inserted (${nomPk} = ${this._data[nomPk]})`);
        }

        // Marque comme enregistré
        this._enregistre = true;

        // Enregistre ensuite les associations dépendant de l'id du modèle actuel
        await this.saveAssos(true, optsApropager);

        return this.getPkValue()
    }

    public async save(opts?: TOptsQuery) {

        this.log(`Save`);

        // Insertion de toutes les données
        if (this._enregistre === false) {
            
            await this.insert(opts);

        // Màj des données modifiées
        } else {

            await this.update(undefined, opts);
        }
    }

    // reverse = false:     Enregistre d'abord les associations dont le modèle actuel dépend des pks
    // reverse = true:      Enregistre ensuite les associations dépendant de l'id du modèle actuel
    private async saveAssos(reverse: false, opts?: TOptsUpdate): Promise<Partial<this>>;
    private async saveAssos(reverse: true, opts?: TOptsUpdate): Promise<null>;
    private async saveAssos(reverse: boolean, opts?: TOptsUpdate): Promise<Partial<this> | null> {

        const metas = this._metas;
        const updatedFks: Partial<this> = {}

        this.log(`[associations][save] ${reverse ? 'Association -> ' + this._name : this._name + ' -> Association'}`);

        // Pour chaque association avec un autre modèle
        for (const nomAsso of metas.associations.all) {

            // Sans cette ligne, crash à l'enregistrement d'une publicité
            this.log(`[associations][save] 1 ${nomAsso}`);

            const asso = metas.attributes[nomAsso].association;
            if (
                asso?.mode === 'relation' && asso.reverse === reverse 
                && 
                this._data[nomAsso] !== undefined && this._data[nomAsso] instanceof Modele
            ) {

                this.log(`[associations][save] ${nomAsso}`);

                if (reverse === true) {
                    // On considère que le mode CASCADE est configuré pour toutes les pks faisant référence à une pk
                    // EX: MissionMetas.id (fk) => Mission.id (pk)
                    // Un update de Mission.id provoque donc systématiquement un update de MissionMetas.id
                    // On marque donc la fk des associations reverse comme déjà mise à jour
                    // TODO: if (asso.fk.association.contrainte.onUpdate === 'CASCADE')
                    //this.log("[associations][save] Prise en considération du paramètre CASCADE ON UPDATE", asso)
                    this._data[nomAsso]._savedData[asso.fk.nom] = this._data[nomAsso]._data[asso.fk.nom];

                } else {

                    if (!this._data[nomAsso].hasChanged())
                        continue;

                    this.log(`[associations][save] ${this._name}.${nomAsso} (${asso.type})`);
                    await this._data[nomAsso].save(opts);

                    // Màj de la fk du modèle actuel via la nouvelle pk du modèle associé
                    const nouvelleValFk = this._data[nomAsso][asso.pk.nom]
                    this.log(`[associations][save] ${this._name}.${asso.fk.nom} = ${this._name}.${nomAsso}.${asso.pk.nom} = `, nouvelleValFk);
                    updatedFks[asso.fk.nom] = this._data[asso.fk.nom] = nouvelleValFk;

                }

            }
        }

        if (reverse === false) {

            this.log(`[associations][save] Finished. Updated pks:`, updatedFks);
            return updatedFks;

        } else
            return null;

    }

    public static async delete<T extends Modele>(this: ClassOf<T>, opts: string | number | { where: TWhere }) {

        if (typeof opts !== 'object')
            opts = {
                where: {
                    [this.metas.tables.default.pk[0]]: opts
                }
            }

        const requete = new DeleteQuery<T>(this);
        await requete.delete(opts);

    }

    public async delete() {

        const valsPks = this.getPkValues();
        const classeModele = this.constructor as typeof Modele;

        const requete = new DeleteQuery<this>(classeModele);
        await requete.delete({  
            where: valsPks
        });

        await classeModele.AfterDelete(this);

        this._enregistre = false;

    }

    /*----------------------------------
    - HOOKS
    ----------------------------------*/
    public static async BeforeQuery() {  }
    public static BeforeBuild<T extends Modele>(this: ClassOf<T>, donnees: any, opts?: TOptsSet): Partial<any> { return donnees; }

    // NOTE: Losqu'on type le paramètre instance avec T,
    //  On obtient une erreur typescript sur toutes les implémentations du hook:
    // « Approbation is not assignable to T »  
    public static async AfterCreate<T extends Modele>(this: ClassOf<T>, instance: any): Promise<void> { }

    public static async BeforeUpdate<T extends Modele>(this: ClassOf<T>, before: any, after: any, opts: TOptsAfterUpdate<T>): Promise<void> { }
    public static async AfterUpdate<T extends Modele>(this: ClassOf<T>, before: any, after: any, opts: TOptsAfterUpdate<T>): Promise<void> { }

    public static async AfterDelete<T extends Modele>(this: ClassOf<T>, instance: any): Promise<void> {  }
}