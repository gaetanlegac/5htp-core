/*----------------------------------
- DEPENDANCES
----------------------------------*/

import type Modele from '.';

import { TAssociationLibre, TAssociationRelation, TAssociationQuery } from '../database/metas';
import QueryParser from '../database/jsql/query/base';
import { TQueryAbstraite } from '../database/jsql/parser/abstraction';

import { setAttribute } from './attributes';

/*----------------------------------
- TYPES
----------------------------------*/

export type TAssociationRelationViaDecorateur = (TAssociationRelation & {
    // Lorsque spécifié via décorateur, pk et fk sont spcifiés via leur nom, et pk est optionnelle
    // On utilisera donc getModel pour déterminer la pk / fk une fois que tous les modèles seront chargés (via Database.initModels)
    // Et on transformera le nom des colonnes en références vers TMetasColonne
    getModel: (() => typeof Modele | string),
    pk?: string,
    fk: string,
})

// En attente de completion via Database et ModelsManager
export type TAssociationViaDecorateur = TAssociationLibre | TAssociationQuery | TAssociationRelationViaDecorateur

// Association colonne BDD
export type TContrainteColonne = {
    onDelete: null | 'CASCADE',
    onUpdate: null | 'CASCADE',
}




type TOptsAssoLibre = Partial<Pick<TAssociationLibre, 'pk'>>

type TOptsQuery = string | TQueryAbstraite;

type TFromRelation = TAssociationRelationViaDecorateur["getModel"];
type TOptsRelation = (
    // Obligatoie
    Pick<TAssociationRelationViaDecorateur, 'fk'>
    &
    // Optionnek
    Partial<Pick<TAssociationRelationViaDecorateur, 'pk' | 'reverse' | 'where' | 'required'>>
)

type TDecorateurAttribut = (classe: Modele, attribut: string) => void

/*----------------------------------
- DECORATORS
----------------------------------*/

// Simple initialisation. Les contraintes seront toutes définies via une requete
export function HasOne(from: 'libre', opts?: TOptsAssoLibre): TDecorateurAttribut;
// Les options ne sont pas prises en compte quand c'est une requete brute
export function HasOne(from: 'query', opts: TOptsQuery): TDecorateurAttribut;
// Format recommandé: spécification de la fk et d'éventuels autres paramètrages
export function HasOne(from: TFromRelation, opts: TOptsRelation): TDecorateurAttribut;

export function HasOne(from?: 'libre' | 'query' | TFromRelation, opts?: TOptsAssoLibre | TOptsQuery | TOptsRelation): TDecorateurAttribut {
    return (classe: Modele, attribut: string) => {

        // Défini manuellement dans une requete
        if (from === 'libre') {

            if (opts !== undefined && typeof opts !== 'object')
                throw new Error(`Les options passées pour la définition d'une association libre doivent être au format objet.`);

            setAttribute(classe, attribut, {
                association: {
                    mode: 'libre',
                    type: 'hasone',
                    ...(opts || {})
                }
            });

            // Via query
        } else if (from === 'query') {

            if (opts === undefined)
                throw new Error(`Les options doivent être passées pour la définition d'une association query.`);

            setAttribute(classe, attribut, {
                association: {
                    mode: 'query',
                    type: 'hasone',
                    query: QueryParser.parse(opts)
                }
            });

            // Via modèle ou table
        } else {

            if (typeof opts !== 'object')
                throw new Error(`Les options doivent être passées pour la définition d'une relation avec un modèle ou une table.`);

            setAttribute(classe, attribut, {
                association: {
                    mode: 'relation',
                    type: 'hasone',
                    reverse: false,
                    getModel: from,

                    ...opts
                }
            });
        }
    }
}

// Mêmes surchages que pour HasOne
export function HasMany(from: 'libre', opts?: TOptsAssoLibre): TDecorateurAttribut;
export function HasMany(from: 'query', opts: TOptsQuery): TDecorateurAttribut;
export function HasMany(from: TFromRelation, opts: TOptsRelation): TDecorateurAttribut;

export function HasMany(from?: 'libre' | 'query' | TFromRelation, opts?: TOptsAssoLibre | TOptsQuery | TOptsRelation): TDecorateurAttribut {
    return (classe: Modele, attribut: string) => {

        // Défini manuellement dans une requete
        if (from === 'libre') {

            if (opts !== undefined && typeof opts !== 'object')
                throw new Error(`Les options passées pour la définition d'une association libre doivent être au format objet.`);

            setAttribute(classe, attribut, {
                association: {
                    mode: 'libre',
                    type: 'hasmany',
                    ...(opts || {})
                }
            });

            // Via query
        } else if (from === 'query') {

            if (opts === undefined)
                throw new Error(`Les options doivent être passées pour la définition d'une association query.`);

            setAttribute(classe, attribut, {
                association: {
                    mode: 'query',
                    type: 'hasmany',
                    query: QueryParser.parse(opts)
                }
            });

            // Via modèle ou table
        } else {

            if (typeof opts !== 'object')
                throw new Error(`Les options doivent être passées pour la définition d'une relation avec un modèle ou une table.`);

            setAttribute(classe, attribut, {
                association: {
                    mode: 'relation',
                    type: 'hasmany',
                    reverse: true,
                    getModel: from,
                    required: false, // Autorise l'association à retourner aucun résultat

                    ...opts
                }
            });
        }
    }
}