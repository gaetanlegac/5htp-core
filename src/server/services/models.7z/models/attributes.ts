/*----------------------------------
- DEPENDANCES
----------------------------------*/

// Types
import Modele from '.';
import type { TTypeJs } from '../database/datatypes';
import type { TMetasColonne, TAssociation, TMetasApi } from '../database/metas';

/*----------------------------------
- TYPES
----------------------------------*/
export type TMetasAttribut = {
    nom: string,
    js?: TMetasJs,
    table?: string, // Nom de la table
    colonne?: TMetasColonne,

    // Contraits relatives au type de colonne mysql
    enum?: any[],
    set?: any[],

    // Toutes les props manquantes doivent être déterminées via initModeles
    association?: TAssociation,
}

export type TMetasJs = {
    nom: string,
    nomComplet: string,
    type: TTypeJs,
    optionnel: boolean
}


import type { User } from '@models';
type FuncControleAcces = (obj: { [cle: string]: any }, utilisateur: User) => boolean
export type TControleAcces = string | string[] | FuncControleAcces;

/*----------------------------------
- HELPER
----------------------------------*/
export function setAttribute( instance: Modele, attribute: string, opts: Partial<TMetasAttribut> ) {

    const Class = instance.constructor as typeof Modele;

    // NOTE: Une définition statiqu dans la classe Modele entraine un conflit de références
    if (Class._attributes === undefined)
        Class._attributes = {}

    Class._attributes[attribute] = {
        ...(Class._attributes[attribute] || {}),
        ...(opts || {}),
    }

}

/*----------------------------------
- DECORATORS
----------------------------------*/
export function Column( opts: Partial<TMetasAttribut> = {} ) {
    return (Class: Modele, attribute: string) => {

        // Initialise metas.colonne (qui sera complété par la suite dans Database.initModeles)
        setAttribute(Class, attribute, { 
            ...opts,
            colonne: {  // Indique que l'attribut peut etre rattaché à la colonne
                attached: false // Données métas de la bdd pas encore chargées
            }
        })

    }
}

export function API(auth?: TControleAcces, opts: Partial<Omit<TMetasApi, 'auth'>> = {}) {
    return (Class: Modele, attribute: string) => {

        setAttribute(Class, attribute, {
            ...opts,
            api: { auth, ...opts }
        })
    }
}

// Ni une colonne, ni exposé à l'api
export function Virtual(opts: Partial<TMetasAttribut> = {}) {
    return (Class: Modele, attribute: string) => {

        setAttribute(Class, attribute, opts)

    }
}