/*----------------------------------
- DEPENDANCES
----------------------------------*/

// Libs
import Database from '@server/services/database';
import QueryParser from '../database/jsql/query/base';
import app from '@server/app';

/*----------------------------------
- TYPES
----------------------------------*/

import type Model from './';

import type {
    TMetasTable, TMetasColonne,
    TAssociation, TMetasTablesIncompletes
} from '../database/metas';

import type { 
    TAssociationViaDecorateur
} from './associations';

/*----------------------------------
- SERVICE
----------------------------------*/
export class ModelsManager {

    public modeles: { [nom: string]: typeof Model } = {}

    /*----------------------------------
    - SERVICE
    ----------------------------------*/

    public constructor() {
        app.on('ready', () => this.load());
    }

    // RAPPEL: Les décorateurs des modèles sont executés AVANT Database.init()
    public async load() {

        console.info(`Waiting for database to be ready`);
        await Database.loading;
        console.info(`Database ready. Indexing models.`);

        await this.prepare();

        await this.associate();

        console.info(`Models are ready: `, Object.keys( this.modeles ).join(', '));
    }

    /*----------------------------------
    - INIT
    ----------------------------------*/
    private prepare() {
        console.info(`Preparing models:`, Object.keys(this.modeles).join(', '));

        for (const nomModele in this.modeles) {

            const model = this.modeles[nomModele];
            const metas = model.metas;

            // Verif existance table par défaut
            const nomTables = Object.keys(metas.tables);
            if (nomTables[0] !== 'default')
                throw new Error(`La table default doit être spécifiée en premier dans le décorateur @Table`);

            // Récupération métas depuis bdd
            for (const idTable in (metas.tables as unknown as TMetasTablesIncompletes)) {
                const tableIncomplete = metas.tables[idTable];

                // Remplace les métas incomplètes par les métas extraites via la bdd
                const database = Database.tables[tableIncomplete.database];
                metas.tables[idTable] = database[tableIncomplete.nom];
                const table = metas.tables[idTable];

                // Table non trouvée
                if (table === undefined)
                    throw new Error(`La table \u00ab ${tableIncomplete.database}.${tableIncomplete.nom} \u00bb (alias: ${nomModele}.${idTable}) n'a pas été trouvée dans la base de données.`);

                // La table par défaut est rattachée à son modèle
                if (idTable === 'default') {
                    table.modele = metas;
                    table.alias = metas.alias;
                }

                // Correction de chaque colonne
                for (const nomAttr in metas.attributes) {

                    const attr = metas.attributes[nomAttr as keyof typeof metas.attributes]
                    const colonne = table.colonnes[nomAttr]

                    // Si la colonne est bien associée à un attribut
                    if (colonne === undefined)
                        continue;

                    attr.table = idTable;
                    attr.colonne = colonne;

                    // Verif cohérence
                    if (colonne.type === 'ENUM') {

                        if (attr.enum === undefined)
                            throw new Error(`${nomModele}.${nomAttr}: Afin d'éviter tout problème d'incohérence, le paramètre enum doit être passé dans @Colonne pour tous les attributs faisant reférence à une colonne de type ENUM.`);

                        let incoherent = false;

                        for (const val of attr.enum)
                            if (!colonne.typeParams.includes(val + '' /* Val peut être un number */)) {
                                incoherent = true;
                                break;
                            }

                        if (incoherent || attr.enum.length !== colonne.typeParams.length)
                            throw new Error(`${nomModele}.${nomAttr}: Les valeurs de l'enum passé dans @Colonne (${attr.enum.join(', ')}) ne correspondent pax à celles spécifiées dans la bdd (${colonne.typeParams.join(', ')}).`);

                    } else if (colonne.type === 'SET') {

                        if (attr.set === undefined)
                            throw new Error(`${nomModele}.${nomAttr}: Afin d'éviter tout problème d'incohérence, le paramètre set doit être passé dans @Colonne pour tous les attributs faisant reférence à une colonne de type ENUM.`);

                        let incoherent = false;

                        for (const val of attr.set)
                            if (!colonne.typeParams.includes(val + '' /* Val peut être un number */)) {
                                incoherent = true;
                                break;
                            }

                        if (incoherent || attr.set.length !== colonne.typeParams.length)
                            throw new Error(`${nomModele}.${nomAttr}: Les valeurs du set passé dans @Colonne (${attr.set.join(', ')}) ne correspondent pax à celles spécifiées dans la bdd (${colonne.typeParams.join(', ')}).`);

                    }

                    // Référencements de l'attribut en tant que colonne
                    metas.columns.push(nomAttr);

                }

                // Assure que le rattachement puisse bien être fait entre les tables secondaires et la table principale
                // Verif si les tables secondaires portent au moins les mêmes pks que la table principale
                for (const pk of metas.tables.default.pk)
                    if (!(pk in metas.tables[idTable].colonnes))
                        throw new Error(`Les tables secondaires doivent toutes porter au moins les pks de la table principale. La pk ${pk} est absente de la table ayant pour alias ${idTable}`);

                // Correction ds attributs une fois qu'ils ont tous été référencés
                for (const nomAttr in metas.attributes) {
                    const attr = metas.attributes[nomAttr as keyof typeof metas.attributes];

                    // Associations
                    if (attr.association !== undefined && !metas.associations.all.includes(nomAttr)) {

                        // Référencement liste attributs associés à un modèle
                        metas.associations.all.push(nomAttr);
                        metas.associations[attr.association.type].push(nomAttr);

                    }

                    // Référencement liste attributs exposés à l'api
                    if (attr.api !== undefined)
                        metas.api.push(nomAttr);

                    // Type JS
                    if (attr.js !== undefined) {

                        // Valeur par défaut
                        if (attr.js.defaut !== undefined)
                            metas.defaultValues[nomAttr] = attr.js.defaut;

                        // Corrrection type
                        if (attr.js.type !== undefined && attr.js.type.endsWith('[]'))
                            attr.js.type = 'array'

                    }


                }

                if (metas.tables.default.pk.length === 0)
                    throw new Error(`Aucune pk n'a été trouvée pour le modele ` + nomModele);
            }
        }
    }

    private associate() {

        console.info(`Creating associations ...`);

        // Completion des métadonnées des associations
        // Tous les modèles doivent déjà être initialisés au préalable, pour pouvoir accèder à leurs métadonnées
        // C'est pourquoi on itère à nouveau la liste des modèles
        for (const nomModele in this.modeles) {

            const model = this.modeles[nomModele];
            const metas = model.metas;

            for (const nomAttr of metas.associations.all) {

                // Completion de l'association si définie via un décorateur
                // - Détermine la pk si pas spéciiée
                // - Créé une référence vers les colonnes concernées
                const attr = model._attributes[nomAttr];
                const asso = attr.association as unknown as (TAssociationViaDecorateur | TAssociation);

                // La completion auto n'est pas applicable aux associations libres (voir metas.ts pour plus d'infos)
                // Si getModel = undefined, l'associaion a déjà été traitée
                if (asso?.getModel === undefined || asso.mode !== 'relation')
                    continue;

                // Recup des métas de la table associée
                const associe = asso.getModel();

                //console.log(`[boot][database][modeles] Init association ${nomModele}.${nomAttr}`, associe, modele.tables);
                let tableAssociee: TMetasTable;
                if (typeof associe === 'string') { // <database>.<table>

                    const [nomDbAsso, nomTableAsso] = associe.split('.');
                    tableAssociee = Database.tables[nomDbAsso][nomTableAsso];

                    if (tableAssociee === undefined)
                        throw new Error(`Impossible de trouver la base de données ${nomDbAsso}.${nomTableAsso}`);

                } else // Modèle
                    tableAssociee = associe.metas.tables.default;

                // Completion des métas de l'association
                let assoComplete: TAssociation, pk: TMetasColonne, fk: TMetasColonne;
                if (asso.reverse === false) { // fk = modèle actuel / pk = modèle associé

                    const nomPk = asso.pk || tableAssociee.pk[0];
                    pk = tableAssociee.colonnes[nomPk];
                    if (pk === undefined)
                        throw new Error(`Impossible de créer l'association ${nomModele} -> ${tableAssociee.nom} sur la propriété ${nomModele}.${nomAttr}, car la PK ${nomPk} n'a pas été référencée pour la table ${tableAssociee.chemin}.`);

                    fk = metas.tables.default.colonnes[asso.fk];
                    if (fk === undefined)
                        throw new Error(`Impossible de créer l'association ${nomModele} -> ${tableAssociee.nom} sur la propriété ${nomModele}.${nomAttr}, car la FK ${asso.fk} n'a pas été référencée pour la table ${metas.tables.default.chemin}.`);

                } else { // fk = modèle associé / pk = modèle actuel

                    const nomPk = asso.pk || metas.tables.default.pk[0];
                    pk = metas.tables.default.colonnes[nomPk];
                    if (pk === undefined)
                        throw new Error(`Impossible de créer l'association ${tableAssociee.nom} -> ${nomModele} sur la propriété ${nomModele}.${nomAttr}, car la PK ${nomPk} n'a pas été référencée pour la table ${metas.tables.default.chemin}.`);

                    fk = tableAssociee.colonnes[asso.fk];
                    if (fk === undefined)
                        throw new Error(`Impossible de créer l'association ${tableAssociee.nom} -> ${nomModele} sur la propriété ${nomModele}.${nomAttr}, car la FK ${asso.fk} n'a pas été référencée pour la table ${tableAssociee.chemin}.`);

                }

                assoComplete = {
                    ...asso,
                    fk,
                    pk,
                    getModel: undefined,
                    table: tableAssociee,
                    modele: tableAssociee.modele
                }

                // Si aucune valeur n'a été spécifiée manuellement pour cette association, détermination automatique
                if (assoComplete.required === undefined) {

                    // Par défaut, une association est optionnelle si la valeur de sa fk l'est aussi
                    if (assoComplete.reverse !== true && assoComplete.fk.nullable === true)
                        assoComplete.required = false;
                    else
                        assoComplete.required = assoComplete.type === 'hasone';
                }

                attr.association = assoComplete
            }
        }
    }

    public getScope(chemin: string): QueryParser {

        const [nomModele, ...branches] = chemin.split('.');
        if (branches.length === 0)
            throw new Error(`Format du chemin du scope incorrect: « ${chemin} ». Format requis: <modele>.<branche1>`);

        const modele = this.modeles[nomModele];
        if (modele === undefined)
            throw new Error(`Impossible de récupérer le scope ${chemin}: Le modèle ${nomModele} n'est pas référencé. Modèles connus: ${Object.keys(this.modeles).join(', ')}`);

        const scope = modele.metas.scopes[chemin];
        if (scope === undefined)
            throw new Error(`Scope introuvable: ${chemin}. A t-il bien été rattaché à son modèle via le décorateur @Scopes ? Liste des scopes connus pour ${nomModele}: ${Object.keys(modele.metas.scopes).join(', ')}`);

        //console.log(`[database][modeles] getScope ${chemin}`, scope);

        // Instancie la query afin que les ast soient lus et mis en cache
        const ast = QueryParser.parse(scope);
        // Prebuild pour rendre les ast accessibles
        ast.prebuild();

        return ast;

    }

}

export default new ModelsManager