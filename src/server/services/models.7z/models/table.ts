/*----------------------------------
- DEPENDANCES
----------------------------------*/

// Core
import Database from '../database';
import ModelsManager from './manager';

// Types
import type Modele from '.';
import type { TMetasAttribut } from './attributes';
import type { TImportedQuery } from '../database/jsql/query/runner';
import type { TAssociationsIndex, TMetasTables, TMetasTablesIncompletes } from '../database/metas';

/*----------------------------------
- TYPES
----------------------------------*/
type TOptsTable = {}

export type TModelMetas = {

    // Identity
    name: string,
    alias: string,
    class: typeof Modele,

    // Database
    database: string,
    tables: TMetasTables,
    columns: string[], // Attributs étant rattachés à des colonnes de la bdd
    associations: TAssociationsIndex,
    scopes: { [id: string]: TImportedQuery },

    // Attributes
    defaultValues: { [nom: string]: any },
    api: string[], // Attributs étant exposés à l'api
    attributes: { [name: string]: TMetasAttribut },
}

/*----------------------------------
- DECORATORS
----------------------------------*/
export function Table(database: string, nomTables: string | {[nom: string]: string}, opts?: TOptsTable ) {
    // Attention: classe fair référence au constructeur, et non à la classe elle-même
    return <TModel extends typeof Modele>(classe: TModel): TModel => {

        const nom = classe.name;
        const attributes = opts && opts["metadata"]; // Métadnnées injectées depuis le plugn babel

        if (typeof nomTables === 'string')
            nomTables = { default: nomTables }
        // On chargera les métadonnées de la table de mnière synchrone dans DatabasE.initModels()
        const tables = {} as unknown as TMetasTablesIncompletes
        for (const aliasTable in nomTables)
            tables[aliasTable] = {
                database,
                nom: nomTables[aliasTable],
                loaded: false
            }

        // Pointe les attributs vers Modele.data via getters et setters
        // Créer une classe dérivée est la seule solution connue pour écraser les définitions de propriété crées dans le constructeur de la classe par @babel/plugin-proposal-class-properties
        // https://github.com/RobinBuschmann/sequelize-typescript/issues/612
        const classeCorrigee = ModelsManager.modeles[nom] = (class extends classe {
            constructor() {
                super();

                for (const prop in classe._attributes) {

                    // Si défini manuelleent
                    const existants = Object.getOwnPropertyDescriptor(classe.prototype, prop);

                    Object.defineProperty(this, prop, {
                        get: existants?.get || function () {
                            return this.getData(prop)
                        },
                        set: existants?.set || function (value) { 
                            this.setData(prop, value)
                        },
                        configurable: true,
                        enumerable: true
                    });
                }
            }
        }) as TModel;

        classeCorrigee.metas = {

            // Identity
            name: nom,
            alias: nom.toLowerCase(),
            class: classeCorrigee,

            // Database
            dataase: database,
            tables: tables,
            columns: [],
            associations: { all: [], hasmany: [], hasone: [] },
            scopes: {},

            // Attributes
            attributes: classeCorrigee._attributes,
            api: [],
            defaultValues: {}

        }

        // Donne à classeCorrigee le nom de classe d'origine (sinon, conserve classeCorrigee, pas terrible pour le debug)
        Object.defineProperty(classeCorrigee, 'name', { value: nom });

        // Ajout de la base de données à la liste des bdd à charger
        if (Database.tables[ database ] === undefined)
            Database.toLoad.add( database );

        return classeCorrigee;
    }
}

export function Scopes( scopes: TImportedQuery[] = [] ) {
    // Attention: classe fair référence au constructeur, et non à la classe elle-même
    return <TModel extends typeof Modele>(classe: TModel): TModel => {

        // Référencement des scopes
        for (const scopeQuery of scopes) {

            const cheminScope = scopeQuery.id;
            console.log(`[database][scopes]`, classe.name, cheminScope);
            if (cheminScope === undefined)
                throw new Error(`Impossible de répertorier le scope car aucun ID n'a été associé au query factory`);

            classe.metas.scopes[ cheminScope ] = scopeQuery
            
        }

        return classe;

    }
}